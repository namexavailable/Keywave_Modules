/*
 * ============================================================
 *  KW007 Configuration & Status — Keywave 5.8GHz Doppler Radar
 *
 *  What it does:
 *    Configures the sensor with the settings in the CONFIG block
 *    below, then prints a live status report to the Serial Monitor
 *    every 500 ms.
 *
 *  How to use:
 *    1. Edit the CONFIG block below to match your needs.
 *    2. Upload, open Serial Monitor at 115200 baud.
 *    3. To change a setting, edit the value and re-upload.
 *
 *  Copy-paste into your own project:
 *    The CONFIG block + the applyConfig() function are
 *    self-contained — copy both into your sketch's setup().
 *
  *  Board preset: ESP32-S3                        SDA=GPIO8 SCL=GPIO9
 *
 *  Wiring (KW007 -> Board):
 *    VCC -> 3.3V (5V on UNO is OK if your KW007 module supports it)
 *    GND -> GND
 *    SDA -> SDA pin (board-specific, see Wire.begin() below)
 *    SCL -> SCL pin (board-specific, see Wire.begin() below)
 * ============================================================
 */

#include <Wire.h>
#include "KW007_api.h"

/* ============================================================
 *  CONFIG — edit these values to change sensor behaviour
 * ============================================================ */

/* Detection range: 1 (~15 cm) ... 8 (~13 m)
 *   1 = ~15 cm   close-up
 *   2 = ~50 cm   desktop / shelf
 *   3 = ~1 m     near
 *   4 = ~3 m     room (good default)
 *   5 = ~5 m     larger room
 *   6 = ~7 m     hallway
 *   7 = ~10 m    long range
 *   8 = ~13 m    max (enhanced mode on)
 */
#define CFG_RANGE              4

/* GPO output hold time after motion stops.
 *   DELAY_SETTING1 — KW007-S: 4s     KW007-L/SE: 16s
 *   DELAY_SETTING2 — KW007-S: 2s     KW007-L/SE: 32s
 *   DELAY_SETTING3 — KW007-S: 1s     KW007-L/SE: 1s
 *   DELAY_SETTING4 — KW007-S: 64s    KW007-L/SE: 64s
 */
#define CFG_HOLD_TIME          DELAY_SETTING3

/* Slow-speed detection (for very slow targets like a hand creeping closer).
 *   true  = enabled
 *   false = disabled
 */
#define CFG_SLOW_SPEED         true

/* Fast-speed detection (for quickly moving targets like vehicles).
 *   true  = enabled
 *   false = disabled (default)
 */
#define CFG_FAST_SPEED         false

/* System sampling rate.
 *   false = 1 kHz (default)
 *   true  = 500 Hz (lower power)
 */
#define CFG_USE_500HZ          false

/* Status print interval, in milliseconds */
#define CFG_PRINT_INTERVAL_MS  500

/* ============================================================
 *  Apply the CONFIG above to the sensor.
 *  Call AFTER KW007_Init().
 *  Returns KW007_OK on success.
 * ============================================================ */
uint8_t applyConfig(void) {
    uint8_t err;
    if ((err = KW007_SetDetectionRange(CFG_RANGE)))            return err;
    if ((err = KW007_SetGPO_DelayDuration(CFG_HOLD_TIME)))     return err;
    if ((err = KW007_SetSlowSpeedDetection(CFG_SLOW_SPEED)))   return err;
    if ((err = KW007_SetFastSpeedDetection(CFG_FAST_SPEED)))   return err;
    if ((err = KW007_SetSamplingRate(CFG_USE_500HZ)))          return err;
    return KW007_OK;
}

/* ============================================================
 *  Helpers for pretty printing
 * ============================================================ */
const char* modelName(void) {
    switch (KW007_GetModel()) {
        case KW007_S: return "KW007-S/SE";
        case KW007_L: return "KW007-L";
        default:      return "UNKNOWN";
    }
}

const char* holdTimeName(void) {
    /* Names reflect the KW007-L / KW007-SE timings (most common variant) */
    switch (CFG_HOLD_TIME) {
        case DELAY_SETTING1: return "16 s (S: 4s)";
        case DELAY_SETTING2: return "32 s (S: 2s)";
        case DELAY_SETTING3: return "1 s";
        case DELAY_SETTING4: return "64 s";
        default:             return "?";
    }
}

void printConfig(void) {
    Serial.println(F("---------- KW007 Configuration ----------"));
    Serial.print(F("  Model              : ")); Serial.println(modelName());
    Serial.print(F("  Detection range    : ")); Serial.println(CFG_RANGE);
    Serial.print(F("  Hold time          : ")); Serial.println(holdTimeName());
    Serial.print(F("  Slow-speed detect  : ")); Serial.println(CFG_SLOW_SPEED ? "ON"  : "OFF");
    Serial.print(F("  Fast-speed detect  : ")); Serial.println(CFG_FAST_SPEED ? "ON"  : "OFF");
    Serial.print(F("  Sampling rate      : ")); Serial.println(CFG_USE_500HZ  ? "500 Hz" : "1 kHz");
    Serial.print(F("  Print interval     : ")); Serial.print(CFG_PRINT_INTERVAL_MS); Serial.println(F(" ms"));
    Serial.println(F("-----------------------------------------"));
}

/* ============================================================
 *  Setup
 * ============================================================ */
void setup() {
    Serial.begin(115200);
    while (!Serial && millis() < 2000) { }
    Serial.println();
    Serial.println(F("KW007 Configuration & Status"));

    /* Start I2C — uncomment line for your board if default fails */
    // Wire.begin();              // UNO / Nano
    // Wire.begin(8, 9);          // ESP32-S3 / ESP32-C3
    // Wire.begin(4, 5);          // ESP8266 D1 Mini
    Wire.begin(8, 9);    // <-- preset for this board

    uint8_t err = KW007_Init();
    if (err != KW007_OK) {
        Serial.print(F("Init FAILED  err=0x"));
        Serial.println(err, HEX);
        Serial.println(F("Check wiring, power, and pull-ups."));
        while (1) delay(1000);
    }

    err = applyConfig();
    if (err != KW007_OK) {
        Serial.print(F("Config FAILED  err=0x"));
        Serial.println(err, HEX);
        while (1) delay(1000);
    }

    printConfig();
    Serial.println(F("Wave your hand in front of the sensor.\n"));
}

/* ============================================================
 *  Main loop — read + print status every CFG_PRINT_INTERVAL_MS
 * ============================================================ */
void loop() {
    static uint32_t lastPrint = 0;
    uint32_t now = millis();

    if (now - lastPrint < CFG_PRINT_INTERVAL_MS) {
        delay(20);
        return;
    }
    lastPrint = now;

    KW007_Data d = KW007_Read();
    if (!d.ok) {
        Serial.println(F("[I2C read failed]"));
        return;
    }

    /* Build a clean status line:
     *   [   12345 ms]  motion: APPROACH+LEAVE   RSSI=187   state: day
     */
    char line[100];
    const char *motion;
    if      (d.approaching && d.leaving) motion = "APPROACH+LEAVE";
    else if (d.approaching)              motion = "APPROACH      ";
    else if (d.leaving)                  motion = "       LEAVE  ";
    else                                 motion = "  (idle)      ";

    snprintf(line, sizeof(line),
             "[%8lu ms]  motion: %s   RSSI=%3u   state: %s",
             (unsigned long)now,
             motion,
             d.rssi,
             d.isDay ? "day" : "rest");
    Serial.println(line);
}
