# KW007 SDK — Distribution Package

Keywave **KW007** 5.8 GHz Doppler radar sensor — official SDK, packaged as
four ready-to-install variants. **Pick one** that matches your platform.

## Which folder do I use?

| Your platform                                                 | Use this variant         |
|----------------------------------------------------------------|--------------------------|
| Arduino UNO / Nano / Mega                                      | `KW007_SDK_Arduino/`     |
| ESP32 (any flavour: S3, C3, S2, original, etc.)                | `KW007_SDK_Arduino/`     |
| ESP8266 (D1 Mini, NodeMCU, etc.)                               | `KW007_SDK_Arduino/`     |
| Raspberry Pi Pico / RP2040 (Arduino IDE)                       | `KW007_SDK_Arduino/`     |
| SAMD21 / nRF52 boards programmed via Arduino IDE               | `KW007_SDK_Arduino/`     |
| STM32 with STM32CubeIDE / CubeMX                               | `KW007_SDK_STM32/`       |
| Windows PC + FTDI USB-I2C adapter (C++ Builder evaluation)     | `KW007_SDK_FTDI/`        |
| Anything else (Nordic, NXP, Renesas, TI, Linux, RTOS, etc.)    | `KW007_SDK_Custom/`      |

> Quick rule: **if you're using the Arduino IDE on any board → `KW007_SDK_Arduino`.**

## Why are there separate variants?

The SDK has a Hardware Abstraction Layer (HAL) — a small file that talks to
your specific platform's I2C peripheral. Only **one** HAL can be compiled at
a time; if more than one is present in the same build, the linker will
complain about *"multiple definition of `KW007_HAL_WriteReg`"*.

To make installation foolproof, each variant ships with **exactly one HAL
file** baked in. You cannot get the linker error by mistake.

## How to install (Arduino IDE)

1. Download **only the variant folder you need** (e.g. `KW007_SDK_Arduino/`).
   Right-click → "Compress to ZIP" if you grabbed the unzipped folder.
2. Open the Arduino IDE.
3. Go to **Sketch → Include Library → Add .ZIP Library...**
4. Select the zip you just made.
5. The library appears under **Sketch → Include Library → Contributed**.
6. In your sketch, add `#include "KW007_api.h"` and call `Wire.begin()`
   followed by `KW007_Init()` in `setup()`.

The Arduino variant also includes a `examples/` folder with ready-to-run
sketches for UNO, ESP32-S3, ESP32-C3, and ESP8266. Find them under
**File → Examples → KW007_SDK_Arduino**.

## How to install (other platforms)

### STM32CubeIDE (`KW007_SDK_STM32/`)
1. Copy `src/*` into your project's `Core/Src/` and `Core/Inc/` folders
   (or any include path your project uses).
2. In `kw007_hal_stm32.c`, edit the line `#include "stm32xxxx_hal.h"` to
   match your STM32 series (e.g. `stm32f4xx_hal.h`, `stm32g0xx_hal.h`).
3. In your `main.c`, call `KW007_HAL_SetI2C(&hi2c1)` *before* `KW007_Init()`,
   passing whichever I2C handle CubeMX generated for you.

### Windows + FTDI (`KW007_SDK_FTDI/`)
1. Add `src/*.c` and `src/*.cpp` to your C++ Builder project.
2. Make sure the existing `I2C_Sys2.h / I2C_Sys2.cpp` driver is on your
   include / source path.
3. In your form, call `KW007_HAL_FTDI_Open()` at startup, then
   `KW007_Init()`. Call `KW007_HAL_FTDI_Close()` on shutdown.

### Custom platform (`KW007_SDK_Custom/`)
1. Copy `src/*` into your project.
2. Open `kw007_hal_user.c` and fill in the four `TODO` functions using
   your platform's I2C and delay APIs. The file contains pseudo-code for
   each function and notes on the 7-bit vs 8-bit address convention.
3. Build. Call `KW007_Init()` in your application code.

## Wiring (all platforms)

```
KW007         Your board
─────         ──────────
VCC    ─────  3.3 V    (5 V on UNO is OK if your KW007 module supports it)
GND    ─────  GND
SDA    ─────  SDA pin  (board-specific)
SCL    ─────  SCL pin  (board-specific)
```

Most KW007 breakout boards include 10 kΩ I2C pull-ups. If yours does not,
add 4.7 kΩ resistors from SDA and SCL to 3.3 V.

## Minimum sketch (Arduino)

```cpp
#include <Wire.h>
#include "KW007_api.h"

void setup() {
    Serial.begin(115200);
    Wire.begin();                    // or Wire.begin(SDA, SCL) for ESP32/ESP8266
    if (KW007_Init() != KW007_OK) {
        Serial.println("Init failed");
        while (1);
    }
    KW007_SetDetectionRange(4);      // ~3 m
}

void loop() {
    KW007_Data d = KW007_Read();
    if (d.ok && d.approaching) Serial.println("APPROACH");
    if (d.ok && d.leaving)     Serial.println("LEAVING");
    delay(125);
}
```

## What's in each variant

```
KW007_SDK_<variant>/
├── library.properties      ← Arduino IDE metadata
├── keywords.txt            ← Arduino IDE syntax highlighting
└── src/
    ├── KW007_api.h         ← high-level API (the only header you #include)
    ├── KW007_api.c         ← high-level API implementation
    ├── kw007_reg.h         ← register-level definitions (advanced use)
    ├── kw007_reg.c         ← register-level helpers
    ├── kw007_hal.h         ← HAL interface
    └── kw007_hal_<X>.{c,cpp}  ← the ONE HAL implementation for this variant
```

The Arduino variant additionally contains:

```
└── examples/
    ├── 01_HelloWorld/      ← prints motion + RSSI to Serial
    ├── 02_MotionLED/       ← onboard LED blinks on motion
    └── 03_Configuration/   ← edit settings at top of sketch, status to Serial
```

## Troubleshooting

| Symptom                                              | Cause / Fix                                                    |
|------------------------------------------------------|----------------------------------------------------------------|
| `multiple definition of KW007_HAL_WriteReg`          | You installed more than one HAL — uninstall and use just one variant |
| `'DELAY_SETTING3' was not declared`                  | Old SDK files in your sketch folder are overriding the library — delete them |
| `Init FAILED  err=0x10`                              | I2C wiring wrong, missing pull-ups, or no power                |
| `Init FAILED  err=0x20`                              | Sensor present but not responding — check VCC                  |
| Garbage on Serial Monitor                            | Set monitor to 115200 baud                                     |

## Version

KW007 SDK v1.1
