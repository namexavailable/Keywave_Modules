/**
 * ============================================================
 *  KW007_api.h — User API
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.1
 *
 *  High-level functions for application developers.
 *  No register knowledge required.
 *
 *  For direct register access or fine-grained gain control,
 *  include kw007_reg.h additionally.
 *
 *  Supported platforms (provide HAL implementation):
 *    ESP32 / ESP32-S3 / ESP32-C3  — kw007_hal_arduino.cpp
 *    Arduino AVR / SAMD / nRF52   — kw007_hal_arduino.cpp
 *    STM32 (HAL / LL)             — kw007_hal_stm32.c
 *    Windows + FTDI               — kw007_hal_ftdi.cpp
 *    Any MCU with I2C             — kw007_hal_user.c (template)
 *
 *  BASIC USAGE:
 *    KW007_Init();
 *    KW007_SetDetectionRange(4);
 *    KW007_Data data = KW007_Read();
 *    if (data.approaching) { ... }
 * ============================================================
 */

#ifndef KW007_API_H
#define KW007_API_H

#include <stdint.h>
#include <stdbool.h>
#include "kw007_hal.h"   /* provides KW007_OK / KW007_ERR_* return codes */

#ifdef __cplusplus
extern "C" {
#endif

/* ─── SENSOR MODEL ─────────────────────────────────────────── */
typedef enum {
    KW007_UNKNOWN = 0,   /* Unrecognised / not yet detected           */
    KW007_S       = 1,   /* Short-range (R31=0x01; covers KW007-SE)  */
    KW007_L       = 2    /* Long-range  (R31=0x81)                   */
} KW007_Model;

/* ─── GPO DELAY DURATION ───────────────────────────────────── */
/**
 * GPO pin hold-on time after motion stops.
 * Encoded in R29 bits[2:1] (tlight). Actual duration depends on model:
 *
 *   tlight[1:0] │ KW007-S │ KW007-L / KW007-SE
 *   ────────────┼─────────┼────────────────────
 *       00      │    4 s  │   16 s
 *       01      │    2 s  │   32 s
 *       10      │    1 s  │    1 s
 *       11      │   64 s  │   64 s
 */
typedef enum {
    DELAY_SETTING1 = 0,   /* tlight 00 — S:4s   L/SE:16s  */
    DELAY_SETTING2 = 1,   /* tlight 01 — S:2s   L/SE:32s  */
    DELAY_SETTING3 = 2,   /* tlight 10 — S:1s   L/SE:1s   */
    DELAY_SETTING4 = 3    /* tlight 11 — S:64s  L/SE:64s  */
} KW007_DelayDuration;

/* ─── DATA OUTPUT ──────────────────────────────────────────── */
typedef struct {
    bool    ok;           /* false = I2C read failed                  */
    bool    approaching;  /* object approaching                       */
    bool    leaving;      /* object leaving                           */
    bool    isDay;        /* 1=operating, 0=rest                      */
    uint8_t rssi;         /* signal strength 0-255                    */
} KW007_Data;

/* ─── API ──────────────────────────────────────────────────── */

/**
 * Initialize sensor. Runs the official startup sequence.
 * Auto-detects model.
 * Returns KW007_OK / KW007_ERR_I2C / KW007_ERR_NO_DEVICE.
 */
uint8_t KW007_Init(void);

/**
 * Read sensor output. Sensor updates at ~8Hz; poll in main loop.
 * Returns data.ok = false on I2C failure.
 */
KW007_Data KW007_Read(void);

/**
 * Set detection range 1 (close) ~ 8 (far).
 * Sets Gain(amp1/amp2/amp3), Threshold (R27), and enhanced mode atomically.
 *
 * Approximate detection distance (unobstructed, human target):
 *
 *   Range │ amp1 amp2 amp3 │ Threshold │ Enhanced │ ~Distance
 *   ──────┼────────────────┼───────────┼──────────┼──────────
 *     1   │  3    0    0   │    45     │   off    │  ~15 cm
 *     2   │  5    0    0   │    64     │   off    │  ~50 cm
 *     3   │  7    1    0   │    90     │   off    │   ~1 m
 *     4   │  7    4    0   │    90     │   off    │   ~3 m
 *     5   │  7    7    0   │    90     │   off    │   ~5 m
 *     6   │  7    7    1   │    64     │   off    │   ~7 m
 *     7   │  7    7    3   │    32     │   off    │  ~10 m
 *     8   │  7    7    3   │    32     │   on     │  ~13 m
 *
 * KW007-S: max ~2 m; effective range ≈ KW007-L / 6.
 * Actual range varies with environment, target size, and motion speed.
 */
uint8_t KW007_SetDetectionRange(uint8_t range);

/** Set amplifier gains directly. amp1: 0-7, amp2: 0-7, amp3: 0-3. */
uint8_t KW007_SetGain(uint8_t amp1, uint8_t amp2, uint8_t amp3);

/** Set detection threshold 0-255. Higher = less sensitive. */
uint8_t KW007_SetThreshold(uint8_t threshold);

/** Set enhanced range mode. */
uint8_t KW007_SetEnhancedMode(bool enable);

/** Set GPO output hold time. */
uint8_t KW007_SetGPO_DelayDuration(KW007_DelayDuration delay);

/** Set slow speed detection. true = enabled. */
uint8_t KW007_SetSlowSpeedDetection(bool enable);

/** Set fast speed detection. false = OFF (default), true = ON. */
uint8_t KW007_SetFastSpeedDetection(bool enable);

/** Set system sampling rate. false = 1kHz (default), true = 500Hz. */
uint8_t KW007_SetSamplingRate(bool use500Hz);

KW007_Model KW007_GetModel(void);

#ifdef __cplusplus
}
#endif

#endif /* KW007_API_H */
