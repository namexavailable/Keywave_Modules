# Keywave KW007 Arduino Library v1.2.0

Arduino / ESP32 library for the Keywave KW007 5.8 GHz Doppler radar motion sensor.

This library is designed so you can install it directly in the Arduino IDE and start from the included examples. You do not need to rename, move, or manually copy the source files.

---

## 1. Install the library

1. Download `KW007_Arduino_v1.2.0.zip`.
2. Open **Arduino IDE**.
3. Select **Sketch > Include Library > Add .ZIP Library...**
4. Select the downloaded ZIP file.
5. Open **File > Examples > Keywave KW007 > BasicRead**.

If the example opens correctly, the library has been installed.

---

## 2. Hardware setup

### Important: Range1 pin

For I2C / software control, the **Range1 pin must be connected to GND through a protection resistor before power-up**.

If Range1 is not connected correctly, the KW007 stays in hardware pin-selection mode and will ignore I2C configuration commands.

### Power

Use **either** the module's 3.3 V input **or** 5 V input.

- Do not connect both power inputs at the same time.
- Never apply 5 V to the 3.3 V input.

---

## 3. Arduino Uno connection

For a classic Arduino Uno, the I2C pins are fixed:

| Arduino Uno | KW007 |
|---|---|
| A4 | SDA |
| A5 | SCL |
| GND | GND |
| 5V or 3.3V | Matching KW007 power input |

In the Arduino code, use:

```cpp
Wire.begin();
```

You do not need to specify A4 and A5 in software. The Arduino Uno Wire library uses those pins automatically.

---

## 4. First test: BasicRead

Open:

**File > Examples > Keywave KW007 > BasicRead**

Upload the example to your board, then open the **Serial Monitor** at `115200` baud.

### If the wiring is wrong

You may see:

```text
KW007_Init failed, status=0x20
```

This usually means the sensor did not acknowledge the I2C request.

Check:

- SDA and SCL wiring
- GND connection
- Power connection
- Range1 connection
- Sensor power

### If the connection is correct

You should see output similar to:

```text
KW007 Ready
Approaching=NO  Leaving=NO  RSSI=32
Approaching=NO  Leaving=NO  RSSI=132
```

Move toward the sensor and then move away from it to see the direction flags change.

---

## 5. MotionLED example

Open:

**File > Examples > Keywave KW007 > MotionLED**

On Arduino Uno, this example uses the built-in LED.

Expected behavior:

- **Approaching** -> LED blinks twice
- **Leaving** -> LED blinks once

The same event is also shown in the Serial Monitor.

---

## 6. Detecting motion without direction

If your application does not care whether a person is approaching or leaving, combine the two motion flags:

```cpp
bool motion = data.approaching || data.leaving;
```

When either direction is detected, `motion` becomes `true`.

> Note: this is a motion indication based on the approaching/leaving flags. It should not be treated as a dedicated stationary-presence or occupancy flag.

---

## 7. Basic example

```cpp
#include <Wire.h>
#include <KW007.h>

void setup()
{
    Serial.begin(115200);

    // Arduino Uno uses A4 = SDA and A5 = SCL automatically.
    Wire.begin();

    uint8_t status = KW007_Init();

    if (status != KW007_OK)
    {
        Serial.print("KW007 init failed, status=0x");
        Serial.println(status, HEX);

        while (true)
        {
            delay(1000);
        }
    }

    // Range setting 4 is approximately 3 m.
    KW007_SetDetectionRange(4);

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (data.ok)
    {
        Serial.print("Approaching=");
        Serial.print(data.approaching ? "YES" : "NO");

        Serial.print("  Leaving=");
        Serial.print(data.leaving ? "YES" : "NO");

        Serial.print("  RSSI=");
        Serial.println(data.rssi);
    }

    delay(128);
}
```

---

## 8. Detection range

The library provides preset detection-range settings:

```cpp
KW007_SetDetectionRange(range);
```

`range` can be from `1` to `8`.

Example:

```cpp
KW007_SetDetectionRange(4);
```

Range setting 4 is approximately 3 m under typical conditions.

Actual detection distance can vary with the sensor version, target size, installation, obstruction, power quality, and environment.

---

## 9. ESP32 and other Arduino-compatible boards

The same KW007 library can also be used with ESP32 and other Arduino-compatible platforms that use the Arduino `Wire` library.

### Arduino Uno / Nano / Mega

Use:

```cpp
Wire.begin();
```

These boards use their standard hardware I2C pins automatically.

### ESP32 family

Some ESP32 boards allow you to select the SDA and SCL pins.

For example:

```cpp
Wire.begin(SDA_PIN, SCL_PIN);
```

Replace `SDA_PIN` and `SCL_PIN` with the correct pins for your exact board.

Do not assume that all ESP32, ESP32-C3, or ESP32-S3 boards use the same pin numbers. Check the pinout for your board.

---

## 10. I2C address

KW007 uses the 7-bit I2C address:

```text
0x19
```

The library handles the address conversion internally. Application code normally does not need to handle the KW007 I2C address directly.

---

## 11. Reading sensor data

The main read function is:

```cpp
KW007_Data data = KW007_Read();
```

Available fields are:

```cpp
data.ok
data.approaching
data.leaving
data.isDay
data.rssi
```

### `data.ok`

Indicates whether the I2C read was successful.

```cpp
if (!data.ok) {
    // I2C read failed
}
```

### `data.approaching`

`true` when approaching motion is detected.

### `data.leaving`

`true` when leaving motion is detected.

### `data.isDay`

Reports the sensor's day / operating flag.

### `data.rssi`

Signal-strength value from `0` to `255`.

---

## 12. Troubleshooting

### `KW007_Init failed, status=0x20`

The sensor did not acknowledge the I2C request.

Check the wiring, power, Range1 connection, SDA, SCL, and GND.

### No approaching or leaving detection

Check:

1. `KW007_Init()` completed successfully.
2. The detection range is suitable.
3. The sensor is installed in the correct direction.
4. The target is moving within the detection area.
5. Range1 was connected correctly before power-up.

### Arduino Uno compiles but shows no sensor data

Compilation only confirms that the software built successfully. It does not confirm the physical sensor connection.

Check the Serial Monitor for initialization errors.

### ESP32 does not communicate

Check the SDA and SCL pin numbers for your exact ESP32 board and initialize Wire accordingly.

Example:

```cpp
Wire.begin(SDA_PIN, SCL_PIN);
```

---

## 13. Library contents

```text
KW007_Arduino_v1.2.0/
|
|-- library.properties
|-- keywords.txt
|-- README.md
|-- CHANGELOG.md
|-- LICENSE
|
|-- src/
|   |-- KW007.h
|   |-- KW007_api.c
|   |-- KW007_api.h
|   |-- kw007_reg.c
|   |-- kw007_reg.h
|   |-- kw007_hal.h
|   `-- kw007_hal_arduino.cpp
|
`-- examples/
    |-- BasicRead/
    |   `-- BasicRead.ino
    |
    `-- MotionLED/
        `-- MotionLED.ino
```

Most users only need:

- `BasicRead` to confirm the sensor is working
- `MotionLED` to see a simple application example
- `KW007.h` for normal application development

The files inside `src/` are installed and compiled automatically by Arduino IDE.

---

## 14. Typical application flow

A normal program only needs four steps:

```cpp
#include <Wire.h>
#include <KW007.h>

Wire.begin();
KW007_Init();
KW007_SetDetectionRange(4);
KW007_Data data = KW007_Read();
```

You do not need to access the sensor registers directly for normal use.

---

## 15. License

Copyright 2026 Keywave Technology.

First-party contents are licensed under the Apache License, Version 2.0.

See `LICENSE` for the complete license text.
