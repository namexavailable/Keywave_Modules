# KW007 Configuration Command Guide

This guide explains the main KW007 commands intended for normal application development.

For most Arduino users, include:

```cpp
#include <Wire.h>
#include <KW007.h>
```

Initialize I2C first, then initialize the sensor:

```cpp
Wire.begin();
KW007_Init();
```

---

## Quick Reference

| Command | Purpose | Options / Values |
|---|---|---|
| `KW007_Init()` | Initialize the sensor | No parameter |
| `KW007_Read()` | Read sensor status | Returns `KW007_Data` |
| `KW007_SetDetectionRange(range)` | Set detection range preset | `1` to `8` |
| `KW007_SetThreshold(value)` | Set detection threshold | `0` to `255` |
| `KW007_SetGPO_DelayDuration(delay)` | Set GPO output hold time | `DELAY_SETTING1` to `DELAY_SETTING4` |
| `KW007_SetSamplingRate(use500Hz)` | Set internal sampling rate | `false = 1 kHz`, `true = 500 Hz` |

---

# 1. `KW007_Init()`

## Purpose

Initializes the KW007 sensor and applies the required startup configuration.

This should normally be called once in `setup()` after I2C has been initialized.

## Usage

```cpp
uint8_t status = KW007_Init();

if (status != KW007_OK) {
    Serial.print("KW007 init failed, status=0x");
    Serial.println(status, HEX);
}
```

## Typical Arduino setup

```cpp
void setup()
{
    Serial.begin(115200);
    Wire.begin();

    uint8_t status = KW007_Init();

    if (status != KW007_OK) {
        Serial.println("KW007 initialization failed");
        while (1) {
            delay(1000);
        }
    }

    Serial.println("KW007 Ready");
}
```

## Important

For I2C/software control, the KW007 `Range1` pin must be connected to GND through a protection resistor before power-up.

If initialization returns:

```text
0x20
```

the sensor did not acknowledge the I2C request. Check wiring, power, SDA, SCL, GND, and the Range1 connection.

---

# 2. `KW007_Read()`

## Purpose

Reads the current motion status and RSSI value from the sensor.

## Usage

```cpp
KW007_Data data = KW007_Read();
```

The returned structure contains:

```cpp
data.ok
data.approaching
data.leaving
data.isDay
data.rssi
```

## Example

```cpp
KW007_Data data = KW007_Read();

if (data.ok) {
    Serial.print("Approaching=");
    Serial.print(data.approaching ? "YES" : "NO");

    Serial.print("  Leaving=");
    Serial.print(data.leaving ? "YES" : "NO");

    Serial.print("  RSSI=");
    Serial.println(data.rssi);
}
```

## Detect motion regardless of direction

If you only need to know whether motion is detected:

```cpp
bool motion = data.approaching || data.leaving;
```

This combines both direction flags.

> Note: this is a motion indication. It is not a dedicated stationary-presence or occupancy flag.

---

# 3. `KW007_SetDetectionRange(range)`

## Purpose

Sets a predefined detection-range configuration.

This command automatically adjusts the sensor gain, threshold, and enhanced-range setting for the selected preset.

## Syntax

```cpp
KW007_SetDetectionRange(range);
```

## Valid values (base on your sensor model)

| Range setting | Approximate distance |
|---:|---:|
| `1` | ~15 cm |
| `2` | ~50 cm |
| `3` | ~1 m |
| `4` | ~3 m |
| `5` | ~5 m |
| `6` | ~7 m |
| `7` | ~10 m |
| `8` | ~13 m, enhanced mode | by this command KW007_SetEnhancedMode(true);

Example:

```cpp
KW007_SetDetectionRange(4);
```

This selects approximately 3 m detection range under typical conditions.

## Recommended use

Use the shortest range that covers your required detection area.

Example:

```cpp
if (KW007_SetDetectionRange(4) != KW007_OK) {
    Serial.println("Failed to set detection range");
}
```

## Sensor variant limits

The actual usable range depends on the KW007 version.

According to the SDK:

```text
KW007-S   max approximately 2 m
KW007-SE  max approximately 4 m
```

Actual range also depends on installation, target size, obstruction, motion, power quality, and environment.

---

# 4. `KW007_SetThreshold(value)`

## Purpose

Sets the motion-detection threshold directly.

The threshold controls how strong the received signal must be before the sensor considers it a valid detection.

## Syntax

```cpp
KW007_SetThreshold(value);
```

## Valid values

```text
0 to 255
```

## General behavior

```text
Lower threshold  -> more sensitive
Higher threshold -> less sensitive
```

Example:

```cpp
KW007_SetThreshold(90);
```

## Usage example

```cpp
uint8_t status = KW007_SetThreshold(90);

if (status != KW007_OK) {
    Serial.println("Failed to set threshold");
}
```

## Important

Normally, `KW007_SetDetectionRange()` is easier to use because it selects gain and threshold together.

Use `KW007_SetThreshold()` when you want to fine-tune sensitivity for your own installation.

Changing gain or installation conditions can change the ideal threshold.

---

# 5. `KW007_SetGPO_DelayDuration(delay)`

## Purpose

Sets how long the KW007 GPO output remains active after motion stops.

This setting controls the hardware GPO hold time.

## Syntax

```cpp
KW007_SetGPO_DelayDuration(delay);
```

## Available settings

The actual delay depends on the KW007 sensor variant.

| Setting | KW007-SE |
|---|---:|---:|
| `DELAY_SETTING1` | 16 s | 
| `DELAY_SETTING2` | 32 s | 
| `DELAY_SETTING3` | 1 s | 
| `DELAY_SETTING4` | 64 s | 

## Example

```cpp
KW007_SetGPO_DelayDuration(DELAY_SETTING3);
```

For both KW007-S and KW007-L / KW007-SE, this selects approximately 1 second.

## Error handling example

```cpp
uint8_t status = KW007_SetGPO_DelayDuration(DELAY_SETTING3);

if (status != KW007_OK) {
    Serial.println("Failed to set GPO delay");
}
```

## Important

This setting applies to the KW007 hardware GPO output.

If your application only reads motion information over I2C using `KW007_Read()`, you may not need to change the GPO delay.

---

# 6. `KW007_SetSamplingRate(use500Hz)`

## Purpose

Sets the KW007 internal sampling rate.

## Syntax

```cpp
KW007_SetSamplingRate(use500Hz);
```

## Options

| Value | Sampling rate |
|---|---:|
| `false` | 1 kHz |
| `true` | 500 Hz |

## Examples

Use the default 1 kHz setting:

```cpp
KW007_SetSamplingRate(false);
```

Use 500 Hz:

```cpp
KW007_SetSamplingRate(true);
```

## Recommended use

For most applications, leave the sampling rate at the default unless you have a specific reason to change it.

---

# Example: Typical Configuration

```cpp
#include <Wire.h>
#include <KW007.h>

void setup()
{
    Serial.begin(115200);

    // Arduino Uno uses A4=SDA and A5=SCL automatically.
    Wire.begin();

    // 1. Initialize the sensor
    if (KW007_Init() != KW007_OK) {
        Serial.println("KW007 initialization failed");
        while (1) {
            delay(1000);
        }
    }

    // 2. Set approximately 3 m detection range
    if (KW007_SetDetectionRange(4) != KW007_OK) {
        Serial.println("Failed to set detection range");
    }

    // 3. Optional: set GPO hold time
    KW007_SetGPO_DelayDuration(DELAY_SETTING3);

    // 4. Optional: keep default 1 kHz sampling rate
    KW007_SetSamplingRate(false);

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (data.ok) {
        bool motion = data.approaching || data.leaving;

        if (data.approaching) {
            Serial.println("Approaching");
        }

        if (data.leaving) {
            Serial.println("Leaving");
        }

        if (motion) {
            Serial.println("Motion detected");
        }

        Serial.print("RSSI=");
        Serial.println(data.rssi);
    }

    delay(128);
}
```

---

# Recommended Starting Point

For most users, the simplest configuration is:

```cpp
Wire.begin();
KW007_Init();
KW007_SetDetectionRange(4);
```

Then read the sensor using:

```cpp
KW007_Data data = KW007_Read();
```

Only change `Threshold`, `GPO Delay`, or `Sampling Rate` when your application needs additional tuning.

---

# Error Codes

Common return values used by the SDK:

| Code | Meaning |
|---|---|
| `KW007_OK` / `0x00` | Success |
| `KW007_ERR_I2C` / `0x10` | I2C communication error |
| `KW007_ERR_NO_DEVICE` / `0x20` | Sensor did not acknowledge |
| `KW007_ERR_PARAM` / `0x30` | Invalid parameter |
| `KW007_ERR_VERIFY` / `0x40` | Register read-back did not match |

---

# License

Copyright 2026 Keywave Technology.

Licensed under the Apache License, Version 2.0.

See `LICENSE` for the complete license text.
