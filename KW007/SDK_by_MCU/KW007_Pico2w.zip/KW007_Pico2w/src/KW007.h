/**
 * ============================================================
 *  KW007.h — Arduino Library Entry Point
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.2
 *  Released: 2026-08-24
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 *
 *  Arduino users normally include only this file.
 * ============================================================
 */

#ifndef KEYWAVE_KW007_H
#define KEYWAVE_KW007_H

#include "KW007_api.h"

#endif /* KEYWAVE_KW007_H */
