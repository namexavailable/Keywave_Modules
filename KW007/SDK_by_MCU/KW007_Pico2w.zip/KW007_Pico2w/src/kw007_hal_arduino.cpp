/**
 * ============================================================
 *  kw007_hal_arduino.cpp — HAL for Arduino / ESP32
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.2
 *  Released: 2026-08-24
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 *
 *  Usage:
 *    1. Add this file together with KW007_api.h / KW007_api.c
 *    2. Call Wire.begin() in setup() for boards with fixed I2C pins
 *       (for example Arduino Uno / Nano / Mega).
 *       On ESP32-family boards, Wire.begin(SDA_PIN, SCL_PIN) may be
 *       used when custom I2C pins are required.
 *    3. Call KW007_Init()
 *
 *  Common examples:
 *    Arduino Uno    : Wire.begin();        // SDA=A4, SCL=A5
 *    Arduino Mega   : Wire.begin();        // SDA=20, SCL=21
 *    ESP32          : Wire.begin(SDA, SCL);
 *    ESP32-C3 / S3  : Wire.begin(SDA, SCL);
 *
 * ============================================================
 */

#include <Arduino.h>
#include <Wire.h>
#include "kw007_hal.h"

extern "C" {

/* Arduino Wire uses the 7-bit I2C address.
 * KW007 devAddr is supplied in 8-bit bus-byte form (0x32),
 * therefore shift right by one:
 *
 *   0x32 >> 1 = 0x19
 *
 * Explicitly cast to uint8_t to avoid requestFrom() overload
 * ambiguity on AVR-based Arduino boards such as the Uno.
 */
#define ADDR7(addr8) ((uint8_t)((addr8) >> 1))

uint8_t KW007_HAL_WriteReg(uint8_t devAddr, uint8_t reg, uint8_t data)
{
    Wire.beginTransmission(ADDR7(devAddr));
    Wire.write(reg);
    Wire.write(data);

    uint8_t status = Wire.endTransmission();

    if (status == 0)
        return KW007_OK;

    if (status == 2)
        return KW007_ERR_NO_DEVICE;

    return KW007_ERR_I2C;
}

uint8_t KW007_HAL_ReadReg(uint8_t devAddr, uint8_t reg, uint8_t *data)
{
    if (!data)
        return KW007_ERR_PARAM;

    Wire.beginTransmission(ADDR7(devAddr));
    Wire.write(reg);

    uint8_t status = Wire.endTransmission(false);

    if (status == 2)
        return KW007_ERR_NO_DEVICE;

    if (status != 0)
        return KW007_ERR_I2C;

    uint8_t received = Wire.requestFrom(
        (uint8_t)ADDR7(devAddr),
        (uint8_t)1
    );

    if (received != 1 || !Wire.available())
        return KW007_ERR_I2C;

    *data = (uint8_t)Wire.read();

    return KW007_OK;
}

uint8_t KW007_HAL_WriteBlock(uint8_t devAddr,
                             uint8_t startReg,
                             uint8_t *data,
                             uint8_t len)
{
    if (!data || len == 0)
        return KW007_ERR_PARAM;

    Wire.beginTransmission(ADDR7(devAddr));
    Wire.write(startReg);

    size_t written = Wire.write(data, len);

    if (written != len)
        return KW007_ERR_I2C;

    uint8_t status = Wire.endTransmission();

    if (status == 0)
        return KW007_OK;

    if (status == 2)
        return KW007_ERR_NO_DEVICE;

    return KW007_ERR_I2C;
}

void KW007_HAL_DelayMs(uint32_t ms)
{
    delay(ms);
}

} /* extern "C" */
