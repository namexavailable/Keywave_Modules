# Keywave KW007 Raspberry Pi Pico 2 W Arduino Library v1.2.0

Arduino IDE guide for using the Keywave KW007 5.8 GHz Doppler radar motion sensor with Raspberry Pi Pico 2 W.

This package uses the same KW007 Arduino library as the Arduino Uno and ESP32 versions.  
For Pico 2 W, the main difference is how the I2C pins are selected.

---

## 1. Install the library

1. Open **Arduino IDE**.
2. Make sure your Raspberry Pi Pico 2 W board support package is installed.
3. Install the KW007 library using:

   **Sketch > Include Library > Add .ZIP Library...**

4. Select the KW007 ZIP file.
5. Open one of the Pico examples:

   - `Pico2W_BasicRead`
   - `Pico2W_MotionLED`

You do not need to rename or manually copy any source files.

---

## 2. Hardware setup

### Recommended connection

| Raspberry Pi Pico 2 W | KW007 |
|---|---|
| GP4 | SDA |
| GP5 | SCL |
| GND | GND |
| 3V3 | KW007 3.3 V input |

For I2C / software control, also connect:

```text
KW007 Range1 -> approximately 1 kOhm resistor -> GND
```

### Important power note

Use either the KW007 **3.3 V input** or **5 V input**, never both.

For Pico 2 W, using the KW007 **3.3 V input** is recommended.

Never apply 5 V to the KW007 3.3 V input.

---

## 3. Pico 2 W I2C setup

For the examples in this package:

```cpp
#define SDA_PIN 4
#define SCL_PIN 5
```

The I2C interface is started with:

```cpp
Wire.setSDA(SDA_PIN);
Wire.setSCL(SCL_PIN);
Wire.begin();
```

So with the default example:

```text
GP4 = SDA
GP5 = SCL
```

If you choose different Pico GPIO pins, update `SDA_PIN` and `SCL_PIN` in your sketch.

---

## 4. First test: Pico2W_BasicRead

Open:

**File > Examples > Keywave KW007 > Pico2W_BasicRead**

Upload the sketch and open the Serial Monitor at:

```text
115200 baud
```

### Normal output

You should see:

```text
KW007 Pico 2 W BasicRead
KW007 Ready
Approaching=NO  Leaving=NO  RSSI=32
Approaching=YES Leaving=NO  RSSI=140
Approaching=NO  Leaving=YES RSSI=118
```

Move toward and away from the sensor to test the direction flags.

---

## 5. If initialization fails

You may see:

```text
KW007_Init failed, status=0x20
```

This means the KW007 did not acknowledge the I2C request.

Check:

1. GP4 is connected to SDA.
2. GP5 is connected to SCL.
3. Pico and KW007 share GND.
4. KW007 power is connected correctly.
5. Range1 is connected to GND through approximately 1 kOhm.
6. The sensor was powered after the Range1 connection was made.

---

## 6. BasicRead example structure

The important Pico-specific section is:

```cpp
#include <Wire.h>
#include <KW007.h>

#define SDA_PIN 4
#define SCL_PIN 5

void setup()
{
    Serial.begin(115200);

    Wire.setSDA(SDA_PIN);
    Wire.setSCL(SCL_PIN);
    Wire.begin();

    if (KW007_Init() != KW007_OK)
    {
        Serial.println("KW007 initialization failed");
        while (1)
        {
            delay(1000);
        }
    }

    KW007_SetDetectionRange(4);

    Serial.println("KW007 Ready");
}
```

Then read the sensor with:

```cpp
KW007_Data data = KW007_Read();
```

---

## 7. MotionLED example

Open:

**File > Examples > Keywave KW007 > Pico2W_MotionLED**

The example uses:

```cpp
#define LED_PIN LED_BUILTIN
```

Expected behavior:

- **Approaching** -> LED blinks twice
- **Leaving** -> LED blinks once

The direction event is also printed in the Serial Monitor.

If your selected Pico 2 W Arduino core does not support `LED_BUILTIN`, replace it with a GPIO connected to an external LED.

Example:

```cpp
#define LED_PIN 15
```

Then connect:

```text
GP15 -> resistor -> LED anode (+)
LED cathode (-) -> GND
```

---

## 8. Detect motion without direction

If your application only needs motion detection and does not care about direction:

```cpp
bool motion = data.approaching || data.leaving;
```

When either flag is active:

```cpp
motion == true
```

> This is a motion indication. It is not a dedicated stationary-presence or occupancy flag.

---

## 9. Detection range

Use:

```cpp
KW007_SetDetectionRange(range);
```

Available range presets:

| Setting | Approximate distance |
|---:|---:|
| `1` | ~15 cm |
| `2` | ~50 cm |
| `3` | ~1 m |
| `4` | ~3 m |
| `5` | ~5 m |
| `6` | ~7 m |
| `7` | ~10 m |
| `8` | ~13 m, enhanced mode |

Example:

```cpp
KW007_SetDetectionRange(4);
```

This selects approximately 3 m under typical conditions.

Use the shortest range that covers your application area.

---

## 10. Reading sensor data

Use:

```cpp
KW007_Data data = KW007_Read();
```

Available fields:

| Field | Meaning |
|---|---|
| `data.ok` | I2C read succeeded |
| `data.approaching` | approaching motion detected |
| `data.leaving` | leaving motion detected |
| `data.isDay` | KW007 day/night flag |
| `data.rssi` | signal strength, 0-255 |

Example:

```cpp
if (data.ok)
{
    if (data.approaching)
    {
        Serial.println("Approaching");
    }

    if (data.leaving)
    {
        Serial.println("Leaving");
    }

    Serial.print("RSSI=");
    Serial.println(data.rssi);
}
```

---

## 11. Common KW007 commands

```cpp
KW007_Init();
KW007_Read();
KW007_SetDetectionRange(range);
KW007_SetThreshold(value);
KW007_SetGPO_DelayDuration(delay);
KW007_SetSamplingRate(use500Hz);
```

For most Pico 2 W applications, start with:

```cpp
Wire.setSDA(4);
Wire.setSCL(5);
Wire.begin();

KW007_Init();
KW007_SetDetectionRange(4);
```

Then:

```cpp
KW007_Data data = KW007_Read();
```

---

## 12. I2C address

KW007 uses the 7-bit I2C address:

```text
0x19
```

The library handles the address internally.

Normal application code does not need to set the KW007 I2C address manually.

---

## 13. Troubleshooting

### BasicRead works but MotionLED does not

The sensor communication may still be working correctly.

Check:

- whether `LED_BUILTIN` is supported by your Pico 2 W Arduino core
- whether the onboard LED is available as a normal GPIO LED
- whether an external LED should be used instead

### No approaching or leaving result

Check:

1. `KW007_Init()` completed successfully.
2. Detection range is suitable.
3. Sensor orientation is correct.
4. The target is moving within the sensing area.

### RSSI changes but direction does not

Try moving clearly toward or away from the sensor instead of moving sideways.

---

## 14. Library structure

A Pico-ready package can use:

```text
KW007_Pico2W_v1.2.0/
|
|-- library.properties
|-- README.md
|-- LICENSE
|
|-- src/
|   |-- KW007.h
|   |-- KW007_api.c
|   |-- KW007_api.h
|   |-- kw007_reg.c
|   |-- kw007_reg.h
|   |-- kw007_hal.h
|   `-- kw007_hal_arduino.cpp
|
`-- examples/
    |-- Pico2W_BasicRead/
    |   `-- Pico2W_BasicRead.ino
    |
    `-- Pico2W_MotionLED/
        `-- Pico2W_MotionLED.ino
```

The same `src/` files can be shared with the Arduino and ESP32 packages.

---

## 15. License

Copyright 2026 Keywave Technology.

Licensed under the Apache License, Version 2.0.

See `LICENSE` for the complete license text.
