/*
 * ============================================================
 *  Pico2W_BasicRead.ino — KW007 Basic Read Example for Pico 2 W
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007 Arduino Library v1.2.0
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 *
 *  Example wiring:
 *    Pico 2 W GP4  -> KW007 SDA
 *    Pico 2 W GP5  -> KW007 SCL
 *    Pico 2 W GND  -> KW007 GND
 *    Pico 2 W 3V3  -> KW007 3.3V input
 *
 *  IMPORTANT:
 *    - KW007 Range1 must be connected to GND through
 *      approximately 1 kOhm before power-up for I2C mode.
 *    - Use either the KW007 3.3V input or 5V input, never both.
 * ============================================================
 */

#include <Wire.h>
#include <KW007.h>

#define SDA_PIN 4
#define SCL_PIN 5

void setup()
{
    Serial.begin(115200);

    // Give the USB serial monitor a moment to connect.
    delay(1000);

    Serial.println("KW007 Pico 2 W BasicRead");

    // Pico 2 W: assign I2C pins before starting Wire.
    Wire.setSDA(SDA_PIN);
    Wire.setSCL(SCL_PIN);
    Wire.begin();

    uint8_t status = KW007_Init();

    if (status != KW007_OK)
    {
        Serial.print("KW007_Init failed, status=0x");
        Serial.println(status, HEX);

        while (true)
        {
            delay(1000);
        }
    }

    // Range setting 4 is approximately 3 m under typical conditions.
    status = KW007_SetDetectionRange(4);

    if (status != KW007_OK)
    {
        Serial.print("KW007_SetDetectionRange failed, status=0x");
        Serial.println(status, HEX);

        while (true)
        {
            delay(1000);
        }
    }

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (!data.ok)
    {
        Serial.println("KW007 read error");
        delay(128);
        return;
    }

    Serial.print("Approaching=");
    Serial.print(data.approaching ? "YES" : "NO");

    Serial.print("  Leaving=");
    Serial.print(data.leaving ? "YES" : "NO");

    Serial.print("  RSSI=");
    Serial.println(data.rssi);

    delay(128);
}
