# Changelog

## 1.2.0 Arduino package

- Packaged the KW007 v1.2 core driver as an installable Arduino library.
- Added `KW007.h` as the Arduino-friendly public include.
- Added Arduino IDE examples: `BasicRead` and `MotionLED`.
- Added Arduino Library Manager metadata (`library.properties`) and keywords.
- Preserved Apache-2.0 license headers on supplied Keywave source files.
- Corrected the malformed `KW007_SDK_VERSION` macro line in `KW007_api.h` so the header compiles.
- Added an explicit `Arduino.h` include in the Arduino HAL.
- Arduino HAL now maps Wire address-NACK status to `KW007_ERR_NO_DEVICE`, consistent with the public API documentation.
