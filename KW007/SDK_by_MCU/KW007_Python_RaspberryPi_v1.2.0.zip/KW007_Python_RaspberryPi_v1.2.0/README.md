# Keywave KW007 Python SDK v1.2.0

Python 3 driver for the Keywave KW007 5.8 GHz Doppler radar motion sensor on Raspberry Pi 4 / 5 and other Linux systems with an I2C interface.

This package is intended for Raspberry Pi OS and uses `smbus2`.

## 1. Hardware connection

Typical Raspberry Pi 4 / 5 I2C connection:

| Raspberry Pi | KW007 |
|---|---|
| Pin 3 / GPIO2 | SDA |
| Pin 5 / GPIO3 | SCL |
| GND | GND |
| 3.3V | KW007 3.3V input |

For I2C/software control, connect the KW007 `Range1` pin to GND through approximately 1 kOhm before power-up.

Use either the KW007 3.3V input or 5V input, never both. 3.3V is recommended.

## 2. Enable I2C on Raspberry Pi

Enable I2C in Raspberry Pi OS, then reboot if required.

You can verify the device with:

```bash
i2cdetect -y 1
```

The KW007 should appear at:

```text
19
```

because its 7-bit I2C address is `0x19`.

## 3. Install Python dependency

```bash
python3 -m pip install smbus2
```

## 4. Install / use the SDK

Place the `kw007` folder in your project, or install the package locally.

Basic import:

```python
from kw007 import KW007
```

## 5. First test

Run:

```bash
python3 examples/basic_read.py
```

Expected output:

```text
KW007 Ready
Approaching=NO  Leaving=NO  RSSI=32
Approaching=YES Leaving=NO  RSSI=140
Approaching=NO  Leaving=YES RSSI=118
```

## 6. Basic usage

```python
import time
from kw007 import KW007

with KW007(bus=1) as sensor:
    sensor.init()
    sensor.set_detection_range(4)

    while True:
        data = sensor.read()

        print(data.approaching, data.leaving, data.rssi)

        time.sleep(0.128)
```

## 7. Motion without direction

```python
if data.motion:
    print("Motion detected")
```

`data.motion` is true when either approaching or leaving motion is detected.

It is not a stationary-presence / occupancy flag.

## 8. Detection range

```python
sensor.set_detection_range(4)
```

| Setting | Approximate distance |
|---:|---:|
| 1 | ~15 cm |
| 2 | ~50 cm |
| 3 | ~1 m |
| 4 | ~3 m |
| 5 | ~5 m |
| 6 | ~7 m |
| 7 | ~10 m |
| 8 | ~13 m, enhanced mode |

Use the shortest range that covers the required area.

## 9. Main commands

```python
sensor.init()
sensor.read()
sensor.set_detection_range(4)
sensor.set_threshold(90)
sensor.set_enhanced_mode(True)
sensor.set_gpo_delay(16)
sensor.set_slow_speed_detection(True)
sensor.set_fast_speed_detection(True)
sensor.set_sampling_rate(1000)
```

### GPO delay — KW007-SE

Valid values are:

```python
sensor.set_gpo_delay(1)
sensor.set_gpo_delay(16)
sensor.set_gpo_delay(32)
sensor.set_gpo_delay(64)
```

The KW007-SE register mapping is:

| Hold time | Reg29[2:1] |
|---:|---|
| 16 s | 00 |
| 32 s | 01 |
| 1 s | 10 |
| 64 s | 11 |

### Sampling rate

```python
sensor.set_sampling_rate(1000)  # 1 kHz, default
sensor.set_sampling_rate(500)   # 500 Hz
```

This controls the KW007 internal Doppler processing sample rate. It is not the Python polling rate.

For normal applications, keep the default 1 kHz setting.

## 10. Returned data

```python
data = sensor.read()
```

Available fields:

```python
data.ok
data.approaching
data.leaving
data.is_day
data.rssi
data.motion
```

## 11. Troubleshooting

If the driver reports that KW007 did not respond:

1. Check SDA and SCL.
2. Check common GND.
3. Check sensor power.
4. Confirm Range1 is pulled to GND through approximately 1 kOhm before power-up.
5. Run `i2cdetect -y 1` and confirm address `0x19`.
6. Confirm `/dev/i2c-1` exists.

## 12. Package contents

```text
KW007_Python_RaspberryPi_v1.2.0/
|
|-- README.md
|-- requirements.txt
|-- LICENSE
|
|-- kw007/
|   |-- __init__.py
|   `-- kw007.py
|
`-- examples/
    |-- basic_read.py
    `-- motion_read.py
```

## 13. License

Copyright 2026 Keywave Technology.

Licensed under the Apache License, Version 2.0.

See `LICENSE`.
