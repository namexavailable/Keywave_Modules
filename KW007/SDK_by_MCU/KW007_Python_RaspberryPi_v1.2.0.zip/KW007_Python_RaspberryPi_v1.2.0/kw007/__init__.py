"""
Keywave KW007 Python SDK
Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

from .kw007 import (
    KW007,
    KW007Data,
    KW007Error,
    KW007NoDeviceError,
    KW007_I2C_ADDRESS,
)

__all__ = [
    "KW007",
    "KW007Data",
    "KW007Error",
    "KW007NoDeviceError",
    "KW007_I2C_ADDRESS",
]

__version__ = "1.2.0"
