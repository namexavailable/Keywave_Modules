"""
============================================================
 kw007.py — MicroPython Driver
 Keywave KW007 5.8GHz Doppler Radar Sensor
 KW007 MicroPython SDK v1.2.0
 Released: 2026-09

 Copyright 2026 Keywave Technology
 SPDX-License-Identifier: Apache-2.0
 Licensed under the Apache License, Version 2.0; see LICENSE.

 Designed for MicroPython boards using machine.I2C.
 Tested usage pattern targets Raspberry Pi Pico / Pico 2 W.
============================================================
"""

KW007_I2C_ADDRESS = 0x19
KW007_REG_COUNT = 31

REG_VCO_FUSE = 0x01
REG_RSSI = 0x05
REG_FLAGS = 0x06
REG_MANUAL_MODE = 0x09
REG_VCO_CTRL = 0x0C
REG_AMP1_GAIN = 0x13
REG_AMP2_AMP3_GAIN = 0x14
REG_SLOW_SPEED = 0x15
REG_ENHANCED_MODE = 0x18
REG_THRESHOLD = 0x1B
REG_GPO_DELAY = 0x1D

FLAG_DAY_NIGHT = 1 << 3
FLAG_APPROACHING = 1 << 2
FLAG_LEAVING = 1 << 1

MASK_EFUSE_MODE = 0x20
MASK_SAMPLE_RATE = 0x80
MASK_RESERVED_R12 = 0x40
MASK_VCO_BANK = 0x3F
MASK_AMP1 = 0xE0
MASK_AMP2 = 0x07
MASK_AMP3 = 0x18
MASK_SLOW_DET = 0x20
MASK_ENHANCED = 0x40
MASK_FAST_SPEED_DET = 0x01
MASK_GPO_DELAY = 0x06

DEFAULT_REGS = bytes([
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0xFC, 0x30, 0x88, 0x03, 0x54, 0x4B, 0x68, 0x55,
    0x98, 0xA0, 0x00, 0xEA, 0xF7, 0x5F, 0x02, 0x30,
    0xA0, 0x20, 0x9A, 0x30, 0x55, 0x75, 0x42
])

_RANGE_PRESETS = {
    1: (3, 0, 0, 45, False),
    2: (5, 0, 0, 64, False),
    3: (7, 1, 0, 90, False),
    4: (7, 4, 0, 90, False),
    5: (7, 7, 0, 90, False),
    6: (7, 7, 1, 64, False),
    7: (7, 7, 3, 32, False),
    8: (7, 7, 3, 32, True),
}

_GPO_DELAY_SECONDS_TO_SETTING = {
    16: 0,
    32: 1,
    1: 2,
    64: 3,
}


class KW007:
    def __init__(self, i2c, address=KW007_I2C_ADDRESS):
        self.i2c = i2c
        self.address = address

    def _write_reg(self, reg, value):
        self.i2c.writeto_mem(self.address, reg, bytes([value & 0xFF]))

    def _read_reg(self, reg):
        return self.i2c.readfrom_mem(self.address, reg, 1)[0]

    def _write_block(self, start_reg, data):
        # Use a single transaction: first byte is register address,
        # followed by consecutive register data.
        payload = bytes([start_reg]) + bytes(data)
        self.i2c.writeto(self.address, payload)

    def _rmw(self, reg, clear_mask, set_bits):
        value = self._read_reg(reg)
        value &= (~clear_mask) & 0xFF
        value |= set_bits & 0xFF
        self._write_reg(reg, value)

    def scan_present(self):
        return self.address in self.i2c.scan()

    def init(self):
        """
        Official KW007 initialization sequence:
          1. Reg9 = 0x10 (fuse mode)
          2. Read Reg1[5:0] factory VCO bank
          3. Put VCO bank into Reg12[5:0]
          4. Write Reg0..Reg30 with Reg9 = 0x30
        """
        self._write_reg(
            REG_MANUAL_MODE,
            DEFAULT_REGS[REG_MANUAL_MODE] & ~MASK_EFUSE_MODE
        )

        vco_bank = self._read_reg(REG_VCO_FUSE) & MASK_VCO_BANK

        regs = bytearray(DEFAULT_REGS)
        regs[REG_VCO_CTRL] = (
            (DEFAULT_REGS[REG_VCO_CTRL] & MASK_SAMPLE_RATE)
            | MASK_RESERVED_R12
            | vco_bank
        )

        self._write_block(0x00, regs)

    def read(self):
        flags = self._read_reg(REG_FLAGS)
        rssi = self._read_reg(REG_RSSI)

        approaching = bool(flags & FLAG_APPROACHING)
        leaving = bool(flags & FLAG_LEAVING)

        return {
            "ok": True,
            "approaching": approaching,
            "leaving": leaving,
            "is_day": bool(flags & FLAG_DAY_NIGHT),
            "rssi": rssi,
            "motion": approaching or leaving,
        }

    def set_detection_range(self, range_level):
        if range_level not in _RANGE_PRESETS:
            raise ValueError("range_level must be 1..8")

        amp1, amp2, amp3, threshold, enhanced = _RANGE_PRESETS[range_level]
        self.set_gain(amp1, amp2, amp3)
        self.set_threshold(threshold)
        self.set_enhanced_mode(enhanced)

    def set_gain(self, amp1, amp2, amp3):
        if not (0 <= amp1 <= 7):
            raise ValueError("amp1 must be 0..7")
        if not (0 <= amp2 <= 7):
            raise ValueError("amp2 must be 0..7")
        if not (0 <= amp3 <= 3):
            raise ValueError("amp3 must be 0..3")

        r19 = self._read_reg(REG_AMP1_GAIN)
        r20 = self._read_reg(REG_AMP2_AMP3_GAIN)

        r19 = (r19 & ~MASK_AMP1) | (amp1 << 5)
        r20 = (r20 & ~(MASK_AMP2 | MASK_AMP3)) | (amp3 << 3) | amp2

        self._write_reg(REG_AMP1_GAIN, r19)
        self._write_reg(REG_AMP2_AMP3_GAIN, r20)

    def set_threshold(self, threshold):
        if not 0 <= threshold <= 255:
            raise ValueError("threshold must be 0..255")
        self._write_reg(REG_THRESHOLD, threshold)

    def set_enhanced_mode(self, enable):
        self._rmw(
            REG_ENHANCED_MODE,
            MASK_ENHANCED,
            MASK_ENHANCED if enable else 0
        )

    def set_gpo_delay(self, seconds):
        """
        KW007-SE GPO hold times:
          16s -> Reg29[2:1] = 00
          32s -> Reg29[2:1] = 01
           1s -> Reg29[2:1] = 10
          64s -> Reg29[2:1] = 11
        """
        if seconds not in _GPO_DELAY_SECONDS_TO_SETTING:
            raise ValueError("GPO delay must be 1, 16, 32, or 64 seconds")

        setting = _GPO_DELAY_SECONDS_TO_SETTING[seconds]
        self._rmw(REG_GPO_DELAY, MASK_GPO_DELAY, setting << 1)

    def set_slow_speed_detection(self, enable):
        # Reg21 bit5 is inverted: 0 = enabled, 1 = disabled.
        self._rmw(
            REG_SLOW_SPEED,
            MASK_SLOW_DET,
            0 if enable else MASK_SLOW_DET
        )

    def set_fast_speed_detection(self, enable):
        self._rmw(
            REG_GPO_DELAY,
            MASK_FAST_SPEED_DET,
            MASK_FAST_SPEED_DET if enable else 0
        )

    def set_sampling_rate(self, hz):
        if hz not in (500, 1000):
            raise ValueError("Sampling rate must be 500 or 1000 Hz")

        self._rmw(
            REG_VCO_CTRL,
            MASK_SAMPLE_RATE,
            MASK_SAMPLE_RATE if hz == 500 else 0
        )

    def write_reg(self, reg, value):
        self._write_reg(reg, value)

    def read_reg(self, reg):
        return self._read_reg(reg)

    def verify_reg(self, reg, mask, expected):
        value = self._read_reg(reg)
        return (value & mask) == (expected & mask)
