"""
KW007 MicroPython Basic Read Example
Raspberry Pi Pico / Pico 2 W

Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

from machine import I2C, Pin
from time import sleep_ms
from kw007 import KW007

SDA_PIN = 4
SCL_PIN = 5

i2c = I2C(
    0,
    sda=Pin(SDA_PIN),
    scl=Pin(SCL_PIN),
    freq=400000
)

print("I2C scan:", [hex(x) for x in i2c.scan()])

sensor = KW007(i2c)

if not sensor.scan_present():
    raise RuntimeError("KW007 not found at I2C address 0x19")

sensor.init()
sensor.set_detection_range(4)

print("KW007 Ready")

while True:
    data = sensor.read()

    print(
        "Approaching={0}  Leaving={1}  RSSI={2}".format(
            "YES" if data["approaching"] else "NO",
            "YES" if data["leaving"] else "NO",
            data["rssi"]
        )
    )

    sleep_ms(128)
