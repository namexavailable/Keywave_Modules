var kw007__reg_8c =
[
    [ "KW007_ReadReg", "kw007__reg_8c.html#ae099312bfc9df230040d59e4dddaeaf3", null ],
    [ "kw007_reg_read", "kw007__reg_8c.html#a790d74c17528a0df23c93da30f5bddf0", null ],
    [ "kw007_reg_rmw", "kw007__reg_8c.html#af9447d21aba2ad8b77e6bb5d27af78a2", null ],
    [ "kw007_reg_write", "kw007__reg_8c.html#ac9e8d36691755817140aed416d197725", null ],
    [ "kw007_reg_write_block", "kw007__reg_8c.html#a4b8a88b14e8cee306801906e13d6cf54", null ],
    [ "KW007_VerifyReg", "kw007__reg_8c.html#ad71242197b20165a8d5ac0f9c644a2a9", null ],
    [ "KW007_WriteReg", "kw007__reg_8c.html#aa840a06c6ba9643bc6d09bb52e5081ba", null ],
    [ "kw007_default_regs", "kw007__reg_8c.html#a9fef6ad3c1a6df0a988b037f44f17e8a", null ]
];