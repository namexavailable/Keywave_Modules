var _k_w007__api_8h =
[
    [ "KW007_Data", "struct_k_w007___data.html", "struct_k_w007___data" ],
    [ "KW007_SDK_VERSION", "_k_w007__api_8h.html#a7b2fbc9bc0c6d8a332affd084abee308", null ],
    [ "KW007_SDK_VERSION_AT", "_k_w007__api_8h.html#a3065810801b7932cbe6dfadb7aaeed27", null ],
    [ "KW007_SDK_VERSION_MAJOR", "_k_w007__api_8h.html#ae5e2057ecf7f8b196c00bd9c009df148", null ],
    [ "KW007_SDK_VERSION_MINOR", "_k_w007__api_8h.html#a7d9b0e1ad196c54b42e363762fe1ffdf", null ],
    [ "KW007_SDK_VERSION_STRING", "_k_w007__api_8h.html#ac2a61f20f64d29afe2fdde296fdf048e", null ],
    [ "KW007_DelayDuration", "_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333", [
      [ "DELAY_SETTING1", "_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a36934368bc392e1b060de6b32adc4a39", null ],
      [ "DELAY_SETTING2", "_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a186dccd0e4017da5556eaf743de0b07e", null ],
      [ "DELAY_SETTING3", "_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a26b10edeb26e5df7fbc67b072bfa15f8", null ],
      [ "DELAY_SETTING4", "_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a849122e7f91d9718ac1b571302f3daf7", null ]
    ] ],
    [ "KW007_Init", "_k_w007__api_8h.html#a86784c228b8930aceee4b806e00aaf84", null ],
    [ "KW007_Read", "_k_w007__api_8h.html#a385cea3502606206bf1a2da81b83eb2d", null ],
    [ "KW007_SetDetectionRange", "_k_w007__api_8h.html#adbb3bd41ee31286f62485142fbfef392", null ],
    [ "KW007_SetEnhancedMode", "_k_w007__api_8h.html#a7a56becedf387ce2b45d2687482eff35", null ],
    [ "KW007_SetFastSpeedDetection", "_k_w007__api_8h.html#a307b76785210995d157325310e8298fe", null ],
    [ "KW007_SetGain", "_k_w007__api_8h.html#a0732cd1440e7f9eaeaef19238ee12918", null ],
    [ "KW007_SetGPO_DelayDuration", "_k_w007__api_8h.html#a1938ea4abe74fe89331840bcb5db9df5", null ],
    [ "KW007_SetSamplingRate", "_k_w007__api_8h.html#aa3643b99660e8847a981486396085ccf", null ],
    [ "KW007_SetSlowSpeedDetection", "_k_w007__api_8h.html#a0406d0570fff7080256c72956d6665a5", null ],
    [ "KW007_SetThreshold", "_k_w007__api_8h.html#a299cb34f3e4db4c36aa043bc8e4cce86", null ]
];