var struct_k_w007___data =
[
    [ "approaching", "struct_k_w007___data.html#a8540c6dbf9664b0781246fdbe94d6c87", null ],
    [ "isDay", "struct_k_w007___data.html#a0e83124dd800c17634e248c20297ca6b", null ],
    [ "leaving", "struct_k_w007___data.html#a46ca5337e9d0f86a7088c80d975abf6e", null ],
    [ "ok", "struct_k_w007___data.html#a9df3df71dc69d2137a53869e78112ffb", null ],
    [ "rssi", "struct_k_w007___data.html#af29537d3e46509eab6d9974509a9b0e0", null ]
];