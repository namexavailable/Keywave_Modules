var index =
[
    [ "Overview", "index.html#autotoc_md1", null ],
    [ "Hardware Setup (Critical)", "index.html#autotoc_md2", null ],
    [ "Quick Start", "index.html#autotoc_md3", null ],
    [ "I²C Address", "index.html#autotoc_md4", null ],
    [ "Supported Platforms", "index.html#autotoc_md5", null ],
    [ "Sensor Variants", "index.html#autotoc_md6", null ],
    [ "Detection Range Presets", "index.html#autotoc_md7", null ],
    [ "Initialization Sequence", "index.html#autotoc_md8", null ],
    [ "Verifying a Write", "index.html#autotoc_md9", null ],
    [ "Error Codes", "index.html#autotoc_md10", null ],
    [ "Version", "index.html#autotoc_md11", null ],
    [ "Module Reference", "index.html#autotoc_md12", null ]
];