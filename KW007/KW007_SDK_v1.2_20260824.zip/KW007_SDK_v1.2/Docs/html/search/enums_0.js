var searchData=
[
  ['kw007_5fdelayduration_0',['KW007_DelayDuration',['../_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333',1,'KW007_api.h']]]
];
