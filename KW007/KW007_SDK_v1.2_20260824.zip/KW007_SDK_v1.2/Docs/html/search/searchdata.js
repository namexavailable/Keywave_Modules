var indexSectionsWithContent =
{
  0: "02458:abcdefghiklmopqrstuvw",
  1: "k",
  2: "km",
  3: "klm",
  4: "aiklors",
  5: "k",
  6: "d",
  7: "afkmr",
  8: "02458:abcdefghiklmopqrstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

