var searchData=
[
  ['c_0',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['c_20and_20directly_20by_20engineers_1',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['codes_2',['Error Codes',['../index.html#autotoc_md10',1,'']]],
  ['critical_3',['Hardware Setup (Critical)',['../index.html#autotoc_md2',1,'']]]
];
