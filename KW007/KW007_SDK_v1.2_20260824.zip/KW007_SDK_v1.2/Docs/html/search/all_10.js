var searchData=
[
  ['leaving_0',['leaving',['../struct_k_w007___data.html#a46ca5337e9d0f86a7088c80d975abf6e',1,'KW007_Data']]],
  ['led_5finit_1',['led_init',['../kw007__example__led_8c.html#a9d9d9b1f30592189c3aa7358c626218f',1,'kw007_example_led.c']]],
  ['led_5fset_2',['led_set',['../kw007__example__led_8c.html#a3d91c4348fd9228b7057ea723b519149',1,'kw007_example_led.c']]],
  ['level_20operations_20are_20in_20kw007_5freg_20c_3',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['lightflagdelay_20bit_200_20fast_20speed_20detection_4',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]]
];
