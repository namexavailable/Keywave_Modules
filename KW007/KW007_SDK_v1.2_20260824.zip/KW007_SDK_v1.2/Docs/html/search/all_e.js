var searchData=
[
  ['i²c_20address_0',['I²C Address',['../index.html#autotoc_md4',1,'']]],
  ['i2c_20api_20expects_20that_20form_20a_20read_20uses_200x33_20derived_20here_1',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['if_20data_20approaching_2',['if (data.approaching) { ... }',['../_k_w007__api_8h.html#autotoc_md16',1,'']]],
  ['ignores_20every_20register_20write_3',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['in_20hardware_20mode_20and_20ignores_20every_20register_20write_4',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['in_20kw007_5freg_20c_5',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['initialization_20sequence_6',['Initialization Sequence',['../index.html#autotoc_md8',1,'']]],
  ['internally_20by_20kw007_5fapi_20c_20and_20directly_20by_20engineers_7',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['invalid_20parameter_8',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md30',1,'']]],
  ['is_20passed_20through_20unchanged_9',['KW007_I2C_ADDRESS = 0x32 is passed through unchanged.',['../kw007__hal__ftdi_8cpp.html#autotoc_md26',1,'']]],
  ['is_20passed_20through_20unchanged_20address_200x19_10',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['isday_11',['isDay',['../struct_k_w007___data.html#a0e83124dd800c17634e248c20297ca6b',1,'KW007_Data']]]
];
