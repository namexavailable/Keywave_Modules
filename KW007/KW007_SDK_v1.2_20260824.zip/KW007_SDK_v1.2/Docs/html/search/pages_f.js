var searchData=
[
  ['keywave_20kw007_20mdash_205_208_20ghz_20doppler_20radar_20motion_20sensor_0',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['kw007_20mdash_205_208_20ghz_20doppler_20radar_20motion_20sensor_1',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['kw007_5fapi_20c_20and_20directly_20by_20engineers_2',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['kw007_5ferr_5fparam_200x30_20invalid_20parameter_3',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md30',1,'']]],
  ['kw007_5fi2c_5faddress_200x32_20is_20passed_20through_20unchanged_4',['KW007_I2C_ADDRESS = 0x32 is passed through unchanged.',['../kw007__hal__ftdi_8cpp.html#autotoc_md26',1,'']]],
  ['kw007_5freg_20c_5',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]]
];
