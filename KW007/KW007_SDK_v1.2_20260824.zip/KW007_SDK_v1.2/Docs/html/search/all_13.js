var searchData=
[
  ['parameter_0',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md30',1,'']]],
  ['passed_20through_20unchanged_1',['KW007_I2C_ADDRESS = 0x32 is passed through unchanged.',['../kw007__hal__ftdi_8cpp.html#autotoc_md26',1,'']]],
  ['passed_20through_20unchanged_20address_200x19_2',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['platforms_3',['Supported Platforms',['../index.html#autotoc_md5',1,'']]],
  ['presets_4',['Detection Range Presets',['../index.html#autotoc_md7',1,'']]]
];
