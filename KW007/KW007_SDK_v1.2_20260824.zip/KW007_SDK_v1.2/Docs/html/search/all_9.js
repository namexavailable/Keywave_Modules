var searchData=
[
  ['d1mini_20_3a_20wire_20begin_204_205_0',['ESP8266 D1Mini : Wire.begin(4, 5)',['../kw007__hal__arduino_8cpp.html#autotoc_md24',1,'']]],
  ['data_20approaching_1',['if (data.approaching) { ... }',['../_k_w007__api_8h.html#autotoc_md16',1,'']]],
  ['delay_5fsetting1_2',['DELAY_SETTING1',['../_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a36934368bc392e1b060de6b32adc4a39',1,'KW007_api.h']]],
  ['delay_5fsetting2_3',['DELAY_SETTING2',['../_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a186dccd0e4017da5556eaf743de0b07e',1,'KW007_api.h']]],
  ['delay_5fsetting3_4',['DELAY_SETTING3',['../_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a26b10edeb26e5df7fbc67b072bfa15f8',1,'KW007_api.h']]],
  ['delay_5fsetting4_5',['DELAY_SETTING4',['../_k_w007__api_8h.html#a79777bc57fc177d99d4dd81fdc1b4333a849122e7f91d9718ac1b571302f3daf7',1,'KW007_api.h']]],
  ['derived_20here_6',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['detection_7',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['detection_20range_20presets_8',['Detection Range Presets',['../index.html#autotoc_md7',1,'']]],
  ['devaddr_200x32_20is_20passed_20through_20unchanged_20address_200x19_9',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['directly_20by_20engineers_10',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['doppler_20radar_20motion_20sensor_11',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]]
];
