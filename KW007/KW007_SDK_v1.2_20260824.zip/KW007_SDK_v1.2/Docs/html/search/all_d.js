var searchData=
[
  ['hardware_20mode_20and_20ignores_20every_20register_20write_0',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['hardware_20setup_20critical_1',['Hardware Setup (Critical)',['../index.html#autotoc_md2',1,'']]],
  ['here_2',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]]
];
