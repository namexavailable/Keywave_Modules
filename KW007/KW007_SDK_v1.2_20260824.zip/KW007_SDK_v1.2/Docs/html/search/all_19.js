var searchData=
[
  ['variants_0',['Sensor Variants',['../index.html#autotoc_md6',1,'']]],
  ['verifying_20a_20write_1',['Verifying a Write',['../index.html#autotoc_md9',1,'']]],
  ['version_2',['Version',['../index.html#autotoc_md11',1,'']]]
];
