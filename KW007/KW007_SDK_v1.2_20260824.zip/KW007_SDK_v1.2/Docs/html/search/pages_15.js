var searchData=
[
  ['r29_20reg_5fgpo_5fdelay_20bits_202_3a1_20lightflagdelay_20bit_200_20fast_20speed_20detection_0',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['radar_20motion_20sensor_1',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['range_20presets_2',['Detection Range Presets',['../index.html#autotoc_md7',1,'']]],
  ['read_20uses_200x33_20derived_20here_3',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['reference_4',['Module Reference',['../index.html#autotoc_md12',1,'']]],
  ['reg_5fgpo_5fdelay_20bits_202_3a1_20lightflagdelay_20bit_200_20fast_20speed_20detection_5',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['register_20level_20operations_20are_20in_20kw007_5freg_20c_6',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['register_20write_7',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['runs_20in_20hardware_20mode_20and_20ignores_20every_20register_20write_8',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]]
];
