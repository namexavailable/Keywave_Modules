var searchData=
[
  ['2_3a1_20lightflagdelay_20bit_200_20fast_20speed_20detection_0',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]]
];
