var searchData=
[
  ['main_0',['main',['../kw007__example__led_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'kw007_example_led.c']]],
  ['mainpage_2emd_1',['mainpage.md',['../mainpage_8md.html',1,'']]],
  ['mask_5famp1_2',['MASK_AMP1',['../kw007__reg_8h.html#ab39f4a763ad88cda34a77039fbc5b3b8',1,'kw007_reg.h']]],
  ['mask_5famp2_3',['MASK_AMP2',['../kw007__reg_8h.html#afef7dbef6204d75b7603564e403b4cc2',1,'kw007_reg.h']]],
  ['mask_5famp3_4',['MASK_AMP3',['../kw007__reg_8h.html#adee8aa3749429acf2d67e4c852e5b12e',1,'kw007_reg.h']]],
  ['mask_5fefuse_5fmode_5',['MASK_EFUSE_MODE',['../kw007__reg_8h.html#a217717240d8aa48752b5b4c001beac86',1,'kw007_reg.h']]],
  ['mask_5fenhanced_6',['MASK_ENHANCED',['../kw007__reg_8h.html#a7460a0b438ae08c8d864ee39de287065',1,'kw007_reg.h']]],
  ['mask_5ffast_5fspeed_5fdet_7',['MASK_FAST_SPEED_DET',['../kw007__reg_8h.html#a18b0add20aa7e4fc9da5ec581272b0b6',1,'kw007_reg.h']]],
  ['mask_5fgpo_5fdelay_8',['MASK_GPO_DELAY',['../kw007__reg_8h.html#a123914299947a44eeb818cf770eabbdf',1,'kw007_reg.h']]],
  ['mask_5freserved_5fr12_9',['MASK_RESERVED_R12',['../kw007__reg_8h.html#af744049702763476a64ef2feae257065',1,'kw007_reg.h']]],
  ['mask_5fsample_5frate_10',['MASK_SAMPLE_RATE',['../kw007__reg_8h.html#adff27c7e9e95a9255d8bf5e1b99d2ca8',1,'kw007_reg.h']]],
  ['mask_5fslow_5fdet_11',['MASK_SLOW_DET',['../kw007__reg_8h.html#a669788c4e6221e1ccf96f291cd337c01',1,'kw007_reg.h']]],
  ['mask_5fvco_5fbank_12',['MASK_VCO_BANK',['../kw007__reg_8h.html#ac972e018b84dac95f425373aa937ad8d',1,'kw007_reg.h']]],
  ['mdash_205_208_20ghz_20doppler_20radar_20motion_20sensor_13',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['mode_20and_20ignores_20every_20register_20write_14',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['module_20reference_15',['Module Reference',['../index.html#autotoc_md12',1,'']]],
  ['motion_20sensor_16',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]]
];
