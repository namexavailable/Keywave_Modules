var searchData=
[
  ['mdash_205_208_20ghz_20doppler_20radar_20motion_20sensor_0',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['mode_20and_20ignores_20every_20register_20write_1',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['module_20reference_2',['Module Reference',['../index.html#autotoc_md12',1,'']]],
  ['motion_20sensor_3',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]]
];
