var searchData=
[
  ['ghz_20doppler_20radar_20motion_20sensor_0',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]]
];
