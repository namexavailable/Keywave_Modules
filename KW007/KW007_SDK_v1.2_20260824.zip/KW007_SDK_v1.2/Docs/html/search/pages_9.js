var searchData=
[
  ['d1mini_20_3a_20wire_20begin_204_205_0',['ESP8266 D1Mini : Wire.begin(4, 5)',['../kw007__hal__arduino_8cpp.html#autotoc_md24',1,'']]],
  ['data_20approaching_1',['if (data.approaching) { ... }',['../_k_w007__api_8h.html#autotoc_md16',1,'']]],
  ['derived_20here_2',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['detection_3',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['detection_20range_20presets_4',['Detection Range Presets',['../index.html#autotoc_md7',1,'']]],
  ['devaddr_200x32_20is_20passed_20through_20unchanged_20address_200x19_5',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['directly_20by_20engineers_6',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['doppler_20radar_20motion_20sensor_7',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]]
];
