var searchData=
[
  ['leaving_0',['leaving',['../struct_k_w007___data.html#a46ca5337e9d0f86a7088c80d975abf6e',1,'KW007_Data']]]
];
