var searchData=
[
  ['ok_0',['ok',['../struct_k_w007___data.html#a9df3df71dc69d2137a53869e78112ffb',1,'KW007_Data']]]
];
