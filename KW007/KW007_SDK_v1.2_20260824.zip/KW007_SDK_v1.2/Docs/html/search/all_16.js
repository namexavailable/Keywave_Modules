var searchData=
[
  ['s_5fftdi_5fopen_0',['s_ftdi_open',['../kw007__hal__ftdi_8cpp.html#a8ae958672fd27919fdd1a62b82af23ac',1,'kw007_hal_ftdi.cpp']]],
  ['s_5fhi2c_1',['s_hi2c',['../kw007__hal__stm32_8c.html#a7a2620b0e04a5b59ccb4db009f017eb0',1,'kw007_hal_stm32.c']]],
  ['sensor_2',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['sensor_20runs_20in_20hardware_20mode_20and_20ignores_20every_20register_20write_3',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['sensor_20variants_4',['Sensor Variants',['../index.html#autotoc_md6',1,'']]],
  ['sequence_5',['Initialization Sequence',['../index.html#autotoc_md8',1,'']]],
  ['setup_20critical_6',['Hardware Setup (Critical)',['../index.html#autotoc_md2',1,'']]],
  ['so_20devaddr_200x32_20is_20passed_20through_20unchanged_20address_200x19_7',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['speed_20detection_8',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['start_9',['Quick Start',['../index.html#autotoc_md3',1,'']]],
  ['supported_20platforms_10',['Supported Platforms',['../index.html#autotoc_md5',1,'']]]
];
