var searchData=
[
  ['fast_20speed_20detection_0',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['flag_5fapproaching_1',['FLAG_APPROACHING',['../kw007__reg_8h.html#a11e2931f4fcbc38ae5b086f459d8c4a3',1,'kw007_reg.h']]],
  ['flag_5fday_5fnight_2',['FLAG_DAY_NIGHT',['../kw007__reg_8h.html#add63468370b786c656e946daedcaf61e',1,'kw007_reg.h']]],
  ['flag_5fleaving_3',['FLAG_LEAVING',['../kw007__reg_8h.html#ae28fecdbf5cfd1fbee0d99c9b18b0b8c',1,'kw007_reg.h']]],
  ['form_20a_20read_20uses_200x33_20derived_20here_4',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]]
];
