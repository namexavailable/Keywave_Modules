var searchData=
[
  ['level_20operations_20are_20in_20kw007_5freg_20c_0',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['lightflagdelay_20bit_200_20fast_20speed_20detection_1',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]]
];
