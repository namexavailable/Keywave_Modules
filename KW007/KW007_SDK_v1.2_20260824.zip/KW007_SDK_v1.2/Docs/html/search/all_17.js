var searchData=
[
  ['that_20form_20a_20read_20uses_200x33_20derived_20here_0',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['through_20unchanged_1',['KW007_I2C_ADDRESS = 0x32 is passed through unchanged.',['../kw007__hal__ftdi_8cpp.html#autotoc_md26',1,'']]],
  ['through_20unchanged_20address_200x19_2',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]]
];
