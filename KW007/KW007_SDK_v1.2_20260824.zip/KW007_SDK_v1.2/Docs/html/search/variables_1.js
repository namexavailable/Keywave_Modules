var searchData=
[
  ['isday_0',['isDay',['../struct_k_w007___data.html#a0e83124dd800c17634e248c20297ca6b',1,'KW007_Data']]]
];
