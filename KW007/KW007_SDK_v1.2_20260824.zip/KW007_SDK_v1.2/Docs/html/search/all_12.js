var searchData=
[
  ['ok_0',['ok',['../struct_k_w007___data.html#a9df3df71dc69d2137a53869e78112ffb',1,'KW007_Data']]],
  ['operations_20are_20in_20kw007_5freg_20c_1',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['overview_2',['Overview',['../index.html#autotoc_md1',1,'']]]
];
