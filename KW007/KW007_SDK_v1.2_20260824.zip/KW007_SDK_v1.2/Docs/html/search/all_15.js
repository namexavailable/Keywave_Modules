var searchData=
[
  ['r29_20reg_5fgpo_5fdelay_20bits_202_3a1_20lightflagdelay_20bit_200_20fast_20speed_20detection_0',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['radar_20motion_20sensor_1',['Keywave KW007 &amp;mdash; 5.8 GHz Doppler Radar Motion Sensor',['../index.html',1,'']]],
  ['range_20presets_2',['Detection Range Presets',['../index.html#autotoc_md7',1,'']]],
  ['read_20uses_200x33_20derived_20here_3',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['reference_4',['Module Reference',['../index.html#autotoc_md12',1,'']]],
  ['reg_5famp1_5fgain_5',['REG_AMP1_GAIN',['../kw007__reg_8h.html#a1db479bfbf1bff8e7342370fa3a97cb2',1,'kw007_reg.h']]],
  ['reg_5famp2_5famp3_5fgain_6',['REG_AMP2_AMP3_GAIN',['../kw007__reg_8h.html#aa054b19eb73a25e269be5b76e9b139e0',1,'kw007_reg.h']]],
  ['reg_5fenhanced_5fmode_7',['REG_ENHANCED_MODE',['../kw007__reg_8h.html#a07d07724af772ea5025ce161851fc916',1,'kw007_reg.h']]],
  ['reg_5fflags_8',['REG_FLAGS',['../kw007__reg_8h.html#a4c5d46219c3489fefbabe1fcba800bad',1,'kw007_reg.h']]],
  ['reg_5fgpo_5fdelay_9',['REG_GPO_DELAY',['../kw007__reg_8h.html#a60717f04b68fbe3257996e735aa7ca13',1,'kw007_reg.h']]],
  ['reg_5fgpo_5fdelay_20bits_202_3a1_20lightflagdelay_20bit_200_20fast_20speed_20detection_10',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['reg_5fmanual_5fmode_11',['REG_MANUAL_MODE',['../kw007__reg_8h.html#adebf2dca039390476691106fc0e14f21',1,'kw007_reg.h']]],
  ['reg_5frssi_12',['REG_RSSI',['../kw007__reg_8h.html#a90de356d2ec2409de09a8ed515c823b7',1,'kw007_reg.h']]],
  ['reg_5fslow_5fspeed_13',['REG_SLOW_SPEED',['../kw007__reg_8h.html#a07da77381896193f6d724ef4674c6514',1,'kw007_reg.h']]],
  ['reg_5fthreshold_14',['REG_THRESHOLD',['../kw007__reg_8h.html#a18d75be1c6891a0bb1b1a3b38c7bd1af',1,'kw007_reg.h']]],
  ['reg_5fvco_5fctrl_15',['REG_VCO_CTRL',['../kw007__reg_8h.html#a5ffa59c27228ea6dec81b868f97f66aa',1,'kw007_reg.h']]],
  ['reg_5fvco_5ffuse_16',['REG_VCO_FUSE',['../kw007__reg_8h.html#a77bc8d1644224681cb7f3d865b7a9311',1,'kw007_reg.h']]],
  ['register_20level_20operations_20are_20in_20kw007_5freg_20c_17',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['register_20write_18',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['rssi_19',['rssi',['../struct_k_w007___data.html#af29537d3e46509eab6d9974509a9b0e0',1,'KW007_Data']]],
  ['runs_20in_20hardware_20mode_20and_20ignores_20every_20register_20write_20',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]]
];
