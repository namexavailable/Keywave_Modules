var searchData=
[
  ['operations_20are_20in_20kw007_5freg_20c_0',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]],
  ['overview_1',['Overview',['../index.html#autotoc_md1',1,'']]]
];
