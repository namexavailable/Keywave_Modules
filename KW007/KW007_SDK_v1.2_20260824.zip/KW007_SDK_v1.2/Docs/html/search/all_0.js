var searchData=
[
  ['0_20fast_20speed_20detection_0',['R29 REG_GPO_DELAY bits[2:1]=LightFlagDelay, bit[0]=fast speed detection',['../kw007__reg_8h.html#autotoc_md22',1,'']]],
  ['0x19_1',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['0x30_20invalid_20parameter_2',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md30',1,'']]],
  ['0x32_20is_20passed_20through_20unchanged_3',['KW007_I2C_ADDRESS = 0x32 is passed through unchanged.',['../kw007__hal__ftdi_8cpp.html#autotoc_md26',1,'']]],
  ['0x32_20is_20passed_20through_20unchanged_20address_200x19_4',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['0x33_20derived_20here_5',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]]
];
