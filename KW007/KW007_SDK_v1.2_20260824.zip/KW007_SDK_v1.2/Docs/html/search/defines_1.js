var searchData=
[
  ['flag_5fapproaching_0',['FLAG_APPROACHING',['../kw007__reg_8h.html#a11e2931f4fcbc38ae5b086f459d8c4a3',1,'kw007_reg.h']]],
  ['flag_5fday_5fnight_1',['FLAG_DAY_NIGHT',['../kw007__reg_8h.html#add63468370b786c656e946daedcaf61e',1,'kw007_reg.h']]],
  ['flag_5fleaving_2',['FLAG_LEAVING',['../kw007__reg_8h.html#ae28fecdbf5cfd1fbee0d99c9b18b0b8c',1,'kw007_reg.h']]]
];
