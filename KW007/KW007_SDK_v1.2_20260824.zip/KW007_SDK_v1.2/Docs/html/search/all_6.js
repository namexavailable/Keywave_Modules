var searchData=
[
  ['a_20read_20uses_200x33_20derived_20here_0',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['a_20write_1',['Verifying a Write',['../index.html#autotoc_md9',1,'']]],
  ['addr7_2',['ADDR7',['../kw007__hal__arduino_8cpp.html#a982f3615674fd8ce3beed037e01f53e5',1,'kw007_hal_arduino.cpp']]],
  ['address_3',['I²C Address',['../index.html#autotoc_md4',1,'']]],
  ['address_200x19_4',['so devAddr = 0x32 is passed through unchanged (address 0x19).',['../kw007__hal__stm32_8c.html#autotoc_md28',1,'']]],
  ['and_20directly_20by_20engineers_5',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8h.html#autotoc_md20',1,'']]],
  ['and_20ignores_20every_20register_20write_6',['sensor runs in hardware mode and ignores every register write.',['../kw007__example__led_8c.html#autotoc_md32',1,'']]],
  ['api_20expects_20that_20form_20a_20read_20uses_200x33_20derived_20here_7',['I2C API expects that form. A read uses 0x33, derived here.',['../kw007__hal_8h.html#autotoc_md18',1,'']]],
  ['approaching_8',['approaching',['../struct_k_w007___data.html#a8540c6dbf9664b0781246fdbe94d6c87',1,'KW007_Data::approaching'],['../_k_w007__api_8h.html#autotoc_md16',1,'if (data.approaching) { ... }']]],
  ['are_20in_20kw007_5freg_20c_9',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8h.html#autotoc_md14',1,'']]]
];
