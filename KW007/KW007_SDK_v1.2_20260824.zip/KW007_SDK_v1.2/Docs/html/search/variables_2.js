var searchData=
[
  ['kw007_5fdefault_5fregs_0',['kw007_default_regs',['../kw007__reg_8c.html#a9fef6ad3c1a6df0a988b037f44f17e8a',1,'kw007_default_regs:&#160;kw007_reg.c'],['../kw007__reg_8h.html#a9fef6ad3c1a6df0a988b037f44f17e8a',1,'kw007_default_regs:&#160;kw007_reg.c']]]
];
