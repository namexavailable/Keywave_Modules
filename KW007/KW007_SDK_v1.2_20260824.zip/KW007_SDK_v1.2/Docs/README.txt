============================================================
 KW007 SDK v1.2 — Technical Documentation
 Keywave KW007 5.8 GHz Doppler Radar Sensor
 Release Date: 2026-08-24
============================================================

CONTENTS
--------
  KW007_SDK_v1.2.chm      Compiled HTML Help — complete API reference,
                          hardware wiring, and integration guide.

  KW007_Programming_Guide_v2.0c.pdf
                          Register-level reference for the KW007
                          sensor — register map, settings tables,
                          and hardware notes.

  html\                   The same reference as browsable HTML, for
                          platforms without a CHM viewer. Open
                          html\index.html.


HOW TO OPEN
-----------
  Windows:   Double-click KW007_SDK_v1.2.chm
  macOS:     Use a third-party CHM reader (e.g. iChm, Chmox)
  Linux:     Use xCHM or kchmviewer


TROUBLESHOOTING — "Page cannot be displayed" / blank content
------------------------------------------------------------
If the CHM opens but the content pane is empty or shows
"Navigation to the webpage was canceled", Windows has blocked
the file for security reasons (Mark-of-the-Web). This is a
standard Windows safeguard for CHM files received via email,
cloud storage, or USB transfer.

To unblock:

  1. Right-click  KW007_SDK_v1.2.chm
  2. Select       Properties
  3. At the bottom of the dialog, check the box:
                  [x] Unblock
  4. Click        Apply  ->  OK
  5. Re-open the .chm file

Alternative (PowerShell one-liner):

        Unblock-File .\KW007_SDK_v1.2.chm


ADDITIONAL NOTES
----------------
  * Do not place the .chm file in a path containing the '#'
    character (e.g. C:\C#_Projects\). CHM cannot render
    content from such paths.

  * When stored on a network drive or SMB share, CHM content
    may be blocked. Copy the file to a local drive first.

  * Some corporate IT policies disable CHM entirely.
    Contact your IT administrator if unblocking does not help.


SUPPORT
-------
For technical inquiries regarding the KW007 sensor or SDK,
please contact your Keywave representative.

============================================================
