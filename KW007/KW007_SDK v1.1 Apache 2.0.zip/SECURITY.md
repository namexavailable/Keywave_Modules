# Security Policy

Keywave Technology Limited welcomes responsible reports of security issues
affecting the Keywave SDK or compatible Keywave products.

## Reporting a Vulnerability

Please do not disclose suspected security vulnerabilities through public
GitHub Issues, discussions, pull requests or other public channels.

Please report suspected vulnerabilities privately to:

[INSERT KEYWAVE SECURITY CONTACT]

Where possible, include:

- A description of the issue
- The affected Keywave product
- The affected SDK version or commit
- Steps to reproduce the issue
- Potential impact
- Relevant logs or technical details
- Any suggested remediation

General SDK bugs that do not involve security may be reported through the
project's normal public issue tracker.

Keywave may update this policy and its supported security-reporting process
from time to time.
