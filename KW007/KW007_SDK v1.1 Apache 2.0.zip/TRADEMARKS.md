# Keywave Trademark Guidelines

Keywave Technology Limited welcomes developers, customers, partners,
researchers and members of the technical community discussing, reviewing and
developing software for Keywave products.

The open-source licences applicable to this repository do not grant a general
licence to use Keywave Technology Limited's trademarks, logos, trade names,
service marks or branding.

## Descriptive Use

You may use the Keywave name and Keywave product names in a factual and
descriptive manner to accurately identify compatibility, integration, support,
testing or the origin of software.

Examples include:

- "Supports the Keywave KW307"
- "Driver for Keywave KW007"
- "Compatible with the Keywave SDK"
- "Application built using the Keywave SDK"

## Uses Requiring Separate Permission

Unless separately authorised by Keywave Technology Limited, you should not:

- Represent yourself, your organisation or your product as Keywave Technology
  Limited.
- State or imply that Keywave officially endorses, certifies, sponsors or
  approves a third-party product or project.
- Use the Keywave logo as the principal branding of a third-party product,
  company, website, repository or service.
- Use Keywave branding in a way likely to cause confusion regarding the source,
  ownership, sponsorship or affiliation of a product or service.

Third-party products and projects should use their own names and branding.

Nothing in these guidelines is intended to restrict uses permitted by
applicable law or by the relevant software licence.
