var index =
[
    [ "Overview", "index.html#autotoc_md19", null ],
    [ "Quick Start", "index.html#autotoc_md21", null ],
    [ "Supported Platforms", "index.html#autotoc_md23", null ],
    [ "Sensor Models", "index.html#autotoc_md25", null ],
    [ "Detection Range Presets", "index.html#autotoc_md27", null ],
    [ "Initialization Sequence", "index.html#autotoc_md29", null ],
    [ "Error Codes", "index.html#autotoc_md31", null ],
    [ "Module Reference", "index.html#autotoc_md33", null ]
];