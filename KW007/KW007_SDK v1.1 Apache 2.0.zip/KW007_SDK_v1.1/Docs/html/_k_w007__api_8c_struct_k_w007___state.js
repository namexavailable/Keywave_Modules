var _k_w007__api_8c_struct_k_w007___state =
[
    [ "model", "_k_w007__api_8c.html#a53280cabebf32db32f43ff0ddf101be4", null ]
];