var indexSectionsWithContent =
{
  0: "01457:_abcdefiklmnopqrstuvw—",
  1: "k",
  2: "km",
  3: "k",
  4: "_kms",
  5: "ak",
  6: "01457:abcdefiklmnopqrstuvw—"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

