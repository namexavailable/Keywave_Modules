var searchData=
[
  ['addr7_0',['ADDR7',['../kw007__hal__arduino_8cpp.html#a982f3615674fd8ce3beed037e01f53e5',1,'kw007_hal_arduino.cpp']]],
  ['address_20shifted_20left_20by_201_20kw007_200x32_20—_20pass_20directly_1',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['and_20directly_20by_20engineers_2',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]],
  ['approaching_3',['if (data.approaching) { ... }',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/KW007_api.h#autotoc_md1',1,'']]],
  ['are_20in_20kw007_5freg_20c_4',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]]
];
