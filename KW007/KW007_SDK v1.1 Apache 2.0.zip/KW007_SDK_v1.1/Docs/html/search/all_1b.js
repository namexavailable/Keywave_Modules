var searchData=
[
  ['—_20never_20write_20r31_3a_20permanently_20corrupts_20model_20id_20on_20chip_0',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['—_20no_20conversion_20needed_1',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]],
  ['—_20pass_20directly_2',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['—_20template_20for_20custom_20platforms_3',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]]
];
