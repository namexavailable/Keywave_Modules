var searchData=
[
  ['kw007_200x32_20—_20pass_20directly_0',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['kw007_20sdk_20v1_201_1',['KW007 SDK v1.1',['../index.html',1,'']]],
  ['kw007_5fapi_20c_20and_20directly_20by_20engineers_2',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]],
  ['kw007_5ferr_5fparam_200x30_20invalid_20parameter_3',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md17',1,'']]],
  ['kw007_5fhal_5fuser_20c_20—_20template_20for_20custom_20platforms_4',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]],
  ['kw007_5fi2c_5faddress_200x32_20—_20no_20conversion_20needed_5',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]],
  ['kw007_5freg_20c_6',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]]
];
