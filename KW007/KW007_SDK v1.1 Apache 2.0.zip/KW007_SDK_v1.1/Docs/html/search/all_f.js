var searchData=
[
  ['left_20by_201_20kw007_200x32_20—_20pass_20directly_0',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['level_20operations_20are_20in_20kw007_5freg_20c_1',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]]
];
