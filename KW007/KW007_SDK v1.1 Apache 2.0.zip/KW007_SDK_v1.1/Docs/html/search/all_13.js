var searchData=
[
  ['parameter_0',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md17',1,'']]],
  ['pass_20directly_1',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['permanently_20corrupts_20model_20id_20on_20chip_2',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['platforms_3',['Supported Platforms',['../index.html#autotoc_md23',1,'']]],
  ['platforms_4',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]],
  ['presets_5',['Detection Range Presets',['../index.html#autotoc_md27',1,'']]]
];
