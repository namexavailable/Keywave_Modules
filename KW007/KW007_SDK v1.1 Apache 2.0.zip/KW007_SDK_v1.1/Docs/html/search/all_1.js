var searchData=
[
  ['1_0',['KW007 SDK v1.1',['../index.html',1,'']]],
  ['1_20kw007_200x32_20—_20pass_20directly_1',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]]
];
