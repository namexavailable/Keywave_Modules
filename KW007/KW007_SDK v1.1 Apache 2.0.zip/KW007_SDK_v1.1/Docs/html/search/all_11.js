var searchData=
[
  ['needed_0',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]],
  ['never_20write_20r31_3a_20permanently_20corrupts_20model_20id_20on_20chip_1',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['no_20conversion_20needed_2',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]]
];
