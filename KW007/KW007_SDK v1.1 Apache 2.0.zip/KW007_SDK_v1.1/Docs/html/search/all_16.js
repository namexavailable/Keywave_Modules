var searchData=
[
  ['s_5fftdi_5fopen_0',['s_ftdi_open',['../kw007__hal__ftdi_8cpp.html#a8ae958672fd27919fdd1a62b82af23ac',1,'kw007_hal_ftdi.cpp']]],
  ['s_5fhi2c_1',['s_hi2c',['../kw007__hal__stm32_8c.html#a7a2620b0e04a5b59ccb4db009f017eb0',1,'kw007_hal_stm32.c']]],
  ['sdk_20v1_201_2',['KW007 SDK v1.1',['../index.html',1,'']]],
  ['sensor_20models_3',['Sensor Models',['../index.html#autotoc_md25',1,'']]],
  ['sequence_4',['Initialization Sequence',['../index.html#autotoc_md29',1,'']]],
  ['shifted_20left_20by_201_20kw007_200x32_20—_20pass_20directly_5',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['start_6',['Quick Start',['../index.html#autotoc_md21',1,'']]],
  ['supported_20platforms_7',['Supported Platforms',['../index.html#autotoc_md23',1,'']]]
];
