var searchData=
[
  ['kw007_5fdefault_5fregs_0',['kw007_default_regs',['../kw007__reg_8c.html#acba1dff5fc1292f6f58ad5e2bde3994f',1,'kw007_reg.c']]]
];
