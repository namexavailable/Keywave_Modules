var searchData=
[
  ['7_20bit_20address_20shifted_20left_20by_201_20kw007_200x32_20—_20pass_20directly_0',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]]
];
