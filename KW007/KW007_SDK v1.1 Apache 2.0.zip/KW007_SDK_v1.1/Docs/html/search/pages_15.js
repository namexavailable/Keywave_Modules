var searchData=
[
  ['sdk_20v1_201_0',['KW007 SDK v1.1',['../index.html',1,'']]],
  ['sensor_20models_1',['Sensor Models',['../index.html#autotoc_md25',1,'']]],
  ['sequence_2',['Initialization Sequence',['../index.html#autotoc_md29',1,'']]],
  ['shifted_20left_20by_201_20kw007_200x32_20—_20pass_20directly_3',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['start_4',['Quick Start',['../index.html#autotoc_md21',1,'']]],
  ['supported_20platforms_5',['Supported Platforms',['../index.html#autotoc_md23',1,'']]]
];
