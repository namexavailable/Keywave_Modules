var searchData=
[
  ['begin_204_205_0',['ESP8266 D1Mini : Wire.begin(4, 5)',['../kw007__hal__arduino_8cpp.html#autotoc_md11',1,'']]],
  ['bit_20address_20shifted_20left_20by_201_20kw007_200x32_20—_20pass_20directly_1',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['by_201_20kw007_200x32_20—_20pass_20directly_2',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['by_20engineers_3',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]],
  ['by_20kw007_5fapi_20c_20and_20directly_20by_20engineers_4',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]]
];
