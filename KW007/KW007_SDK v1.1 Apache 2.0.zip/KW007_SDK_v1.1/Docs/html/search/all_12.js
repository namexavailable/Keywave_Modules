var searchData=
[
  ['on_20chip_0',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['operations_20are_20in_20kw007_5freg_20c_1',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]],
  ['overview_2',['Overview',['../index.html#autotoc_md19',1,'']]]
];
