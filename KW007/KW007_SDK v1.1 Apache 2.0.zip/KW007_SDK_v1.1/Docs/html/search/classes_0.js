var searchData=
[
  ['kw007_5fstate_0',['KW007_State',['../_k_w007__api_8c.html#struct_k_w007___state',1,'']]]
];
