var searchData=
[
  ['d1mini_20_3a_20wire_20begin_204_205_0',['ESP8266 D1Mini : Wire.begin(4, 5)',['../kw007__hal__arduino_8cpp.html#autotoc_md11',1,'']]],
  ['data_20approaching_1',['if (data.approaching) { ... }',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/KW007_api.h#autotoc_md1',1,'']]],
  ['detection_20range_20presets_2',['Detection Range Presets',['../index.html#autotoc_md27',1,'']]],
  ['directly_3',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]],
  ['directly_20by_20engineers_4',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]]
];
