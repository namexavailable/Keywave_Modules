var searchData=
[
  ['used_20internally_20by_20kw007_5fapi_20c_20and_20directly_20by_20engineers_0',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]],
  ['user_5fplatform_20kw007_5fhal_5fuser_20c_20—_20template_20for_20custom_20platforms_1',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]]
];
