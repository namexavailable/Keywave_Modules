var searchData=
[
  ['r31_3a_20permanently_20corrupts_20model_20id_20on_20chip_0',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['range_20presets_1',['Detection Range Presets',['../index.html#autotoc_md27',1,'']]],
  ['reference_2',['Module Reference',['../index.html#autotoc_md33',1,'']]],
  ['register_20level_20operations_20are_20in_20kw007_5freg_20c_3',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]]
];
