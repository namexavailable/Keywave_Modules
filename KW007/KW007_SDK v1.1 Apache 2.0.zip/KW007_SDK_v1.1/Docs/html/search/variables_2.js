var searchData=
[
  ['model_0',['model',['../_k_w007__api_8c.html#a53280cabebf32db32f43ff0ddf101be4',1,'KW007_State']]]
];
