var searchData=
[
  ['s_5fftdi_5fopen_0',['s_ftdi_open',['../kw007__hal__ftdi_8cpp.html#a8ae958672fd27919fdd1a62b82af23ac',1,'kw007_hal_ftdi.cpp']]],
  ['s_5fhi2c_1',['s_hi2c',['../kw007__hal__stm32_8c.html#a7a2620b0e04a5b59ccb4db009f017eb0',1,'kw007_hal_stm32.c']]]
];
