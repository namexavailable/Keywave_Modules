var searchData=
[
  ['c_0',['Register-level operations are in kw007_reg.c.',['../_k_w007__api_8c.html#autotoc_md3',1,'']]],
  ['c_20—_20template_20for_20custom_20platforms_1',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]],
  ['c_20and_20directly_20by_20engineers_2',['Used internally by KW007_api.c and directly by engineers.',['../kw007__reg_8c.html#autotoc_md7',1,'']]],
  ['chip_3',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['codes_4',['Error Codes',['../index.html#autotoc_md31',1,'']]],
  ['conversion_20needed_5',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]],
  ['corrupts_20model_20id_20on_20chip_6',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['critical_20—_20never_20write_20r31_3a_20permanently_20corrupts_20model_20id_20on_20chip_7',['CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_reg.h#autotoc_md5',1,'']]],
  ['custom_20platforms_8',['User_platform/kw007_hal_user.c — template for custom platforms',['../C:/Users/chadlin/Bofry/MCU/Arduino/KW007_SDK_v1.1/kw007_hal.h#autotoc_md9',1,'']]]
];
