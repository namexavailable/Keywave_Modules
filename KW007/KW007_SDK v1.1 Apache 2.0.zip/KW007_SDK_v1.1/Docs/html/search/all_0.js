var searchData=
[
  ['0x30_20invalid_20parameter_0',['KW007_ERR_PARAM 0x30 invalid parameter',['../kw007__hal__user_8c.html#autotoc_md17',1,'']]],
  ['0x32_20—_20no_20conversion_20needed_1',['KW007_I2C_ADDRESS = 0x32 — no conversion needed.',['../kw007__hal__ftdi_8cpp.html#autotoc_md13',1,'']]],
  ['0x32_20—_20pass_20directly_2',['(7-bit address shifted left by 1). KW007 = 0x32 — pass directly.',['../kw007__hal__stm32_8c.html#autotoc_md15',1,'']]]
];
