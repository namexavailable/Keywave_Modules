var _k_w007__api_8c =
[
    [ "KW007_State", "_k_w007__api_8c.html#struct_k_w007___state", [
      [ "model", "_k_w007__api_8c.html#a53280cabebf32db32f43ff0ddf101be4", null ]
    ] ],
    [ "KW007_GetModel", "_k_w007__api_8c.html#a8cd66242ab815cd0aeb4b2b9455cccbe", null ],
    [ "KW007_Init", "_k_w007__api_8c.html#a86784c228b8930aceee4b806e00aaf84", null ],
    [ "KW007_Read", "_k_w007__api_8c.html#a385cea3502606206bf1a2da81b83eb2d", null ],
    [ "KW007_SetDetectionRange", "_k_w007__api_8c.html#adbb3bd41ee31286f62485142fbfef392", null ],
    [ "KW007_SetEnhancedMode", "_k_w007__api_8c.html#a7a56becedf387ce2b45d2687482eff35", null ],
    [ "KW007_SetFastSpeedDetection", "_k_w007__api_8c.html#a307b76785210995d157325310e8298fe", null ],
    [ "KW007_SetGain", "_k_w007__api_8c.html#a0732cd1440e7f9eaeaef19238ee12918", null ],
    [ "KW007_SetGPO_DelayDuration", "_k_w007__api_8c.html#a1938ea4abe74fe89331840bcb5db9df5", null ],
    [ "KW007_SetSamplingRate", "_k_w007__api_8c.html#aa3643b99660e8847a981486396085ccf", null ],
    [ "KW007_SetSlowSpeedDetection", "_k_w007__api_8c.html#a0406d0570fff7080256c72956d6665a5", null ],
    [ "KW007_SetThreshold", "_k_w007__api_8c.html#a299cb34f3e4db4c36aa043bc8e4cce86", null ],
    [ "_state", "_k_w007__api_8c.html#a610fb68882897d3b604f2d33503d5c84", null ]
];