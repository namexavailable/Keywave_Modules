var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", null ],
    [ "User_platform", "dir_d0e8c0e06ec1223222e88f9214601245.html", "dir_d0e8c0e06ec1223222e88f9214601245" ],
    [ "KW007_api.c", "_k_w007__api_8c.html", "_k_w007__api_8c" ],
    [ "KW007_api.h", "_k_w007__api_8h.html", null ],
    [ "kw007_hal.h", "kw007__hal_8h.html", null ],
    [ "kw007_reg.c", "kw007__reg_8c.html", "kw007__reg_8c" ],
    [ "kw007_reg.h", "kw007__reg_8h.html", null ]
];