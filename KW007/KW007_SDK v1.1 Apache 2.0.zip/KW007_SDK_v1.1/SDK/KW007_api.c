/**
 * PDX-License-Identifier: Apache-2.0
 * Copyright 2026 Keywave Technology Limited
 */


/**
 * ============================================================
 *  KW007_api.c — User API Implementation
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.1
 *  Released: 2026-04-19
 *
 *  High-level functions for application developers.
 *  Register-level operations are in kw007_reg.c.
 * ============================================================
 */

#include <string.h>
#include "KW007_api.h"
#include "kw007_reg.h"

/* ─── INTERNAL STATE ─────────────────────────────────────── */
typedef struct {
    KW007_Model model;
} KW007_State;

static KW007_State _state;

/* ─── KW007_Init ─────────────────────────────────────────────
 * Official 4-step startup sequence:
 *   1. Write R09 = 0x10  (fuse mode — enables R01 VCO bank readout)
 *   2. Read  R01[5:0]    (factory-burned VCO bank)
 *   3. Set   R12[5:0]    = VCO bank value in init array
 *   4. Write R00-R30     with R09 = 0x30 (I2C manual mode)
 *   ** R31 is never written under any circumstances **
 */
uint8_t KW007_Init(void)
{
    uint8_t vcoBank = 0;
    uint8_t sensorId = 0;
    uint8_t regs[31];

    /* Step 1: fuse mode */
    if (kw007_reg_write(REG_MANUAL_MODE, 0x10)) return KW007_ERR_I2C;

    /* Step 2: read factory VCO bank */
    if (kw007_reg_read(REG_VCO_FUSE, &vcoBank)) return KW007_ERR_NO_DEVICE;
    vcoBank &= MASK_SEL_VCO;

    /* Auto-detect model from R31 while still in fuse mode */
    if (kw007_reg_read(REG_MODEL_ID, &sensorId)) {
        _state.model = KW007_UNKNOWN;
    } else if (sensorId == 0x01) {
        _state.model = KW007_S;   /* KW007-S and KW007-SE share R31=0x01 */
    } else if (sensorId == 0x81) {
        _state.model = KW007_L;
    } else {
        _state.model = KW007_UNKNOWN;
    }

    /* Step 3: patch VCO bank into register array
     * R12 layout:
     *   bit[7]    = sel_fs   (keep default)
     *   bit[6]    = pin_mode = 1 (must)
     *   bits[5:0] = sel_vco  = VCO bank
     */
    memcpy(regs, kw007_default_regs, 31);
    regs[12] = (kw007_default_regs[12] & MASK_SEL_FS) | MASK_PIN_MODE | vcoBank;

    /* Step 4: write R00-R30 (31 bytes); R09 is already 0x30 in kw007_default_regs */
    if (kw007_reg_write_block(0x00, regs, 31)) return KW007_ERR_I2C;

    return KW007_OK;
}

/* ─── KW007_Read ─────────────────────────────────────────── */
KW007_Data KW007_Read(void)
{
    KW007_Data data;
    uint8_t flags = 0, rssi = 0;

    memset(&data, 0, sizeof(data));
    data.ok = false;

    if (kw007_reg_read(REG_FLAGS, &flags)) return data;
    if (kw007_reg_read(REG_RSSI,  &rssi))  return data;

    data.ok          = true;
    data.approaching = (flags & FLAG_APPROACHING) != 0;
    data.leaving     = (flags & FLAG_LEAVING)     != 0;
    data.isDay       = (flags & FLAG_DAY_NIGHT)   != 0;
    data.rssi        = rssi;

    return data;
}

/* ─── KW007_SetDetectionRange ────────────────────────────── */
uint8_t KW007_SetDetectionRange(uint8_t range)
{
    typedef struct { uint8_t a1, a2, a3, th; bool enhanced; } Preset;
    static const Preset presets[9] = {
        {0, 0, 0,  0, false},  /* 0: unused           */
        {3, 0, 0, 45, false},  /* 1: ~15 cm (27 dB) */
        {5, 0, 0, 64, false},  /* 2: ~50 cm (32 dB) */
        {7, 1, 0, 90, false},  /* 3:  ~1 m  (44 dB) */
        {7, 4, 0, 90, false},  /* 4:  ~3 m  (53 dB) */
        {7, 7, 0, 90, false},  /* 5:  ~5 m  (64 dB) */
        {7, 7, 1, 64, false},  /* 6:  ~7 m  (68 dB) */
        {7, 7, 3, 32, false},  /* 7: ~10 m  (76 dB) */
        {7, 7, 3, 32, true },  /* 8: ~13 m  (76 dB + enhanced) */
    };
    if (range < 1 || range > 8) return KW007_ERR_PARAM;
    const Preset *p = &presets[range];
    uint8_t err;
    if ((err = KW007_SetGain(p->a1, p->a2, p->a3))) return err;
    if ((err = KW007_SetThreshold(p->th)))            return err;
    if ((err = KW007_SetEnhancedMode(p->enhanced)))   return err;
    return KW007_OK;
}

/* ─── KW007_SetGain ─────────────────────────────────────── */
uint8_t KW007_SetGain(uint8_t amp1, uint8_t amp2, uint8_t amp3)
{
    uint8_t r19 = 0, r20 = 0, err = 0;

    err |= kw007_reg_read(REG_AMP1_GAIN,      &r19);
    err |= kw007_reg_read(REG_AMP2_AMP3_GAIN, &r20);
    if (err) return KW007_ERR_I2C;

    r19 = (r19 & ~MASK_AMP1) | ((amp1 & 0x07) << 5);
    r20 = (r20 & ~(MASK_AMP2 | MASK_AMP3))
        | ((amp3 & 0x03) << 3)
        | (amp2  & 0x07);

    err |= kw007_reg_write(REG_AMP1_GAIN,      r19);
    err |= kw007_reg_write(REG_AMP2_AMP3_GAIN, r20);
    return err ? KW007_ERR_I2C : KW007_OK;
}

/* ─── KW007_SetThreshold ─────────────────────────────────── */
uint8_t KW007_SetThreshold(uint8_t threshold)
{
    return kw007_reg_write(REG_THRESHOLD, threshold) ? KW007_ERR_I2C : KW007_OK;
}

/* ─── KW007_SetEnhancedMode ──────────────────────────────── */
uint8_t KW007_SetEnhancedMode(bool enable)
{
    return kw007_reg_rmw(REG_ENHANCED_MODE,
                         MASK_ENHANCED,
                         enable ? MASK_ENHANCED : 0);
}

/* ─── KW007_SetGPO_DelayDuration ─────────────────────────────── */
uint8_t KW007_SetGPO_DelayDuration(KW007_DelayDuration delay)
{
    return kw007_reg_rmw(REG_GPO_DELAY,
                         MASK_TLIGHT,
                         ((uint8_t)delay << 1) & MASK_TLIGHT);
}

/* ─── KW007_SetSlowSpeedDetection ────────────────────────── */
uint8_t KW007_SetSlowSpeedDetection(bool enable)
{
    /* bit[5]=0 = slow detect ON; bit[5]=1 = slow detect OFF */
    return kw007_reg_rmw(REG_SLOW_SPEED,
                         MASK_SLOW_DET,
                         enable ? 0 : MASK_SLOW_DET);
}

/* ─── KW007_SetFastSpeedDetection ───────────────────────── */
uint8_t KW007_SetFastSpeedDetection(bool enable)
{
    return kw007_reg_rmw(REG_GPO_DELAY,
                         MASK_FAST_SPEED_DET,
                         enable ? MASK_FAST_SPEED_DET : 0);
}

/* ─── KW007_SetSamplingRate ──────────────────────────────── */
uint8_t KW007_SetSamplingRate(bool use500Hz)
{
    return kw007_reg_rmw(REG_VCO_CTRL,
                         MASK_SEL_FS,
                         use500Hz ? MASK_SEL_FS : 0);
}

/* ─── KW007_GetModel ─────────────────────────────────────── */
KW007_Model KW007_GetModel(void) { return _state.model; }
