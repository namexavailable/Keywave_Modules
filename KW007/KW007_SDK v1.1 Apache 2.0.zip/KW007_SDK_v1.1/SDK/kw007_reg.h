/**
 * PDX-License-Identifier: Apache-2.0
 * Copyright 2026 Keywave Technology Limited
 */


/**
 * ============================================================
 *  kw007_reg.h — Register-Level Interface
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.1
 *  Released: 2026-04-19
 *
 *  Low-level register definitions and I2C helpers.
 *  Most users should use KW007_api.h instead.
 *  Include this header for direct register access.
 *
 *  REGISTER MAP SUMMARY
 *  ─────────────────────────────────────────────────────────
 *  R01  REG_VCO_FUSE       bits[5:0] = factory VCO bank (read after R09=0x10)
 *  R05  REG_RSSI           signal strength (read-only)
 *  R06  REG_FLAGS          motion/day flags (read-only)
 *  R09  REG_MANUAL_MODE    bit[5]=I2C/fuse mode select
 *  R12  REG_VCO_CTRL       bit[7]=sample rate, bits[5:0]=VCO bank
 *  R19  REG_AMP1_GAIN      bits[7:5]=Gain1 (amp1)
 *  R20  REG_AMP2_AMP3_GAIN bits[2:0]=Gain2 (amp2), bits[4:3]=Gain3 (amp3)
 *  R21  REG_SLOW_SPEED     bit[5]=slow movement detection
 *  R24  REG_ENHANCED_MODE  bit[6]=enhanced range
 *  R27  REG_THRESHOLD      detection threshold 0-255
 *  R29  REG_GPO_DELAY      bits[2:1]=LightFlagDelay, bit[0]=fast speed detection
 *  R31  REG_MODEL_ID       0x01=KW007-S/SE, 0x81=KW007-L (READ-ONLY; KW007-SE shares 0x01)
 *
 *  CRITICAL — NEVER WRITE R31: permanently corrupts model ID on chip.
 * ============================================================
 */

#ifndef KW007_REG_H
#define KW007_REG_H

#include <stdint.h>
#include "kw007_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ─── I2C ADDRESS ──────────────────────────────────────────── */
#define KW007_I2C_ADDRESS   0x32   /* 8-bit write address (read = 0x33) */

/* ─── REGISTER ADDRESSES ───────────────────────────────────── */
#define REG_VCO_FUSE        0x01
#define REG_RSSI            0x05
#define REG_FLAGS           0x06
#define REG_MANUAL_MODE     0x09
#define REG_VCO_CTRL        0x0C
#define REG_AMP1_GAIN       0x13
#define REG_AMP2_AMP3_GAIN  0x14
#define REG_SLOW_SPEED      0x15
#define REG_ENHANCED_MODE   0x18
#define REG_THRESHOLD       0x1B
#define REG_GPO_DELAY       0x1D
#define REG_MODEL_ID        0x1F

/* ─── FLAG BITS (R06) ──────────────────────────────────────── */
#define FLAG_DAY_NIGHT      (1 << 3)   /* 1=day(operating), 0=night(rest) */
#define FLAG_APPROACHING    (1 << 2)   /* 1=approaching motion detected   */
#define FLAG_LEAVING        (1 << 1)   /* 1=leaving motion detected       */

/* ─── REGISTER BIT MASKS ───────────────────────────────────── */
/* R12 (REG_VCO_CTRL) */
#define MASK_SEL_FS         0x80   /* bit[7]    — 0=1kHz, 1=500Hz        */
#define MASK_PIN_MODE       0x40   /* bit[6]    — must=1 in I2C mode      */
#define MASK_SEL_VCO        0x3F   /* bits[5:0] — VCO bank                */
/* R19 (REG_AMP1_GAIN) */
#define MASK_AMP1           0xE0   /* bits[7:5] — bb_gain1                */
/* R20 (REG_AMP2_AMP3_GAIN) */
#define MASK_AMP2           0x07   /* bits[2:0] — bb_gain2                */
#define MASK_AMP3           0x18   /* bits[4:3] — bb_gain3                */
/* R21 (REG_SLOW_SPEED) */
#define MASK_SLOW_DET       0x20   /* bit[5]    — 0=slow ON, 1=slow OFF   */
/* R24 (REG_ENHANCED_MODE) */
#define MASK_ENHANCED       0x40   /* bit[6]    — enhanced range mode     */
/* R29 (REG_GPO_DELAY) */
#define MASK_FAST_SPEED_DET 0x01   /* bit[0]    — 0=fast speed OFF, 1=ON  */
#define MASK_TLIGHT         0x06   /* bits[2:1] — GPO hold duration       */

/* ─── DEFAULT REGISTER TABLE ──────────────────────────────── */
extern const uint8_t kw007_default_regs[31];

/* ─── REGISTER HELPERS ────────────────────────────────────── */

/** Write single register via I2C */
uint8_t kw007_reg_write(uint8_t reg, uint8_t value);

/** Read single register via I2C */
uint8_t kw007_reg_read(uint8_t reg, uint8_t *value);

/** Write consecutive registers (burst) */
uint8_t kw007_reg_write_block(uint8_t startReg, uint8_t *data, uint8_t len);

/** Read-Modify-Write: clear clearMask bits, then set setBits */
uint8_t kw007_reg_rmw(uint8_t reg, uint8_t clearMask, uint8_t setBits);

/* ─── ENGINEER API ────────────────────────────────────────── */

/**
 * Write register directly.
 * R31 (REG_MODEL_ID) is blocked — returns KW007_ERR_PARAM.
 */
uint8_t KW007_WriteReg(uint8_t reg, uint8_t value);

/** Read register directly. Result stored in *value. */
uint8_t KW007_ReadReg(uint8_t reg, uint8_t *value);

#ifdef __cplusplus
}
#endif

#endif /* KW007_REG_H */
