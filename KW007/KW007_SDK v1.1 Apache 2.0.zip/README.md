# Keywave SDK

Official open-source software development kit for integration with compatible
Keywave semiconductor products.

## Purpose

The Keywave SDK provides public software interfaces, device drivers, examples,
integration resources and related development materials to help developers,
OEMs, technology partners and researchers build applications using compatible
Keywave devices.

## Open-Source Licence

Unless otherwise indicated, the source code and documentation in this
repository are licensed under the Apache License, Version 2.0.

Subject to the terms of that licence, you may use, copy, modify, integrate,
publish and redistribute the licensed SDK components, including as part of
commercial products.

Keywave encourages the developer community to:

- Build applications using Keywave devices.
- Fork and improve the SDK.
- Create and publish integrations.
- Publish examples, tutorials, reviews and technical discussions.
- Redistribute the SDK with compatible products.
- Integrate the SDK into commercial products.

See `LICENSE` for the complete licence terms.

## Scope of This Repository

This repository provides public SDK software and integration resources.

It does not include Keywave device firmware, semiconductor design files,
confidential algorithms, production test information, private calibration
information, security credentials, foundry information or other confidential
or proprietary semiconductor technology unless Keywave expressly identifies
specific material otherwise.

The open-source licence applicable to this SDK does not change the licence
status of technology that is not included in this repository.

## Patents

The Apache License, Version 2.0 contains the patent licence set out in Section
3 of that licence. Nothing in this README expands, restricts or modifies the
rights granted by the Apache License, Version 2.0.

## Trademarks

The Apache License, Version 2.0 does not grant a general licence to use
Keywave Technology Limited's trade names, trademarks, service marks, logos
or product names.

Factual references to Keywave and Keywave products may be made to accurately
describe compatibility, integration, support or the origin of this software.

See `TRADEMARKS.md`.

## Contributions

Contributions are welcome. See `CONTRIBUTING.md` before submitting a pull
request or other contribution.

## Security

Please do not publish suspected security vulnerabilities through public issue
trackers. See `SECURITY.md` for reporting guidance.

## Third-Party Software

Any third-party software included in or distributed with this SDK remains
subject to its applicable licence terms. See `THIRD_PARTY_LICENSES.md`.
