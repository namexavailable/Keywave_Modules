# Third-Party Licences

This file records third-party software distributed with or incorporated into
the Keywave SDK.

Each third-party component remains subject to its own applicable licence terms.

## Components

No third-party components are listed at this time.

When adding a third-party dependency, record at least:

- Component name
- Version
- Project or source
- Copyright holder(s), where required
- Licence name and SPDX identifier, where available
- Required attribution or notice text
- Location within the Keywave SDK
