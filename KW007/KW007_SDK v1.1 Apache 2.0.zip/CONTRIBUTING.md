# Contributing to the Keywave SDK

Thank you for your interest in contributing to the Keywave SDK.

We welcome appropriate contributions including:

- Bug fixes
- Platform support
- Driver improvements
- API improvements
- Documentation improvements
- Example applications
- Integration examples
- Performance improvements
- Test improvements

## Contribution Licence

Unless you explicitly state otherwise, any contribution intentionally
submitted for inclusion in this project will be licensed under the Apache
License, Version 2.0, without additional terms or conditions, consistent with
Section 5 of that licence.

By submitting a contribution, you represent that you have the right to submit
the contribution under these terms.

## Confidential and Restricted Information

Do not submit confidential, proprietary, restricted or third-party information
that you are not authorised to disclose.

In particular, do not submit Keywave confidential information obtained under
an NDA, support agreement, development programme, commercial agreement or
other restricted relationship.

Do not submit:

- Non-public semiconductor design information
- Non-public device firmware
- Confidential algorithms
- Production or wafer test information
- Security keys or credentials
- Private calibration information
- Foundry or packaging information
- Non-public register or debug information
- Third-party proprietary code without appropriate permission

Public contributions should rely on interfaces and technical information
Keywave has made publicly available.

## Pull Requests

Where applicable, please provide:

1. A clear description of the proposed change.
2. The Keywave device and platform used for testing.
3. Relevant test results or reproduction steps.
4. Any new dependencies introduced.
5. The origin and licence of any third-party material.

Contributors should keep changes focused and should not combine unrelated
changes in the same pull request where reasonably avoidable.
