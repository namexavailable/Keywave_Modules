#ifndef _I2C_SYS_H_
#define _I2C_SYS_H_

#include "KW130_SDR.h"					// UINT8 / KW_bool

#ifdef __cplusplus
extern "C" {
#endif

// Implement these four functions on your host.
// The I2C functions return 1 on success, 0 if the transfer did not complete.
//
// NOTE on the page functions: regDataPtr is indexed by ABSOLUTE register address,
//      not from regAddr. I2C_pageWrite_Reg(devID, 23, buf, 11) sends buf[23]..buf[33].
//
// NOTE on KW_devID: it is the 8-bit WRITE address - a 7-bit slave address with the R/W
//      bit already in place as 0 - so put it on the bus unshifted.
//        write : 0xF2  0xB2  0x72  0x32     which one depends on the board strap
//        read  : 0xF3  0xB3  0x73  0x33     the same value with bit 0 set
//      A read is addressed with (KW_devID | 1). Shifting KW_devID left first is the
//      usual porting mistake and the part will not ACK.

KW_bool I2C_Write_Reg(UINT8 KW_devID, UINT8 regAddr, UINT8 regData);
KW_bool I2C_pageWrite_Reg(UINT8 KW_devID, UINT8 regAddr, UINT8* regDataPtr, UINT8 Len);
KW_bool I2C_pageRead_Reg(UINT8 devID, UINT8 regAddr, UINT8* regDataPtr, UINT8 Len);

// Blocking delay, used by the PLL lock sequence.
//   Must wait AT LEAST ms milliseconds. Waiting longer only makes tuning slower, never
//   wrong. Typical bodies: Sleep(ms) on Windows, HAL_Delay(ms) on STM32, or a calibrated
//   busy loop on bare metal.
//   Do not make it a no-op: the PLL needs time to settle after rst_atune is released and
//   again after pw0_vco is raised. A host that returns immediately will report false
//   KW_PLL_Unlock and will push the VCO current up for no reason.
void KW130_delay_ms(UINT16 ms);

#ifdef __cplusplus
}
#endif

#endif
