// KW130_SDR API
// Register logic only: no user interface and no transport. The four host functions it
// calls are declared in i2c_sys.h. Version history is in KW130_SDR.h.

#include "KW130_SDR.h"
#include "i2c_sys.h"

// KW130 devID has four options: 0x32 / 0x72 / 0xB2 / 0xF2
		UINT8	KW130_devID=KW130_IIC_Addr;
		UINT8	KW130_rData[KW130_REG_NUM];
		UINT8	KW130_vco_power = KW130_pw0_vco_start;	// pw0_vco the PLL locked at
		UINT8	KW130_pll_retry = 0;					// lock polls needed
		static UINT8	KW130_imr_polls = 0;		// internal: polls the last point needed
		KW130_imr_T	KW130_imr_result[KW130_imr_point_num] = {{0,0,0,0}};
		UINT32	KW130_imr_point_KHz[KW130_imr_point_num] = {0};
		UINT8	KW130_imr_valid[KW130_imr_point_num] = {0};
		static UINT8	KW130_imr_raw[3] = {0, 0, 0};	// internal: the last R5, R6, R7 read
static 	UINT8	KW130_reg[KW130_REG_NUM];

// GPO state. Kept here so it survives an initialise and every tune.
static	UINT8	gpo_level = 0;				// what the pin is driving
static	UINT8	gpo_auto  = 0;				// 1: the level follows the tuned frequency

// Tuning overrides. user_set says which groups the host has taken over; the values are
// held as validated register codes and outlive a tune.
#define KW_USR_RF_AGC		0x0001
#define KW_USR_BB_AGC		0x0002
#define KW_USR_AGC_SPEED	0x0004
#define KW_USR_GAIN(i)		(UINT16)(0x0008 << (i))		// one bit per gain block
#define KW_USR_LPF_COR		0x0080
#define KW_USR_TOP(i)		(UINT16)(0x0100 << (i))		// one bit per TOP
#define KW_USR_IMR		0x2000

// The five TOPs, in the order the KW_USR_TOP bits and top_map use.
#define KW_TOP_LNA			0
#define KW_TOP_RFBUF		1
#define KW_TOP_MIXERAMP	2
#define KW_TOP_FILTER		3
#define KW_TOP_BB			4
#define KW_TOP_NUM			5

// The four gain blocks, in the order the KW_USR_GAIN bits and the arrays below use.
#define KW_GAIN_LNA		0
#define KW_GAIN_RF			1
#define KW_GAIN_BB			2
#define KW_GAIN_FILT		3
#define KW_GAIN_NUM		4

static	UINT16	user_set = 0;				// bit per group, 0 = the API decides
static	UINT8	u_rf_vth, u_rf_vtl;			// R34
static	UINT8	u_bb_vth, u_bb_vtl;			// R35
static	UINT8	u_agc_speed;				// R36, group in bit 3 and rate in bits 2:0
static	UINT8	u_agc_rc;					// R37, a KW130_agc_rc_E
static	UINT8	u_gain_mode[KW_GAIN_NUM];		// KW130_gain_auto / KW130_gain_manual
static	UINT8	u_gain_step[KW_GAIN_NUM];
static	UINT8	u_lpf_cor;					// R41
static	UINT8	u_top[KW_TOP_NUM];
static	KW130_imr_T	u_imr = {0, 0, 0, 0};	// R43 / R44, the I/Q trim

// Where each gain block keeps its step and its auto/manual bit, and how far the step goes.
typedef struct {
	UINT8	reg;		UINT8	mask;		// the step
	UINT8	man_reg;	UINT8	man_mask;	// auto / manual
	UINT8	max;
}gain_map_T;

static const gain_map_T gain_map[KW_GAIN_NUM] = {
	{ 21, 0x1F, 14, 0x01, KW130_lna_gain_max  },	// lna_gain,  man_lna_gain
	{ 18, 0x0F, 18, 0x10, KW130_rf_gain_max   },	// rf_gain,   man_rf_gain
	{ 52, 0xF0, 53, 0x01, KW130_bb_gain_max   },	// BBamp_G,   man_BBamp_G
	{ 53, 0x0E, 53, 0x10, KW130_filt_gain_max }		// filt_G,    man_filt_G
};

// AGC clock and RC corner rates, as register codes. A host picks both with
// KW130_set_agc_speed().
enum agc_clkf_agc_E { clkf_agc_64k = 0, clkf_agc_16k = 1, clkf_agc_4k = 2, clkf_agc_1k = 3 };
enum agc_clks_agc_E { clks_agc_2k = 0, clks_agc_1k = 1, clks_agc_500 = 2, clks_agc_256 = 3,
					  clks_agc_125 = 4, clks_agc_32 = 5, clks_agc_8 = 6, clks_agc_2 = 7 };
enum agc_clkf_RC_E { clkf_RC_256k = 0, clkf_RC_64k = 1, clkf_RC_16k = 2, clkf_RC_4k = 3 };
enum agc_clks_RC_E { clks_RC_4k = 0, clks_RC_2k = 1, clks_RC_1k = 2, clks_RC_500 = 3,
					 clks_RC_256 = 4, clks_RC_64 = 5, clks_RC_16 = 6, clks_RC_4 = 7 };

// The eleven corner rates of KW130_agc_rc_E, as each group reaches them. KW_RC_NONE
// marks one that group cannot select; only 4 kHz is in both.
#define KW_RC_NONE		0xFF
static const UINT8 rc_of_fast[KW130_agc_rc_num] = {
	clkf_RC_256k, clkf_RC_64k, clkf_RC_16k, clkf_RC_4k,
	KW_RC_NONE, KW_RC_NONE, KW_RC_NONE, KW_RC_NONE, KW_RC_NONE, KW_RC_NONE, KW_RC_NONE
};
static const UINT8 rc_of_slow[KW130_agc_rc_num] = {
	KW_RC_NONE, KW_RC_NONE, KW_RC_NONE, clks_RC_4k,
	clks_RC_2k, clks_RC_1k, clks_RC_500, clks_RC_256,
	clks_RC_64, clks_RC_16, clks_RC_4
};

// Where each TOP lives, how far its step goes, and the API default. The step is the
// register code: for the last three that is how far below maximum.
typedef struct {
	UINT8	reg;		UINT8	mask;
	UINT8	max;		UINT8	dflt;
}top_map_T;

// KW_TOP_BB has no public setter. The API applies the default below and leaves it there.
static const top_map_T top_map[KW_TOP_NUM] = {
	{ 48, 0x1C, KW130_top_lna_max,      4 },		// KW_TOP_LNA      top_lna
	{ 48, 0xE0, KW130_top_rfbuf_max,    1 },		// TOP_RFBuf    top_rfdet
	{ 49, 0x07, KW130_top_mixeramp_max, 3 },		// TOPMixeramp  detgain_miamp
	{ 49, 0x38, KW130_top_filter_max,   4 },		// TOP_filter   detgain_filt
	{ 50, 0x0F, 15,                     7 }			// KW_TOP_BB       detgain_BB, no setter
};

// The VGA gain ladder, as the register pair each step needs. See the dB table in
// KW130_SDR.h.
static const UINT8 vga_att_of[KW130_vga_gain_max + 1] = {
	7, 6, 5, 4, 3, 2, 2, 2, 2, 2, 2, 2,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0
};

static const UINT8 vga_code_of[KW130_vga_gain_max + 1] = {
	 0,  0,  0,  0,  0,  0,  1,  2,  3,  4,  5,  6,
	 7,  8,  9, 10, 11, 12, 13, 14, 15, 15, 15
};

// The LPF corner, as the three fields the part spreads it over. BWS and mixeramp_swC
// widen the path for the corners the IF channel field alone cannot reach.
//   corner        BWS  swC  IF_CH_BW  default LPF_cor
typedef struct {
	UINT8	bws;		UINT8	swc;
	UINT8	ch_bw;		UINT8	cor;
	UINT8	eq1;		UINT8	eq2;
}lpf_map_T;

// The fine codes are measured. The equalisers come off for the three wide corners and
// are in the table, so tuning back down restores them.
//                                      bws swc ch_bw cor eq1 eq2
static const lpf_map_T lpf_map[KW130_lpf_num] = {
	{ 0, 0, 7, 22, 3, 1 },				//  6 MHz
	{ 0, 0, 6, 24, 3, 1 },				//  7 MHz
	{ 0, 0, 4, 24, 3, 1 },				//  8 MHz
	{ 0, 0, 0, 24, 3, 1 },				//  9 MHz
	{ 2, 1, 0, 17, 0, 0 },				// 12 MHz
	{ 3, 2, 0, 19, 0, 0 },				// 16 MHz
	{ 3, 2, 0, 26, 0, 0 }				// 20 MHz
};

// internal functions, in the order the bodies appear below
// reg tool
static void set_reg(UINT8 i, UINT8 mask, UINT8 value, UINT8* regkk);

// one field into the shadow
static void gpo_to_shadow(UINT8 level, UINT8* regkk);
static void agc_window_to_shadow(UINT8 reg, UINT8 vth, UINT8 vtl, UINT8* regkk);
static void agc_clk_to_shadow(UINT8 reg, UINT8 fast, UINT8 slow, UINT8* regkk);
static void agc_speed_to_shadow(UINT8 speed, UINT8 rc, UINT8* regkk);
static void gain_to_shadow(UINT8 which, UINT8 mode, UINT8 step, UINT8* regkk);
static void lpf_cor_to_shadow(UINT8 step, UINT8* regkk);
static void hpf_to_shadow(UINT8 corner, UINT8* regkk);
static void vga_to_shadow(UINT8 step, UINT8* regkk);
static void top_to_shadow(UINT8 which, UINT8 step, UINT8* regkk);
static void imr_to_shadow(KW130_imr_T imr, UINT8* regkk);
static KW_Status set_top(UINT8 which, UINT8 step);

// putting overrides back after a tune
static KW_Status write_one(UINT8 regAddr);
static void apply_gpo(UINT32 RF_KHz, UINT8* regkk);
static void apply_user(UINT8* regkk);
static KW_Status set_gain(UINT8 which, KW130_gain_mode_E mode, UINT8 step);

// xtal & pll
static KW_Status set_xtal(KW130_xtal_T, UINT8* reg);
static KW_Status set_pll(UINT32 LO_KHz, UINT16 xtal_freq_KHz, UINT8* reg);

// initial function
static void set_ini_table(UINT8* regkk);
static void set_lna_ini(UINT8* regkk);
static void set_RFbuf_ini(UINT8* regkk);
static void set_mixer_ini(UINT8* regkk);
static void set_mixeramp_ini(UINT8* regkk);
static void set_polyphase_ini(UINT8* regkk);
static void set_filter_ini(UINT8* regkk);
static void set_vga_ini(UINT8* regkk);
static void set_AGC_ini(UINT16 xtal_freq_KHz, UINT8* regkk);
static KW_Status KW130_power_on(UINT8* regkk);

// set tuner function
static void set_lna_tuner(UINT32 RF_KHz, UINT8* regkk);
static void set_RFbuf_tuner(UINT32 RF_KHz, UINT8* regkk);
static void set_mixeramp_tuner(UINT32 RF_KHz, UINT8* regkk);
static void set_filter_tuner(UINT8 lpf, UINT8 hpf, UINT8* regkk);
static void set_polyphase_tuner(UINT32 RF_KHz, UINT8 img_rev, UINT8* regkk);
static void set_AGC_tuner(UINT32 RF_KHz, UINT8* regkk);
//----------------------------------------------------------//
//        the register primitive                            //
//----------------------------------------------------------//

// Write value into the field selected by mask. The shift is derived from the mask, so
// callers pass the value unshifted.
void set_reg(UINT8 i, UINT8 mask, UINT8 value, UINT8* regkk)
{
	int shift_bit = 0;
	int j;
	UINT8 shift_value;
	for (j = 0; j < 8; j++) {
		if ((mask >> j) % 2 == 1) {
			shift_bit = j;
			break;
		}
	}
	shift_value = value << shift_bit;
	regkk[i] = (regkk[i] & ~mask) | shift_value;
}

//----------------------------------------------------------//
//        one field into the shadow                         //
//----------------------------------------------------------//

// Put a GPO level into the shadow. mode_gpi in R62 has to be 1 for the pin to be an
// output, so it goes out with the level.
void gpo_to_shadow(UINT8 level, UINT8* regkk)
{
	set_reg(62, 0x30, 1, regkk);				// mode_gpi = 1, GPIO drives as an output
	set_reg(63, 0x80, level, regkk);		// gpo_in
}

// One AGC detector window. R34 is the RF path, R35 the baseband path; the fields sit
// in the same places in both.
void agc_window_to_shadow(UINT8 reg, UINT8 vth, UINT8 vtl, UINT8* regkk)
{
	set_reg(reg, 0xF0, vth, regkk);			// lna_vth  / mix_vth
	set_reg(reg, 0x0F, vtl, regkk);			// lna_vtl  / mix_vtl
}

// One fast/slow clock pair. R36 is the AGC clock, R37 the RC corner.
void agc_clk_to_shadow(UINT8 reg, UINT8 fast, UINT8 slow, UINT8* regkk)
{
	set_reg(reg, 0x03, fast, regkk);		// clkf_agc / clkf_RC
	set_reg(reg, 0x1C, slow, regkk);		// clks_agc / clks_RC
}

// A speed and its RC corner into the shadow. Bit 3 of the speed picks the group, and
// only that group has its clock and corner fields written.
void agc_speed_to_shadow(UINT8 speed, UINT8 rc, UINT8* regkk)
{
	UINT8	group = (UINT8)((speed >> 3) & 1);
	UINT8	rate  = (UINT8)(speed & 0x07);

	set_reg(36, 0x20, 1, regkk);			// man_clk_agc_slow, the API always drives this
	set_reg(36, 0x40, group, regkk);		// clk_agc_slow, which group is in use

	if (group) {
		set_reg(36, 0x1C, rate, regkk);				// clks_agc
		set_reg(37, 0x1C, rc_of_slow[rc], regkk);	// clks_RC
	} else {
		set_reg(36, 0x03, rate, regkk);				// clkf_agc
		set_reg(37, 0x03, rc_of_fast[rc], regkk);	// clkf_RC
	}
}

// One TOP into the shadow.
void top_to_shadow(UINT8 which, UINT8 step, UINT8* regkk)
{
	set_reg(top_map[which].reg, top_map[which].mask, step, regkk);
}

// Behind all five public TOP functions.
KW_Status set_top(UINT8 which, UINT8 step)
{
	if (step > top_map[which].max)
		return KW_Bad_Param;

	u_top[which] = step;
	user_set |= KW_USR_TOP(which);

	apply_user(KW130_reg);
	return write_one(top_map[which].reg);
}

// One step of the VGA ladder. en_code_mode has to be 1 for vga_code to drive the gain
// at all, so it goes out with the step.
void vga_to_shadow(UINT8 step, UINT8* regkk)
{
	set_reg(13, 0x20, 1, regkk);						// en_code_mode
	set_reg(47, 0x0F, vga_code_of[step], regkk);		// vga_code
	set_reg(57, 0x70, vga_att_of[step], regkk);		// vga_att
}

// One gain block into the shadow.
void gain_to_shadow(UINT8 which, UINT8 mode, UINT8 step, UINT8* regkk)
{
	set_reg(gain_map[which].man_reg, gain_map[which].man_mask, mode, regkk);
	set_reg(gain_map[which].reg,     gain_map[which].mask,     step, regkk);
}

// The two filter trims into the shadow.
void lpf_cor_to_shadow(UINT8 step, UINT8* regkk)
{
	set_reg(41, 0x1F, step, regkk);			// LPF_cor
}

void hpf_to_shadow(UINT8 corner, UINT8* regkk)
{
	set_reg(42, 0x0F, corner, regkk);		// HPF_cor
}

//----------------------------------------------------------//
//        putting overrides back after a tune               //
//----------------------------------------------------------//

// Push one shadow register out, so a setter takes effect without a retune.
KW_Status write_one(UINT8 regAddr)
{
	return (I2C_Write_Reg(KW130_devID, regAddr, KW130_reg[regAddr]))
			? KW_Success : KW_I2C_Fail;
}

// Work out the level for this frequency and put it in the shadow. Called before the
// page write, so the ini table cannot clear the pin.
void apply_gpo(UINT32 RF_KHz, UINT8* regkk)
{
	if (gpo_auto)
		gpo_level = (RF_KHz > KW130_gpo_auto_KHz) ? 1 : 0;

	gpo_to_shadow(gpo_level, regkk);
}

// Put every override back into the shadow. Called from KW130_initial() and
// KW130_set_tuner() after the per-band defaults, so the host value wins.
void apply_user(UINT8* regkk)
{
	int	i;

	if (user_set & KW_USR_RF_AGC)
		agc_window_to_shadow(34, u_rf_vth, u_rf_vtl, regkk);
	if (user_set & KW_USR_BB_AGC)
		agc_window_to_shadow(35, u_bb_vth, u_bb_vtl, regkk);
	if (user_set & KW_USR_AGC_SPEED)
		agc_speed_to_shadow(u_agc_speed, u_agc_rc, regkk);

	for (i = 0; i < KW_GAIN_NUM; i++)
		if (user_set & KW_USR_GAIN(i))
			gain_to_shadow((UINT8)i, u_gain_mode[i], u_gain_step[i], regkk);

	if (user_set & KW_USR_LPF_COR)
		lpf_cor_to_shadow(u_lpf_cor, regkk);

	for (i = 0; i < KW_TOP_NUM; i++)
		if (user_set & KW_USR_TOP(i))
			top_to_shadow((UINT8)i, u_top[i], regkk);

	if (user_set & KW_USR_IMR)
		imr_to_shadow(u_imr, regkk);
}

// Behind all four public gain functions. The step and the auto/manual bit are not
// always in the same register, so both are pushed out.
KW_Status set_gain(UINT8 which, KW130_gain_mode_E mode, UINT8 step)
{
	KW_Status	result;

	if ((UINT8)mode > 1 || step > gain_map[which].max)
		return KW_Bad_Param;

	u_gain_mode[which] = (UINT8)mode;
	u_gain_step[which] = step;
	user_set |= KW_USR_GAIN(which);

	apply_user(KW130_reg);

	result = write_one(gain_map[which].man_reg);
	if (result == KW_Success && gain_map[which].reg != gain_map[which].man_reg)
		result = write_one(gain_map[which].reg);

	return result;
}

//----------------------------------------------------------//
//        crystal and PLL                                   //
//----------------------------------------------------------//

KW_Status set_xtal(KW130_xtal_T xtal_T, UINT8* reg) {
/*------------------------------------------------------------------------------
--| DESCRIPTION   : 1. xtal cap, 2. . Share Mode (pwd_xtal,pwd_xtalldo,pw0_xtal,en_xtaldet)
--| RETURN VALUE  : 1: success, 	0:fail (I2C Fail)
--|---------------------------------------------------------------------------*/

	KW_bool			i2c_status = 1;											// 1: normal, 0:fail
	UINT8		    en_xtaldet = 1;											// Xtal Detector Setting may modify in the future
	UINT8			KW130_pw0_xtal = 3;             						//min xtal power & xtal CAL start point
	set_reg(63, 0x1F, xtal_T.cap_x, reg);									// set xtal_cap

	i2c_status &= I2C_Write_Reg(KW130_devID, 63, reg[63]);					// write xtal cap & clock out to i2c
	switch (xtal_T.share_mode) {											// xtal pw, ldo switch by share mode
		default:
		case 0:		//no share
				en_xtaldet = 1;
				KW130_pw0_xtal = 3;
				set_reg(10, 0x03, 0, reg);										// pwd_xtalldo=0 , pwd_xtal=0
				set_reg(10, 0x80, en_xtaldet, reg);								// xtal AAC (Auto-Amplitude Control)
				set_reg(22, 0x0F, KW130_pw0_xtal, reg);
				i2c_status &= I2C_Write_Reg(KW130_devID, 10, reg[10]);
				i2c_status &= I2C_Write_Reg(KW130_devID, 22, reg[22]);
			break;
		case 1:		//share mode, tuner master
				en_xtaldet = 1;
				KW130_pw0_xtal = 8;												// fix pw0_xtal=8
				set_reg(10, 0x03, 0, reg);										// pwd_xtalldo=0 , pwd_xtal=0
				set_reg(10, 0x80, en_xtaldet, reg);								// xtal AAC (Auto-Amplitude Control)
				set_reg(22, 0x0F, KW130_pw0_xtal, reg);
				i2c_status &= I2C_Write_Reg(KW130_devID, 10, reg[10]);
				i2c_status &= I2C_Write_Reg(KW130_devID, 22, reg[22]);
			break;
		case 2:		//share mode, tuner slave , clock in to xtal_out pin
				en_xtaldet = 0;
				KW130_pw0_xtal = 0;
				set_reg(10, 0x03, 1, reg);										// pwd_xtalldo=0 , pwd_xtal=1
				set_reg(10, 0x80, en_xtaldet, reg);								// en_xtaldet=0 at slave mode
				set_reg(22, 0x0F, KW130_pw0_xtal, reg);
				set_reg(33, 0x04, 0, reg);                                      // sel_xixo = 0 (xo)
				i2c_status &= I2C_Write_Reg(KW130_devID, 10, reg[10]);
				i2c_status &= I2C_Write_Reg(KW130_devID, 22, reg[22]);
				i2c_status &= I2C_Write_Reg(KW130_devID, 33, reg[33]);
			break;
	}
	return (i2c_status) ? KW_Success : KW_I2C_Fail;

}

KW_Status set_pll(UINT32 LO_KHz, UINT16 xtal_freq_KHz, UINT8* reg) {
/*------------------------------------------------------------------------------
--| DESCRIPTION   : set LO (PLL) freqeuency setting
--| RETURN VALUE  : 1: success, 0:fail (I2C Fail)
--|---------------------------------------------------------------------------*/

	 KW_bool	i2c_status = 1;
// Control Parameter
	 KW_bool	en_sdm_bound = 1;		//enable sdm bound function for boundary spur reduce
	 UINT8	sdm_bit_num = 16;		// SDM is 16bit at KT110
	 UINT32 VCO_Min = 4096000;   	//4096 MHz
	 UINT32 VCO_Max = 8192000;	  	//VCO_Min * 2;
	 UINT32	VCO_for_div4 = 6000000;	//6000MHz
// PLL_Ref = xtal_freq_KHz /1/2/3/4
	 UINT8	div_clk_pll = 0;						// 0:/1, 1:/2, 2:/3, 3:/4
	 UINT16	PLL_Ref = 0;
	 UINT16 LoDiv = 2;                              // Min LO Divider Number
	 UINT16 DivBuf = 0;
	 UINT8  sel_div = 0;							// 0:/1, 1:/2, 2:/4, 3:/8, 4:/16, 5:/32
	 UINT8  vco_power = KW130_pw0_vco_start;
//operation
	 PLL_Ref = xtal_freq_KHz / (div_clk_pll + 1);
//Divider
	 while (LoDiv <= 256)
	 {
		 if  ((LO_KHz * LoDiv) >= VCO_Max)
			break;
		 else if (((LO_KHz * LoDiv) >= VCO_Min) && ((LO_KHz * LoDiv) < VCO_Max))
		 {
			 DivBuf = LoDiv;
			 while (DivBuf > 8)
			 {
				 DivBuf = DivBuf >> 1;
				 sel_div++;					// sel_div = 0:/1, 1:/2, 2:/4, 3:/8, 4:/16, 5:/32
			 }
			 break;
		 }
		 LoDiv = LoDiv << 1;
	 }

	 if (LoDiv > 256) {                                                              //LO<32MHz
				sel_div=5;
				LoDiv=256;
	 }

	 UINT8   sel_div1 = (LoDiv ==2);
	 UINT8   iqgen_div2 = (LoDiv < 8);
	 UINT32  VCO_Freq = LO_KHz * LoDiv;
	 KW_bool	 sel_vco_div24 = (VCO_Freq > VCO_for_div4);						// 0: VCO/2 to NScnt, 1: vco/4 to NScnt
	 UINT8	 Npre_div = 2 * (sel_vco_div24 + 1);							// Prescaler = VCO/2 or VCO/4
	 UINT16  Nint = (UINT16)(VCO_Freq / Npre_div / PLL_Ref);
	 UINT32	 Nint_m = Nint << sdm_bit_num;
	 UINT32  VCO_Frac = (VCO_Freq - PLL_Ref * Nint * Npre_div);					//VCO_Fra = VCO_Freq - VCO_Freq_by_Nint
	 UINT16  Nfra_m = (UINT16)(((VCO_Frac << (sdm_bit_num - 2)) / Npre_div) / (PLL_Ref >> 2));
	 // Nfra known as 0~65535/2^16, and  Nfra_m = Nfra * 2^16
	 // Nfra_m = VCO_Fra shift 16bit / Presclaer / Ref = VCO_F  (to prevent overflow 32bit, 2bit merge to Ref/4)
//Boundary spur prevention      (max offset would be 47kHz if using 24MHz xtal)
	 UINT16  Nfra_m_bound;		//Bondary Limited Nfra
	 if (en_sdm_bound == 1) {
		 if (Nfra_m < 256)  // 65536 * 2^-8   1<<(sdm_bit_num-7)
			 Nfra_m_bound = 0;
		 else if (Nfra_m > (65535 - 256))  //65535-(65536*2^-8)
		 {
			 Nfra_m_bound = 0;
			 Nint++;
		 }
		 else if ((Nfra_m > (32768 - 128)) && (Nfra_m < 32768))
			 Nfra_m_bound = 32768 - 128;
		 else if ((Nfra_m < (32768 + 128)) && (Nfra_m >= 32768))
			 Nfra_m_bound = 32768 + 128;
		 else
			 Nfra_m_bound = Nfra_m;
	 }
	 else
		 Nfra_m_bound = Nfra_m;
	 UINT8 Ni = (UINT8)((Nint - 13) / 4);
	 UINT8 Si = (UINT8)(Nint - 4 * Ni - 13);
	 UINT8 SDM_MSB = (UINT8)((Nfra_m_bound & 0xFF00) >> 8);
	 UINT8 SDM_LSB = (UINT8)(Nfra_m_bound & 0x00FF);
	 KW_bool pwd_sdm = (Nfra_m_bound == 0);


// SDR Use
	 set_reg(5, 0x02, sel_div1, reg);
	 set_reg(5, 0x04, iqgen_div2, reg);
	i2c_status &= I2C_Write_Reg(KW130_devID, 5, reg[5]);

	 // Write Result to regkk
	 set_reg(23, 0x03, Si, reg);
	 set_reg(23, 0xFC, Ni, reg);
	 set_reg(24, 0xFF, SDM_LSB, reg);
	 set_reg(25, 0xFF, SDM_MSB, reg);
	 set_reg(26, 0x07, sel_div, reg);
	 set_reg(26, 0x08, sel_vco_div24, reg);
	 set_reg(26, 0x10, pwd_sdm, reg);
	 set_reg(27, 0xC0, 2, reg);					//pw0_cp=2;
		vco_power = KW130_pw0_vco_start;
	 set_reg(28, 0x0F, vco_power, reg);			//pw0_vco;
	 set_reg(28, 0x10, 0, reg);					//iqgen_swl=0;
	 set_reg(28, 0x20, 0, reg);					//iqgen_swi=0;
	 set_reg(29, 0x01, 1, reg);					//en_pfd_offset=1;
	 set_reg(29, 0x02, 1, reg);					//en_sah_lf=1;
	 set_reg(30, 0x80, 1, reg);					//en_autopw=1;
	 set_reg(33, 0x60, div_clk_pll, reg);		//div_clk_pll
	 set_reg(26, 0x40, 1, reg);					// rst_atune=1

	i2c_status &= I2C_pageWrite_Reg(KW130_devID, 23, KW130_reg, 11);		//Page Write R23 ~ R33
	set_reg(26, 0x40, 0, reg);					// rst_atune=0
	i2c_status &= I2C_Write_Reg(KW130_devID, 26, reg[26]);

	// Wait for the auto-tune to settle before the first poll: reading the lock flag too
	// early reports a failure that is not there. Raising pw0_vco does not need a second
	// rst_atune. 1 ms covers both waits.
	 UINT8 time_out = 0;
	 UINT8 lock_flag = 0;						// done flag

	 KW130_delay_ms(KW130_pll_settle_ms);		// rst_atune released -> let the search run
	 do
	 {
		i2c_status &= I2C_pageRead_Reg(KW130_devID, 4, KW130_rData, 1);
		if ((KW130_rData[4] & 0x80) != 0)
		{
			lock_flag = 1;
			break;
		}
		if (vco_power < KW130_pw0_vco_max)
		{
			vco_power++;
			set_reg(28, 0x0F, vco_power, reg);		//pw0_vco
			i2c_status &= I2C_Write_Reg(KW130_devID, 28, reg[28]);
		}
		KW130_delay_ms(KW130_pll_settle_ms);		// VCO restarts / the search carries on
		time_out++;
	 } while (time_out < KW130_pll_retry_max);

	 KW130_vco_power = vco_power;				// diagnostics for the host
	 KW130_pll_retry = time_out;
	// tell an I2C failure apart from a VCO that never locked
	if (i2c_status == 0)
		return KW_I2C_Fail;
	if (lock_flag == 0)
		return KW_PLL_Unlock;

	 return KW_Success;
}

//----------------------------------------------------------//
//        initialise                                        //
//----------------------------------------------------------//

void set_ini_table(UINT8* regkk) {
/*------------------------------------------------------------------------------
--| FUNCTION NAME : set_ini_table
--| DESCRIPTION   : PowerOn and Set the status for SDR Tuner
--|---------------------------------------------------------------------------*/
	UINT8 ini_array[64] =
				  { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,	//R0~R7
					0x00,0xC4,0x9C,0x40,0x00,0x20,0xD8,0x15,	//R8~R15
					0x04,0x00,0x20,0x29,0xA2,0x10,0x48,0x62,	//R16~R23
					0x55,0xD5,0x00,0x00,0xC8,0x07,0x82,0x00,	//R24~R31
					0x3F,0x18,0x86,0x86,0x0D,0x09,0x87,0x0A,	//R32~R39
					0xC9,0x10,0x08,0x00,0x00,0x00,0x00,0x00,	//R40~R47
					0x92,0x00,0x08,0x55,0x86,0xA8,0x7F,0x8E,	//R48~R55
					0x3F,0x00,0x00,0xC0,0xD7,0x00,0x1C,0x60	};	//R56~R63

	for (int i = 0; i < 64; i++) {
		regkk[i] = ini_array[i];
	}

}

void set_lna_ini(UINT8* regkk)
{
	set_reg(15, 0x03, 1, regkk); // pw0_lna = 1
	set_reg(15, 0x0C, 1, regkk); // pw1_lna = 1
	set_reg(15, 0x30, 1, regkk); // pw3_lna = 1
}

void set_RFbuf_ini(UINT8* regkk)
{
	set_reg(18, 0x0F, 8, regkk); // rf_gain = 8
	set_reg(19, 0x04, 0, regkk); // pw0_rfbuf = 0
	set_reg(19, 0x18, 1, regkk); // pw1_rfbuf = 1
}

void set_mixer_ini(UINT8* regkk)
{
	set_reg(20, 0x03, 2, regkk); // pw_mix = 2

}

void set_mixeramp_ini(UINT8* regkk)
{
	set_reg(51, 0x03, 2, regkk); // mixeramp_current = 2
	set_reg(53, 0xC0, 0, regkk); // mixeramp_glimit
	set_reg(60, 0x03, 3, regkk); // BB_det_ch2 = 3
	set_reg(60, 0x0C, 1, regkk); // PdectMixampCH = 1
	set_reg(60, 0x30, 1, regkk); // PdectMixampHPF = 1
	set_reg(60, 0x40, 1, regkk); // det_mixeramp_rl = 1
	set_reg(60, 0x80, 1, regkk); // det_mixeramp_LPF_r = 1
}

void set_polyphase_ini(UINT8* regkk)
{
	set_reg(40, 0xC0, 0x03, regkk); // polygain = 3
	set_reg(51, 0x0C, 0x02, regkk); // polyphase_filter_current = 2
}

void set_filter_ini(UINT8* regkk)
{
	set_reg(51, 0x30, 2, regkk); // pw_1th_LPF = 2
	set_reg(51, 0xC0, 0, regkk); // pw_2nd_LPF = 0
	set_reg(52, 0x03, 0, regkk); // pw_HPF = 0
}

// The parts of the VGA that do not depend on the gain asked for.
void set_vga_ini(UINT8* regkk)
{
	set_reg(52, 0x0C, 0, regkk); 			// pw_vga, lowest current
	set_reg(55, 0x60, 0, regkk); 			// vga_EQ, no equalisation
}

void set_AGC_ini(UINT16 xtal_freq_KHz, UINT8* regkk) {

	if (xtal_freq_KHz > 20000)
		set_reg(20, 0x80, 1, regkk); // clk_agc/3
	else
		set_reg(20, 0x80, 0, regkk); // clk_agc/2
}

KW_Status KW130_power_on(UINT8* regkk){

	KW_bool		status = 1;								// 1: SUCCESS,	 0: Fail
	set_reg(9, 0x0C, 3, regkk);							// en_lna=1 , en_BG=1
	set_reg(9, 0xE0, 7, regkk);							// en_pll,en_mixer,en_rfbuf
	set_reg(10, 0x0C, 3, regkk);	 					// en_lna_rf_det,en_BB
	set_reg(10, 0x02, 0, regkk);	 					// pwd_xtalldo=0
	set_reg(11, 0x03, 0, regkk);	 					// pwd_agc=0, pwd_ldo_apr=0

	status &= I2C_pageWrite_Reg(KW130_devID, 9, KW130_reg, 3);
	return (status) ? KW_Success : KW_I2C_Fail;
}

//----------------------------------------------------------//
//        per tune                                          //
//----------------------------------------------------------//

// set tuner local function
void set_lna_tuner(UINT32 RF_KHz, UINT8* regkk)
{
	enum TF_LNA_enum {
		reg_TF = 17,
		mask_TF = 0x7F,
	};

	UINT8 TF_array_LF[26] = {127,127,127,127,127,127,63,48,   // 0,8,16,24,32,40,48,56,MHz
							 32,24,15,10,6,2,0,0,   	      // 64,72,80,88,96,104,112,120MHz,
							 0,0,0,0,0,0,0,0,                 // 128,136,144,152,160,168,176,184MHz
							 0,0};	  						  // 192,200MHz


	UINT8 TF_array_MF[30] = {63,53,43,31,28,26,  		  	  // 208,216,224,232,240,248 MHz
							 24,22,20,18,17,16,15,14,   	  // 256,264,272,280,288,296,304,312 MHz
							 13,12,11,10,10, 9, 9, 8,    	  // 320,328,336,344,352,360,368,376 MHz
							 8,7,7,6,6,5,4,3};                // 384,392,400,408,416,424,432,440 MHz

	int i_LF = (int)RF_KHz / 8000;
		i_LF = (i_LF > (int)(sizeof(TF_array_LF)-1)) ? (int)(sizeof(TF_array_LF)-1) : i_LF;	// clamp to the table

	int i_MF = (int)RF_KHz / 8000 - 26;
		i_MF = (i_MF<0) ? 0 :i_MF;
		i_MF = (i_MF > (int)(sizeof(TF_array_MF)-1)) ? (int)(sizeof(TF_array_MF)-1) : i_MF;	// clamp to the table

//UHF
	if (RF_KHz > 2300000)			set_reg(reg_TF, mask_TF, 0, regkk);
	else if (RF_KHz > 2200000)      set_reg(reg_TF, mask_TF, 1, regkk);
	else if (RF_KHz > 2100000)      set_reg(reg_TF, mask_TF, 2, regkk);
	else if (RF_KHz > 2000000)      set_reg(reg_TF, mask_TF, 3, regkk);
	else if (RF_KHz > 1900000)      set_reg(reg_TF, mask_TF, 4, regkk);
	else if (RF_KHz > 1800000)      set_reg(reg_TF, mask_TF, 5, regkk);
	else if (RF_KHz > 1700000)      set_reg(reg_TF, mask_TF, 6, regkk);
	else if (RF_KHz > 1600000)      set_reg(reg_TF, mask_TF, 7, regkk);
//HF   (12nH)
	else if (RF_KHz > 1050000)      set_reg(reg_TF, mask_TF, 0, regkk);
	else if (RF_KHz > 1000000)      set_reg(reg_TF, mask_TF, 1, regkk);
	else if (RF_KHz > 950000)       set_reg(reg_TF, mask_TF, 2, regkk);
	else if (RF_KHz > 900000)       set_reg(reg_TF, mask_TF, 4, regkk);
	else if (RF_KHz > 850000)       set_reg(reg_TF, mask_TF, 6, regkk);
	else if (RF_KHz > 800000)       set_reg(reg_TF, mask_TF, 8, regkk);
	else if (RF_KHz > 750000)       set_reg(reg_TF, mask_TF, 11, regkk);
	else if (RF_KHz > 700000)       set_reg(reg_TF, mask_TF, 14, regkk);
//MF   (33nH)
	else if (RF_KHz > 500000)       set_reg(reg_TF, mask_TF, 0, regkk);
	else if (RF_KHz > 440000)       set_reg(reg_TF, mask_TF, 3, regkk);
	else if (RF_KHz > 200000)       set_reg(reg_TF, mask_TF, TF_array_MF[i_MF], regkk); // TF
//LF   (270nH)
	else                            set_reg(reg_TF, mask_TF, TF_array_LF[i_LF], regkk); // TF

	if (RF_KHz > 1600000){
		set_reg(16, 0x30, 0, regkk); 			// Band = UHF
		set_reg(14, 0x08, 0x00, regkk); 		// en_qlimit = 0
		set_reg(14, 0x10, 0x00, regkk); 		// qlimit = 0
		set_reg(14, 0x60, 0x02, regkk); 		// Qbst = 2
	}
	else if (RF_KHz > 700000){
		set_reg(16, 0x30, 1, regkk); 			// Band = HF
		set_reg(14, 0x08, 0x00, regkk); 		// en_qlimit = 0
		set_reg(14, 0x10, 0x00, regkk); 		// qlimit = 0
		set_reg(14, 0x60, 0x02, regkk); 		// Qbst = 2
		}
	else if (RF_KHz > 200000){
		set_reg(16, 0x30, 2, regkk); 			// Band = MF
		set_reg(14, 0x08, 0x01, regkk); 		// en_qlimit = 1
		set_reg(14, 0x10, 0x00, regkk); 		// qlimit = 0
		set_reg(14, 0x60, 0x01, regkk); 		// Qbst = 1
		}
	else {
		set_reg(16, 0x30, 3, regkk); 			// Band = LF
		set_reg(14, 0x08, 0x01, regkk); 		// en_qlimit = 1
		set_reg(14, 0x10, 0x00, regkk); 		// qlimit = 0
		set_reg(14, 0x60, 0x00, regkk); 		// Qbst = 0
		}

		top_to_shadow(KW_TOP_LNA, top_map[KW_TOP_LNA].dflt, regkk);

}

void set_RFbuf_tuner(UINT32 RF_KHz, UINT8* regkk)
{
// RF TOP Setup

		top_to_shadow(KW_TOP_RFBUF, top_map[KW_TOP_RFBUF].dflt, regkk);

// RF Poly Setup
	UINT8 RF_poly = 0;

	if (RF_KHz <= 130000)          	RF_poly = 2;
	else if (RF_KHz <= 200000)      RF_poly = 1;
	else if (RF_KHz <= 1024000)     RF_poly = 0;
	else                            RF_poly = 3;

	set_reg(16, 0xC0, RF_poly, regkk); // poly_mux

// RF LPF Setup
	UINT8 RF_LPF = 0;

	if (RF_KHz <= 130000)           RF_LPF = 3;
	else if (RF_KHz <= 170000)      RF_LPF = 2;
	else if (RF_KHz <= 250000)      RF_LPF = 1;
	else                            RF_LPF = 0;
	set_reg(18, 0xC0, RF_LPF, regkk); // rf_lpf = 0x00

	if (RF_KHz <= 1024000) {
	set_reg(5,  0x08, 0, regkk); // lovcm_up = 0
	set_reg(5,  0x10, 0, regkk); // en_rfdet_ibst = 0
	set_reg(20, 0x03, 2, regkk); // pw_mix = 2
	set_reg(20, 0x0C, 0, regkk); // LO_vcm = 0 (1.6V)
	set_reg(20, 0x30, 2, regkk); // LO_vdd = 2
	set_reg(20, 0x40, 0, regkk); // rfvcm = 0
	}
	else {
	set_reg(5,  0x08, 1, regkk); // lovcm_up = 1
	set_reg(5,  0x10, 1, regkk); // en_rfdet_ibst = 1
	set_reg(20, 0x03, 3, regkk); // pw_mix = 3
	set_reg(20, 0x0C, 2, regkk); // LO_vcm = 2 (2.0V)
	set_reg(20, 0x30, 0, regkk); // LO_vdd = 0
	set_reg(20, 0x40, 1, regkk); // rfvcm = 1
    }

}

void set_mixeramp_tuner(UINT32 RF_KHz , UINT8* regkk)
{
	enum TOP_BB_enum {
		reg_BB_top = 50,
		mask_BB_top = 0x0F,
		BB_top_0 = 15, BB_top_1 = 14, BB_top_2 = 13, BB_top_3 = 12,
		BB_top_4 = 11, BB_top_5 = 10, BB_top_6 = 9, BB_top_7 = 8,
		BB_top_8 = 7, BB_top_9 = 6, BB_top_10 = 5, BB_top_11 = 4,
		BB_top_12 = 3, BB_top_13 = 2, BB_top_14 = 1, BB_top_15 = 0,
	};


	top_to_shadow(KW_TOP_MIXERAMP, top_map[KW_TOP_MIXERAMP].dflt, regkk);
	top_to_shadow(KW_TOP_BB, top_map[KW_TOP_BB].dflt, regkk);

}

// The channel the host asked for. The LPF corner needs three fields set together, so
// they come out of one table; the HPF corner is a single field. The LPF fine trim gets
// the default for this corner, and KW130_set_lpf_cor() overrides it afterwards.
void set_filter_tuner(UINT8 lpf, UINT8 hpf, UINT8* regkk)
{

	top_to_shadow(KW_TOP_FILTER, top_map[KW_TOP_FILTER].dflt, regkk);			// Top_Filter

	set_reg(6, 0x03, lpf_map[lpf].bws, regkk);							// BWS
	set_reg(6, 0x0C, lpf_map[lpf].swc, regkk);							// mixeramp_swC
	set_reg(41, 0xE0, lpf_map[lpf].ch_bw, regkk);						// IF_CH_BW, the LPF corner
	set_reg(56, 0x18, lpf_map[lpf].eq1, regkk);							// eq_1th_LPF
	set_reg(56, 0x60, lpf_map[lpf].eq2, regkk);							// eq_2nd_LPF

	lpf_cor_to_shadow(lpf_map[lpf].cor, regkk);
	hpf_to_shadow(hpf, regkk);
}

void set_polyphase_tuner(UINT32 RF_KHz, UINT8 img_rev, UINT8* regkk)
{
	// The I/Q image trim is left at zero: image calibration is not part of this release.
	set_reg(43, 0x0F, 0, regkk);						// xi_gain_i
	set_reg(43, 0xF0, 0, regkk);						// yi_phs_i
	set_reg(44, 0x01, 0, regkk);						// xi_sign_i
	set_reg(44, 0x02, 0, regkk);						// yi_sign_i
	set_reg(44, 0x40, (img_rev != 0), regkk);		// img_Rev
}

// RF_KHz is not used: the AGC settings do not depend on the band. It stays in the
// signature to match the other set_*_tuner functions.
void set_AGC_tuner(UINT32 RF_KHz, UINT8* regkk) {

	(void)RF_KHz;

	// Defaults for both detector windows: vth 1.3 V, vtl 0.9 V.
	agc_window_to_shadow(34, KW130_vth_13, KW130_vtl_09, regkk);		// RF path
	agc_window_to_shadow(35, KW130_vth_13, KW130_vtl_09, regkk);		// baseband path

	// Both groups are given a rate and the mux selects one. The default is 4 kHz.
	agc_clk_to_shadow(36, clkf_agc_4k,  clks_agc_125, regkk);
	agc_clk_to_shadow(37, clkf_RC_16k,  clks_RC_256,  regkk);

	agc_speed_to_shadow(KW130_agc_speed_4kHz, KW130_agc_rc_16kHz, regkk);
}

//----------------------------------------------------------//
//        customer entry points                             //
//----------------------------------------------------------//

// Validate set_info before anything is written to the chip. The limits are in
// KW130_SDR.h. RF_KHz is deliberately NOT range checked, so the part can be driven
// outside its specified band; an out-of-range RF simply fails to lock (KW_PLL_Unlock)
// rather than misbehaving.
KW_Status KW130_check_set_info(KW130_set_info set_info)
{
	if (set_info.lpf >= KW130_lpf_num)							return KW_Bad_Param;
	if (set_info.hpf > 15)										return KW_Bad_Param;
	if (set_info.xtal_T.xtal_freq_KHz < KW130_xtal_KHz_min)		return KW_Bad_Param;
	if (set_info.xtal_T.xtal_freq_KHz > KW130_xtal_KHz_max)		return KW_Bad_Param;
	if (set_info.xtal_T.cap_x > KW130_cap_x_max)				return KW_Bad_Param;
	if (set_info.xtal_T.share_mode > KW130_share_mode_max)		return KW_Bad_Param;
	if (set_info.vga_gain > KW130_vga_gain_max)					return KW_Bad_Param;
	if (set_info.img_rev > 1)									return KW_Bad_Param;

	return KW_Success;
}

// initial function for customer
KW_Status KW130_initial(KW130_set_info set_info) {

	KW_bool		status = 1;				// I2C accumulator : 1 = every write completed
	KW_Status	result;

	result = KW130_check_set_info(set_info);						//check before touching the chip
	if (result != KW_Success)
		return result;

	set_ini_table(KW130_reg);
	set_lna_ini(KW130_reg);
	set_RFbuf_ini(KW130_reg);
	set_mixer_ini(KW130_reg);
	set_mixeramp_ini(KW130_reg);
	set_polyphase_ini(KW130_reg);
	set_filter_ini(KW130_reg);
	set_AGC_ini(set_info.xtal_T.xtal_freq_KHz ,KW130_reg);
	set_vga_ini(KW130_reg);
	vga_to_shadow(set_info.vga_gain, KW130_reg);

	apply_gpo(set_info.RF_KHz, KW130_reg);							// keep the GPO level
	apply_user(KW130_reg);											// host overrides win

//Write all setting
	status &= I2C_pageWrite_Reg(KW130_devID, 5, KW130_reg, 59);		//page write R5~R63
//xtal power setup : master or slave mode, clock out setting
	result = set_xtal(set_info.xtal_T, KW130_reg);

	if (status == 0)
		return KW_I2C_Fail;
	return result;

}

KW_Status KW130_set_tuner(KW130_set_info set_info) {

	KW_bool		status = 1;				// I2C accumulator : 1 = every write completed
	KW_Status	result;
	KW_Status	pll_result;
	UINT32		LO_KHz;

	result = KW130_check_set_info(set_info);						//check before touching the chip
	if (result != KW_Success)
		return result;

	if (KW130_power_on(KW130_reg) != KW_Success)
		status = 0;

	// set_pll takes the LO to land on.
	LO_KHz = (set_info.img_rev == 0) ? (set_info.RF_KHz + set_info.IF_KHz)
									 : (set_info.RF_KHz - set_info.IF_KHz);

	pll_result = set_pll(LO_KHz, set_info.xtal_T.xtal_freq_KHz, KW130_reg);
	// the registers below are written even when the PLL did not lock, so the chip state
	// does not depend on whether it locked
	set_lna_tuner(set_info.RF_KHz , KW130_reg);
	set_RFbuf_tuner(set_info.RF_KHz, KW130_reg);
	set_mixeramp_tuner(set_info.RF_KHz, KW130_reg);
	set_filter_tuner(set_info.lpf, set_info.hpf, KW130_reg);
	set_polyphase_tuner(set_info.RF_KHz, set_info.img_rev, KW130_reg);
	set_AGC_tuner(set_info.RF_KHz, KW130_reg);
	vga_to_shadow(set_info.vga_gain, KW130_reg);					// was initial-only before

	apply_gpo(set_info.RF_KHz, KW130_reg);							// auto mode acts here
	apply_user(KW130_reg);											// after set_AGC_tuner, so they win

	status &= I2C_pageWrite_Reg(KW130_devID, 5, KW130_reg, 59);		//page write R5~R63

	if (status == 0)
		return KW_I2C_Fail;
	return pll_result;											// KW_Success / KW_PLL_Unlock / KW_I2C_Fail
}

KW_Status KW130_standby(void) {

	KW_bool	status = 1;								// 1: SUCCESS ,  0: FAIL

	// Drop the GPO first, so an LNA in front of the tuner is off before the tuner powers
	// down. There is no wake-up call: KW130_set_tuner() brings the part back and sets the
	// GPO with it.
	gpo_level = 0;
	gpo_to_shadow(gpo_level, KW130_reg);
	status &= I2C_pageWrite_Reg(KW130_devID, 62, KW130_reg, 2);		// R62 ~ R63

	set_reg(9,  0x04, 0, KW130_reg);				// en_BG=0
	set_reg(9,  0x08, 0, KW130_reg);				// en_lna=0
	set_reg(9,  0xE0, 0, KW130_reg);				// en_pll,en_mixer,en_rfbuf
	set_reg(10, 0x0C, 0, KW130_reg);	 			// en_lna_rf_det,en_BB
	set_reg(11, 0x03, 3, KW130_reg);	 			// pwd_agc=1,pwd_ldo_apr=1
	set_reg(10, 0x02, 1, KW130_reg);	 			// pwd_xtalldo=1

	status &= I2C_pageWrite_Reg(KW130_devID, 9, KW130_reg, 3);

	if (status)
	   return KW_Success;
	else
		return KW_I2C_Fail;

}

//----------------------------------------------------------//
//        GPO pin                                           //
//----------------------------------------------------------//

// Drive the GPO now. R62 and R63 go out together; the rest of R63 - cap_x - is
// untouched because the value comes from the shadow.
KW_Status KW130_set_gpo(UINT8 level)
{
	KW_bool	status = 1;

	if (level > 1)
		return KW_Bad_Param;

	gpo_level = level;
	gpo_to_shadow(gpo_level, KW130_reg);
	status &= I2C_pageWrite_Reg(KW130_devID, 62, KW130_reg, 2);		// R62 ~ R63

	return (status) ? KW_Success : KW_I2C_Fail;
}

// The level the GPO is driving.
KW_Status KW130_get_gpo(UINT8* level)
{
	if (level == 0)
		return KW_Bad_Param;

	*level = gpo_level;
	return KW_Success;
}

// Turn auto mode on or off. On, the next KW130_set_tuner() sets the level from the
// tuned frequency; the level already driven is left alone until then.
KW_Status KW130_set_gpo_auto(UINT8 on)
{
	if (on > 1)
		return KW_Bad_Param;

	gpo_auto = on;
	return KW_Success;
}

//----------------------------------------------------------//
//        tuning overrides                                  //
//----------------------------------------------------------//

// AGC detector window for the RF path. Nothing is stored and nothing is written when
// the check fails, so a bad call cannot leave half a window applied.
KW_Status KW130_set_rf_agc(KW130_vth_E vth, KW130_vtl_E vtl)
{
	if ((UINT8)vth > 15 || (UINT8)vtl > 15)
		return KW_Bad_Param;

	u_rf_vth = (UINT8)vth;
	u_rf_vtl = (UINT8)vtl;
	user_set |= KW_USR_RF_AGC;

	apply_user(KW130_reg);
	return write_one(34);
}

// AGC detector window for the baseband path.
KW_Status KW130_set_bb_agc(KW130_vth_E vth, KW130_vtl_E vtl)
{
	if ((UINT8)vth > 15 || (UINT8)vtl > 15)
		return KW_Bad_Param;

	u_bb_vth = (UINT8)vth;
	u_bb_vtl = (UINT8)vtl;
	user_set |= KW_USR_BB_AGC;

	apply_user(KW130_reg);
	return write_one(35);
}

// How fast the AGC loop runs, and the RC corner that goes with it. Only the twelve
// values in KW130_agc_speed_E are legal, and the corner has to be one the chosen speed
// can select.
KW_Status KW130_set_agc_speed(KW130_agc_speed_E speed, KW130_agc_rc_E rc)
{
	KW_Status	result;
	UINT8		v = (UINT8)speed;
	UINT8		r = (UINT8)rc;

	if (v > 15)
		return KW_Bad_Param;
	if ((v & 0x08) == 0 && (v & 0x07) > 3)		// 4..7 are not settings
		return KW_Bad_Param;
	if (r >= KW130_agc_rc_num)
		return KW_Bad_Param;
	if (((v & 0x08) ? rc_of_slow[r] : rc_of_fast[r]) == KW_RC_NONE)
		return KW_Bad_Param;					// this speed cannot select that corner

	u_agc_speed = v;
	u_agc_rc    = r;
	user_set |= KW_USR_AGC_SPEED;

	apply_user(KW130_reg);

	result = write_one(36);
	if (result == KW_Success)
		result = write_one(37);

	return result;
}

// Gain of each block. The step is a count, 0 is the least gain.
KW_Status KW130_set_lna_gain(KW130_gain_mode_E mode, UINT8 step)
{
	return set_gain(KW_GAIN_LNA, mode, step);
}

KW_Status KW130_set_rf_gain(KW130_gain_mode_E mode, UINT8 step)
{
	return set_gain(KW_GAIN_RF, mode, step);
}

KW_Status KW130_set_bb_gain(KW130_gain_mode_E mode, UINT8 step)
{
	return set_gain(KW_GAIN_BB, mode, step);
}

KW_Status KW130_set_filt_gain(KW130_gain_mode_E mode, UINT8 step)
{
	return set_gain(KW_GAIN_FILT, mode, step);
}

// TOP of each detector. The step is the register code; see KW130_SDR.h.
KW_Status KW130_set_top_lna(UINT8 step)
{
	return set_top(KW_TOP_LNA, step);
}

KW_Status KW130_set_top_rfbuf(UINT8 step)
{
	return set_top(KW_TOP_RFBUF, step);
}

KW_Status KW130_set_top_mixeramp(UINT8 step)
{
	return set_top(KW_TOP_MIXERAMP, step);
}

KW_Status KW130_set_top_filter(UINT8 step)
{
	return set_top(KW_TOP_FILTER, step);
}

// LPF corner trim, around the corner set_info.lpf selected. 0 is the narrowest.
KW_Status KW130_set_lpf_cor(UINT8 step)
{
	if (step > KW130_lpf_cor_max)
		return KW_Bad_Param;

	u_lpf_cor = step;
	user_set |= KW_USR_LPF_COR;

	apply_user(KW130_reg);
	return write_one(41);
}

// Give the API back control of every override. The registers are left as they are:
// the defaults are worked out per band, so they only come back at the next
// KW130_set_tuner().
KW_Status KW130_reset_tuning(void)
{
	user_set = 0;
	return KW_Success;
}

//----------------------------------------------------------//
//        image rejection calibration                       //
//----------------------------------------------------------//

// Put the I/Q trim into the shadow, so it survives the write set_polyphase_tuner() does
// on every tune.
void imr_to_shadow(KW130_imr_T imr, UINT8* regkk)
{
	set_reg(43, 0x0F, imr.code_x, regkk);		// xi_gain_i
	set_reg(43, 0xF0, imr.code_y, regkk);		// yi_phs_i
	set_reg(44, 0x01, imr.sign_x, regkk);		// xi_sign_i
	set_reg(44, 0x02, imr.sign_y, regkk);		// yi_sign_i
}

// Everything the calibration engine needs before it can run.
static void imr_cal_setup(UINT8* regkk)
{
	// The read path. KW130 comes up with rw_mode = 1, and while it is 1 a read of R5..R7
	// hands back what was written there instead of what the engine found.
	set_reg(32, 0x20, 0, regkk);				// rw_mode = 0

	// manual gain, and the gains the engine expects
	set_reg(11, 0x10, 1, regkk);				// rst_agc_i2c = 1, forces every block manual
	set_reg(53, 0x0E, 7, regkk);				// filt_G   = 7
	set_reg(52, 0xF0, 7, regkk);				// BBamp_G  = 7
	set_reg(44, 0x0C, 0, regkk);				// mpcr_gain = 0

	// Shut the antenna out. The engine is measuring an internal tone, so anything the
	// LNA and the RF buffer bring in from outside is interference in the measurement.
	// en_mixer and en_pll stay on - the mixer is in the calibration path and the PLL
	// places the LO.
	set_reg(9, 0x08, 0, regkk);					// en_lna   = 0
	set_reg(9, 0x20, 0, regkk);					// en_rfbuf = 0

	// The digital side. Reset_n_dsp is active low, and the initial table leaves the DSP
	// held in reset, so it has to be released here.
	set_reg(11, 0x02, 0, regkk);				// pwd_ldo_apr = 0, the APR block needs its LDO
	set_reg(11, 0x04, 1, regkk);				// Reset_n_dsp = 1, release the DSP
	set_reg(11, 0x08, 1, regkk);				// en_clk_apr = 1
	set_reg(11, 0x80, 1, regkk);				// en_adc     = 1
	set_reg(13, 0x01, 1, regkk);				// en_ringpll = 1
	set_reg(13, 0x10, 1, regkk);				// cal_on_rfbuf = 1, the tone reaches the RF buffer

	// the VGA, and where the ADC reading is taken from
	set_reg(13, 0x06, 1, regkk);				// vga_det_sw_mode = calibration
	set_reg(44, 0x20, 1, regkk);				// img_cal_vga = 1
	set_reg(48, 0x02, 1, regkk);				// vga_slope = high
	set_reg(48, 0x01, 1, regkk);				// sel_mux_vga_code = auto
	set_reg(44, 0x80, 0, regkk);				// sel_adc_i2c_path = from the ADC

	// the narrowest filter, for the best signal to noise on the tone
	set_reg(41, 0x1F, 0, regkk);				// LPF_cor = 0, narrowest
	set_reg(41, 0xE0, 7, regkk);				// LPF corner = 6 MHz
	set_reg(44, 0x10, 1, regkk);				// img_cal_HPF = 1
	set_reg(46, 0x40, 0, regkk);				// sel_mux_fcal = i2c

	// The engine. R45 and R46 come up at zero, which already means IMR mode, 4T, the wider
	// search window and a full search.
	set_reg(45, 0x02, 0, regkk);				// cal_mode = IMR
	set_reg(45, 0x0C, 0, regkk);				// Ts = 4T
	set_reg(45, 0x10, 0, regkk);				// ical_range = the +-15 window
	set_reg(45, 0x20, 0, regkk);				// ical_opt3 = ADC output is the calibration
	set_reg(45, 0x40, 0, regkk);				// ical_opt1 = full search
	set_reg(45, 0x80, 0, regkk);				// ical_opt2 = do the VGA gain training
	set_reg(46, 0x01, 1, regkk);				// avg_en = 1
	set_reg(46, 0x02, 0, regkk);				// adc_vth_sel = 80
	set_reg(46, 0x80, 1, regkk);				// sel_mux_Ical = APR, the engine owns the trim
}

// Undo it. The host has to call KW130_set_tuner() afterwards to get a working receiver
// either way, so this only has to leave nothing enabled that should not be.
static void imr_cal_teardown(UINT8* regkk)
{
	set_reg(11, 0x10, 0, regkk);				// rst_agc_i2c = 0
	set_reg(11, 0x08, 0, regkk);				// en_clk_apr = 0
	set_reg(11, 0x04, 0, regkk);				// Reset_n_dsp back to the ini value
	set_reg(11, 0x80, 0, regkk);				// en_adc = 0
	set_reg(13, 0x01, 0, regkk);				// en_ringpll = 0
	set_reg(13, 0x10, 0, regkk);				// cal_on_rfbuf = 0
	set_reg(13, 0x06, 0, regkk);				// vga_det_sw_mode = off
	set_reg(44, 0x20, 0, regkk);				// img_cal_vga = 0
	set_reg(44, 0x10, 0, regkk);				// img_cal_HPF = 0
	set_reg(48, 0x01, 0, regkk);				// sel_mux_vga_code = manual
	set_reg(46, 0x80, 0, regkk);				// sel_mux_Ical = i2c, the host owns the trim
	set_reg(9, 0x08, 1, regkk);					// en_lna   = 1
	set_reg(9, 0x20, 1, regkk);					// en_rfbuf = 1
	set_reg(32, 0x20, 1, regkk);				// rw_mode back to what the ini table sets
}

// The six calibration points, as the ring PLL dividers each one needs.
// RingVCO = 4 * ring_div_num * xtal, and the tone is that divided by (mod23 + 2) and
// then by 2^sel_div - so where a point lands depends on the crystal, which is why the
// tone is computed and reported in KW130_imr_point_KHz[] rather than fixed.
static const UINT32 imr_vco_KHz[KW130_imr_point_num] =
		{ 1728000UL, 1824000UL, 1920000UL, 1920000UL, 1920000UL, 1920000UL };
static const UINT8  imr_sel_div[KW130_imr_point_num]  = { 0, 0, 1, 1, 2, 3 };
static const UINT8  imr_mod23[KW130_imr_point_num]    = { 0, 1, 0, 1, 1, 1 };
static const UINT8  imr_poly_mux[KW130_imr_point_num] = { 0, 0, 0, 0, 1, 2 };

// Park the ring PLL on one point, point the polyphase filter at it, and return the tone
// it actually lands on.
static UINT32 imr_ring_setup(UINT8 point, UINT16 xtal_freq_KHz, UINT8* regkk)
{
	UINT8	div_num = (UINT8)(imr_vco_KHz[point] / xtal_freq_KHz / 4);
	UINT32	vco_KHz = (UINT32)xtal_freq_KHz * 4 * div_num;

	set_reg(12, 0x3F, div_num, regkk);					// ring_div_num
	set_reg(12, 0xC0, imr_sel_div[point], regkk);		// ring_sel_div
	set_reg(13, 0x80, 0, regkk);						// ring_bank
	set_reg(13, 0x40, imr_mod23[point], regkk);			// ring_mod23
	set_reg(16, 0xC0, imr_poly_mux[point], regkk);		// polyrf_mux

	return vco_KHz / (imr_mod23[point] + 2) / ((UINT32)1 << imr_sel_div[point]);
}

// Hold cal_en high and read the result while it is still high. Taking it low abandons
// the search and zeroes the result, so it is only cleared once a run has finished - the
// clearing is what lets the next run start.
static KW_Status imr_cal_en(UINT8 on)
{
	set_reg(45, 0x01, on, KW130_reg);
	return (I2C_Write_Reg(KW130_devID, 45, KW130_reg[45])) ? KW_Success : KW_I2C_Fail;
}

// Poll the engine. cal_en is written high every time, which is a no-op once it already
// is, and the read happens with it still high.
static KW_Status imr_poll(KW130_imr_T* out, UINT8* done)
{
	KW_bool	status = 1;

	*done = 0;

	if (imr_cal_en(1) != KW_Success)
		return KW_I2C_Fail;

	// Give the engine time to work before looking, so the give-up is a length of time
	// rather than a number of I2C reads.
	KW130_delay_ms(KW130_imr_poll_ms);

	status &= I2C_pageRead_Reg(KW130_devID, 5, KW130_rData, 3);
	KW130_imr_raw[0] = KW130_rData[5];
	KW130_imr_raw[1] = KW130_rData[6];
	KW130_imr_raw[2] = KW130_rData[7];

	if ((KW130_rData[5] & 0x80) != 0) {			// ical_done, read with cal_en still high
		*done = 1;
		out->code_x = (UINT8)(KW130_rData[6] & 0x0F);
		out->code_y = (UINT8)((KW130_rData[6] & 0xF0) >> 4);
		out->sign_x = (UINT8)(KW130_rData[7] & 0x01);
		out->sign_y = (UINT8)((KW130_rData[7] & 0x02) >> 1);
	}

	return (status) ? KW_Success : KW_I2C_Fail;
}

// Measure all six points and keep the results. Nothing is applied - the host chooses.
KW_Status KW130_imr_cal(KW130_set_info set_info)
{
	KW_bool		status = 1;
	KW_Status	check;
	KW130_imr_T	this_run;
	KW130_imr_T	no_trim;
	UINT8		point;
	UINT8		done = 0;
	UINT8		all_done = 1;

	check = KW130_check_set_info(set_info);
	if (check != KW_Success)
		return check;

	no_trim.code_x = 0;		no_trim.code_y = 0;
	no_trim.sign_x = 0;		no_trim.sign_y = 0;

	for (point = 0; point < KW130_imr_point_num; point++) {
		KW130_imr_result[point] = no_trim;
		KW130_imr_point_KHz[point] = 0;
		KW130_imr_valid[point] = 0;
	}
	KW130_imr_raw[0] = 0;	KW130_imr_raw[1] = 0;	KW130_imr_raw[2] = 0;

	// the engine measures the imbalance, so it must not be looking through a trim
	imr_to_shadow(no_trim, KW130_reg);
	imr_cal_setup(KW130_reg);
	status &= I2C_pageWrite_Reg(KW130_devID, 5, KW130_reg, 59);		// R5 ~ R63

	for (point = 0; point < KW130_imr_point_num && status; point++) {
		UINT32		tone_KHz;
		KW_Status	pll_result;

		tone_KHz = imr_ring_setup(point, set_info.xtal_T.xtal_freq_KHz, KW130_reg);
		KW130_imr_point_KHz[point] = tone_KHz;
		status &= I2C_pageWrite_Reg(KW130_devID, 12, KW130_reg, 5);	// R12 ~ R16

		// the tone sits 5 MHz above the LO, in the image band
		pll_result = set_pll(tone_KHz - 5000,
							 set_info.xtal_T.xtal_freq_KHz, KW130_reg);
		if (pll_result != KW_Success) {
			all_done = 0;					// no tone here, carry on to the next point
			continue;
		}

		done = 0;
		KW130_imr_polls = 0;
		while (KW130_imr_polls < KW130_imr_poll_max) {
			KW130_imr_polls++;

			if (imr_poll(&this_run, &done) != KW_Success) {
				status = 0;
				break;
			}
			if (!done)
				continue;					// still searching, leave cal_en alone

			// The engine reports its answer once and does not wander, so the first
			// reading with done set is the answer.
			KW130_imr_result[point] = this_run;
			KW130_imr_valid[point] = 1;
			break;
		}

		// a finished point has to be released before the next one can start
		status &= (imr_cal_en(0) == KW_Success);

		if (!done)
			all_done = 0;
	}

	imr_cal_teardown(KW130_reg);
	status &= I2C_pageWrite_Reg(KW130_devID, 5, KW130_reg, 59);		// R5 ~ R63

	if (!status)
		return KW_I2C_Fail;
	if (!all_done)
		return KW_Failed;				// KW130_imr_valid says which points did finish

	return KW_Success;
}

// Apply a trim now. R43 and R44 go out immediately, so a host hunting for the best codes can
// set, measure and set again without retuning. The value is kept, so the next
// KW130_set_tuner() preserves it.
KW_Status KW130_set_imr(KW130_imr_T imr)
{
	KW_bool	status = 1;

	if (imr.code_x > 15 || imr.code_y > 15 || imr.sign_x > 1 || imr.sign_y > 1)
		return KW_Bad_Param;

	u_imr = imr;
	user_set |= KW_USR_IMR;

	apply_user(KW130_reg);
	status &= I2C_pageWrite_Reg(KW130_devID, 43, KW130_reg, 2);		// R43 ~ R44

	return (status) ? KW_Success : KW_I2C_Fail;
}

// The trim currently applied.
KW_Status KW130_get_imr(KW130_imr_T* imr)
{
	if (imr == 0)
		return KW_Bad_Param;

	*imr = u_imr;
	return KW_Success;
}

//----------------------------------------------------------//
//        for Keywave debug                                 //
//----------------------------------------------------------//

KW_Status KW130_dump_reg(void)
{
	KW_bool result = 1;
	result &= I2C_pageRead_Reg(KW130_devID, 0, KW130_rData, 64);
	if (result)
	   return KW_Success;
	else
		return KW_I2C_Fail;
}

KW_Status KW130_get_states(void)
{
	KW_bool result = 1;
	result &= I2C_pageRead_Reg(KW130_devID, 1, KW130_rData, 4);
	if (result)
	   return KW_Success;
	else
		return KW_I2C_Fail;
}
