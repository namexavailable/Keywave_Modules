// KW130 SDR Tuner API
//----------------------------------------------------------//
// Version History
//----------------------------------------------------------//
// 2025/05/02  v1.0   KW130 SDR prototype
// 2025/05/09  v2.0   KW130
// 2025/05/12  v2.6
// 2025/05/30  v2.9   mixer gain limit 9 => 11
// 2025/07/11  v2.91  RF band split: lovcm_up / pw_mix / LO_vcm
// 2026/08/28  v3.25  the mixer amp gain stops at 11. Codes 12 to 15 exist in the
//                    field but behave as 11, so KW130_set_bb_gain() now rejects
//                    them instead of accepting a step that does nothing.
//                    Documentation only otherwise: the I2C address is stated as an
//                    8-bit write address with the read address alongside it, and
//                    some field names follow the datasheet.
// 2026/08/25  v3.24  a channel is stated as an IF centre and two filter corners, so
//                    set_info.format is replaced by IF_KHz, lpf and hpf.
//                    One VGA gain step replaces the code and attenuator pair.
//                    The AGC window and speed, the four gains, the LPF trim and the
//                    TOPs can each be set and are then held across a tune.
//                    The GPO pin is controllable, with an optional mode that follows
//                    the tuned frequency.
//                    Image rejection can be measured at six frequencies; the results
//                    are reported and applied only if the host asks.
//                    See README.md.
// 2026/08/20  v3.14  first v3 release. KW_Status carries the reason a call failed,
//                    set_info is validated before anything is written, the PLL lock
//                    sequence is fixed, and this header needs no other header.
//                    README.md lists what changed since v2.91.
//----------------------------------------------------------//

#pragma once
#ifndef KW130_SDR_H
#define KW130_SDR_H
// This file needs no other header.

#ifdef __cplusplus
extern "C" {
#endif

//----------------------------------------------------------//
//                   API Version                            //
//----------------------------------------------------------//
#define KW130_API_major     3
#define KW130_API_minor     25

//----------------------------------------------------------//
//                   Type Define                            //
//----------------------------------------------------------//
typedef unsigned char 	UINT8;
typedef unsigned short 	UINT16;
typedef unsigned int 	UINT32;
typedef signed char 	INT8;
typedef signed short 	INT16;
typedef signed int 		INT32;
typedef UINT8 			KW_bool;			// 0 = fail / false,  1 = ok / true

// The widths are checked at compile time: on a target where they do not hold this line
// fails to compile, and the six typedefs above are the only thing that needs editing.
typedef char KW130_type_width_check[
	(sizeof(UINT8) == 1 && sizeof(UINT16) == 2 && sizeof(UINT32) == 4 &&
	 sizeof(INT8)  == 1 && sizeof(INT16)  == 2 && sizeof(INT32)  == 4) ? 1 : -1];
//----------------------------------------------------------//
//        Result code                                       //
//----------------------------------------------------------//
// Result of every API call.
// NOTE: test the result with  (result != KW_Success).
//       Do NOT test  (result == KW_Failed) : a failure normally carries a specific code,
//       so it is not equal to KW_Failed.
typedef enum _KW_Status
{
	KW_Success = 1,					// unchanged from v2.x, so (== KW_Success) tests stay valid
	KW_Failed = 0,					// failure without further detail
	KW_I2C_Fail = 2,				// I2C write or read did not complete
	KW_PLL_Unlock = 3,				// registers were written, but the VCO never reported lock
	KW_Bad_Param = 4				// set_info carries an out-of-range field
}KW_Status;

//----------------------------------------------------------//
//                   Define                                 //
//----------------------------------------------------------//
// I2C device address. This is the 8-bit WRITE address: a 7-bit slave address with the
// R/W bit already in place as 0. Do not shift it again.
//   write : 0xF2   0xB2   0x72   0x32     strapped on the board
//   read  : 0xF3   0xB3   0x73   0x33     the write address with bit 0 set
// The API passes this value to all four I2C functions; setting bit 0 for a read is the
// transport's job, not the API's.
#define KW130_IIC_Addr    	0xF2           	// 4 option : 0x32 / 0x72 / 0xB2 / 0xF2
#define KW130_REG_NUM       64				// R0~R4 are read-only status registers

//----------------------------------------------------------//
//        Parameter limits (from the KW130 datasheet)     //
//----------------------------------------------------------//
// RF range is INFORMATIONAL only and is not enforced by KW130_check_set_info(), so the
// part can be driven outside its specified band. A host may use these values to warn.
#define KW130_RF_KHz_min        30000		// fRF  min   30 MHz (datasheet, not enforced)
#define KW130_RF_KHz_max        2600000		// fRF  max 2600 MHz (datasheet, not enforced)
#define KW130_xtal_KHz_min      16000		// FOSC min   16 MHz
#define KW130_xtal_KHz_max      32000		// FOSC max   32 MHz
#define KW130_cap_x_max         31			// R63 b0:4
#define KW130_share_mode_max    2			// 0:no share, 1:master, 2:slave

// VGA gain. One step number covers the whole range, and step 9 is 0 dB - the default.
// 3.2 dB per step through the middle, 2.4 dB at the two ends.
//
//    0   -24.8 dB     6    -9.6 dB    12    +9.6 dB    18   +28.8 dB
//    1   -22.4        7    -6.4       13   +12.8       19   +32.0
//    2   -20.0        8    -3.2       14   +16.0       20   +35.2
//    3   -17.6        9     0.0       15   +19.2       21   +37.6
//    4   -15.2       10    +3.2       16   +22.4       22   +40.0
//    5   -12.8       11    +6.4       17   +25.6
#define KW130_vga_gain_max      22
#define KW130_vga_gain_0dB       9

//----------------------------------------------------------//
//        The channel you ask for                           //
//----------------------------------------------------------//
typedef struct {
	UINT16				xtal_freq_KHz;			//ex.24MHz Xtal => 24000
	UINT8				cap_x;					//internal xtal_cap setting 0~31 step: 1pF
	UINT8				share_mode;				//0: normal no share,  1: tuner master,   2:tuner slave (xtal_osc power down)
}KW130_xtal_T;

// The channel: an IF centre and the two filter corners. Both corner names are the
// frequency in MHz.
//
//     HPF corner = IF centre - channel bandwidth / 2      the lower edge
//     LPF corner = IF centre + channel bandwidth / 2      the upper edge
//
// So an 8 MHz channel at an IF centre of 5 MHz is HPF 1 MHz and LPF 9 MHz:
//
//     s.IF_KHz = 5000;
//     s.lpf    = KW130_lpf_9M;
//     s.hpf    = KW130_hpf_0M96;      // the step nearest 1 MHz
//
// The corners land on the steps the part provides, so pick the nearest one. The LPF
// corner can then be trimmed with KW130_set_lpf_cor().
typedef enum {
	KW130_lpf_6M  = 0,
	KW130_lpf_7M  = 1,
	KW130_lpf_8M  = 2,
	KW130_lpf_9M  = 3,
	KW130_lpf_12M = 4,
	KW130_lpf_16M = 5,
	KW130_lpf_20M = 6
}KW130_lpf_E;
#define KW130_lpf_num           7

typedef struct {
	UINT32					RF_KHz;
	UINT16					IF_KHz;			//IF centre, ex. 5000 or 4570
	UINT8					lpf;			//LPF corner, KW130_lpf_E   : upper edge
	UINT8					hpf;			//HPF corner, KW130_hpf_E   : lower edge
	KW130_xtal_T			xtal_T;			/* xtal Frequency, refers above */
	UINT8					vga_gain;		//VGA gain, 0 ~ KW130_vga_gain_max, see the table
	UINT8					dummy6;			//keeps the struct a whole number of 32-bit words
	UINT8					img_rev;		//Image reverse function 0: normal ( IF spectrum reverse to RF)  1: reverse
	UINT8					dummy5;         //Add Dummy for strcut 32bit transfer
}KW130_set_info;

// HPF corner, the lower edge of the channel. The name is the frequency in MHz, so
// KW130_hpf_2M72 is 2.72 MHz. Raising it clears more of what sits near DC, at the cost
// of the bottom of the channel.
typedef enum {
	KW130_hpf_2M72 =  0, KW130_hpf_2M56 =  1, KW130_hpf_2M40 =  2, KW130_hpf_2M24 =  3,
	KW130_hpf_2M08 =  4, KW130_hpf_1M92 =  5, KW130_hpf_1M76 =  6, KW130_hpf_1M60 =  7,
	KW130_hpf_1M44 =  8, KW130_hpf_1M28 =  9, KW130_hpf_1M12 = 10, KW130_hpf_0M96 = 11,
	KW130_hpf_0M80 = 12, KW130_hpf_0M64 = 13, KW130_hpf_0M48 = 14, KW130_hpf_0M32 = 15
}KW130_hpf_E;


//----------------------------------------------------------//
//        Image rejection calibration                       //
//----------------------------------------------------------//
// KW130_imr_cal() measures the I/Q imbalance at six frequencies and keeps the results.
// It applies nothing. Two decisions stay with the host: whether to calibrate at all, and
// which of the six results to apply for the frequency it is about to tune.
//
// Call it with the part already initialised. It runs an internal tone through the
// receiver, so it leaves the chip unable to receive - call KW130_set_tuner() afterwards
// whether or not you keep a result.
//
// The six tones are generated by dividing the crystal, so where they land depends on it:
// with 24 MHz they are 864, 608, 480, 320, 160 and 80 MHz, and with 27 MHz they are 864,
// 576, 459, 306, 153 and 76.5 MHz. KW130_imr_point_KHz[] is filled in with the tone each
// point actually used, which is what tells you which result belongs near your frequency.
//
//     KW130_imr_cal(s);                       // once, if you want to
//     ...
//     KW130_set_imr(KW130_imr_result[0]);     // the point nearest what you are tuning
//     KW130_set_tuner(s);
//
// A point that did not finish leaves KW130_imr_valid[] at 0 for that point, and the call
// returns KW_Failed. The others are still usable.
#define KW130_imr_point_num      6			// calibration frequencies
#define KW130_imr_poll_max      20			// polls per point before giving up
#define KW130_imr_poll_ms        4			// wait before each read; the engine needs time

typedef struct {
	UINT8				code_x;			// R6 b0:3
	UINT8				code_y;			// R6 b4:7
	UINT8				sign_x;			// R7 b0
	UINT8				sign_y;			// R7 b1
}KW130_imr_T;

// Filled in by KW130_imr_cal, read only.
extern KW130_imr_T	KW130_imr_result[KW130_imr_point_num];
extern UINT32		KW130_imr_point_KHz[KW130_imr_point_num];	// the tone each point used
extern UINT8		KW130_imr_valid[KW130_imr_point_num];		// 1: that point finished

//----------------------------------------------------------//
//        PLL lock sequence                                 //
//----------------------------------------------------------//
// The tuner locks on its own once rst_atune is released; raising pw0_vco does not need
// another one, only time for the VCO to restart at the higher current. The datasheet
// does not specify a lock time - 1 ms covers both waits.
#define KW130_pll_settle_ms     1			// settle wait, see the note above
#define KW130_pll_retry_max     10			// lock polls before giving up
#define KW130_pw0_vco_start     10			// R28 b0:3 starting VCO current
#define KW130_pw0_vco_max       15			// R28 b0:3 highest VCO current

//----------------------------------------------------------//
//        GPO pin                                           //
//----------------------------------------------------------//
// The GPO drives whatever the board connects to that pin. On the Keywave EVK it is
// the enable for the off-chip LNA in front of the tuner.
//
// Auto mode is for exactly that arrangement: with it on, KW130_set_tuner() raises the
// GPO when the tuned frequency is above KW130_gpo_auto_KHz and lowers it below, so the
// LNA follows the band it covers. It is off by default; leave it off and the GPO only
// changes when KW130_set_gpo() is called.
//
// The level survives KW130_initial() and KW130_set_tuner() - both write it out - so a
// re-initialise cannot silently switch the LNA off.
//
// KW130_standby() takes the GPO low, so an LNA in front of the tuner is off while the
// tuner is. There is no separate wake-up call - KW130_set_tuner() brings the part back
// and sets the GPO with it, from the frequency when auto mode is on.
#define KW130_gpo_auto_KHz      950000		// auto mode: above this the GPO is high

//----------------------------------------------------------//
//        Tuning overrides                                  //
//----------------------------------------------------------//
// KW130_set_tuner() works out the AGC, gain and filter settings for the band it is
// tuning, so a register written by hand is lost at the next tune. The functions in
// this group are the supported way to change one: the value is remembered and put
// back after every KW130_initial() and KW130_set_tuner(), until KW130_reset_tuning()
// hands control back to the API.
//
// Each one also writes its register straight away, so a setting can be changed,
// measured and changed again without retuning in between.
//
// Nothing is overridden until one of them is called.

// AGC detector window. The two digits in the name are the threshold in volts times
// ten, so KW130_vth_13 is 1.3 V.
// vth is the level above which the AGC reduces gain, vtl the level below which it
// increases gain. The gap between them is the window the loop leaves alone; vth above
// vtl is the sensible arrangement, but it is not enforced.
typedef enum {
	KW130_vth_04 =  0, KW130_vth_05 =  1, KW130_vth_06 =  2, KW130_vth_07 =  3,
	KW130_vth_08 =  4, KW130_vth_09 =  5, KW130_vth_10 =  6, KW130_vth_11 =  7,
	KW130_vth_12 =  8, KW130_vth_13 =  9, KW130_vth_14 = 10, KW130_vth_15 = 11,
	KW130_vth_16 = 12, KW130_vth_17 = 13, KW130_vth_18 = 14, KW130_vth_19 = 15
}KW130_vth_E;

typedef enum {
	KW130_vtl_03 =  0, KW130_vtl_04 =  1, KW130_vtl_05 =  2, KW130_vtl_06 =  3,
	KW130_vtl_07 =  4, KW130_vtl_08 =  5, KW130_vtl_09 =  6, KW130_vtl_10 =  7,
	KW130_vtl_11 =  8, KW130_vtl_12 =  9, KW130_vtl_13 = 10, KW130_vtl_14 = 11,
	KW130_vtl_15 = 12, KW130_vtl_16 = 13, KW130_vtl_17 = 14, KW130_vtl_18 = 15
}KW130_vtl_E;

// LPF corner trim. KW130_set_lpf_cor() moves the upper edge around whatever
// set_info.lpf selected: 0 is the narrowest setting, KW130_lpf_cor_max the widest.
#define KW130_lpf_cor_max       31

// TOP, the level at which each detector decides its block is being overdriven. Lower
// the TOP and the AGC backs the gain off sooner, which trades sensitivity for headroom.
// The numbers are the ones the register table uses.
// For the mixer amp, filter and baseband the step is how far below maximum, so 0 is
// the highest TOP. For the LNA and the RF buffer the table gives a plain 0 to 7.
#define KW130_top_lna_max        7
#define KW130_top_rfbuf_max      7
#define KW130_top_mixeramp_max   7
#define KW130_top_filter_max     7

// Gain blocks. Each can follow the AGC or be held at a fixed step, and the step is a
// plain count - 0 is the least gain, the maximum below is the most.
// In auto the AGC sets the gain and the step is what manual mode will use.
#define KW130_lna_gain_max      31		// LNA
#define KW130_rf_gain_max       15		// RF buffer
#define KW130_bb_gain_max       11		// mixer amp. 12..15 exist but behave as 11
#define KW130_filt_gain_max      7		// filter

typedef enum {
	KW130_gain_auto   = 0,
	KW130_gain_manual = 1
}KW130_gain_mode_E;

// AGC loop speed and the RC corner that goes with it. Both are set by one call: the
// same selector picks which of two clock settings and which of two corner settings is
// in effect, so a corner only means anything alongside a speed.
//
// These corners can be used with the four fastest speeds:  256 kHz, 64 kHz, 16 kHz, 4 kHz
// These with the other eight:  4 kHz, 2 kHz, 1 kHz, 500 Hz, 256 Hz, 64 Hz, 16 Hz, 4 Hz
//
// 4 kHz is the only corner that works with either. Asking for one the chosen speed
// cannot reach returns KW_Bad_Param. The default pair is 4 kHz with a 16 kHz corner.
typedef enum {
	KW130_agc_rc_256kHz =  0,
	KW130_agc_rc_64kHz  =  1,
	KW130_agc_rc_16kHz  =  2,
	KW130_agc_rc_4kHz   =  3,
	KW130_agc_rc_2kHz   =  4,
	KW130_agc_rc_1kHz   =  5,
	KW130_agc_rc_500Hz  =  6,
	KW130_agc_rc_256Hz  =  7,
	KW130_agc_rc_64Hz   =  8,
	KW130_agc_rc_16Hz   =  9,
	KW130_agc_rc_4Hz    = 10
}KW130_agc_rc_E;
#define KW130_agc_rc_num        11

// AGC loop speed, twelve settings. The name is the rate.
// Faster settles quicker and tracks a changing signal; slower rides through modulation
// without pumping. The default is 4 kHz.
// Two settings run at 1 kHz and differ in loop damping - try both if 1 kHz is the rate
// you want.
typedef enum {
	KW130_agc_speed_64kHz  =  0,
	KW130_agc_speed_16kHz  =  1,
	KW130_agc_speed_4kHz   =  2,
	KW130_agc_speed_1kHz_f =  3,
	KW130_agc_speed_2kHz   =  8,
	KW130_agc_speed_1kHz_s =  9,
	KW130_agc_speed_500Hz  = 10,
	KW130_agc_speed_256Hz  = 11,
	KW130_agc_speed_125Hz  = 12,
	KW130_agc_speed_32Hz   = 13,
	KW130_agc_speed_8Hz    = 14,
	KW130_agc_speed_2Hz    = 15
}KW130_agc_speed_E;



// global

// I2C device address and I2C read out memory
extern UINT8 	KW130_devID;
extern UINT8	KW130_rData[KW130_REG_NUM];

// PLL lock diagnostics, updated by KW130_set_tuner (read only)
extern UINT8	KW130_vco_power;			// pw0_vco the PLL actually locked at
extern UINT8	KW130_pll_retry;			// lock polls needed; 0 = locked on the first poll



// Customer Function
extern KW_Status KW130_check_set_info(KW130_set_info set_info);	// validate without writing
extern KW_Status KW130_initial(KW130_set_info set_info);
extern KW_Status KW130_standby();
extern KW_Status KW130_set_tuner(KW130_set_info set_info);

// GPO pin, see the note above. Level is 0 or 1; set writes it out immediately.
extern KW_Status KW130_set_gpo(UINT8 level);
extern KW_Status KW130_get_gpo(UINT8* level);
extern KW_Status KW130_set_gpo_auto(UINT8 on);	// 0 = off (default), 1 = follow the RF

// Tuning overrides, see the note above. Each survives a tune and an initialise.
// AGC detector window for the RF path (LNA) and the baseband path (mixer amp).
extern KW_Status KW130_set_rf_agc(KW130_vth_E vth, KW130_vtl_E vtl);
extern KW_Status KW130_set_bb_agc(KW130_vth_E vth, KW130_vtl_E vtl);

// How fast the AGC loop runs, and the RC corner of the same loop.
extern KW_Status KW130_set_agc_speed(KW130_agc_speed_E speed, KW130_agc_rc_E rc);

// Gain of each block. In KW130_gain_auto the AGC drives it and step is stored for
// later; in KW130_gain_manual the block sits at step.
extern KW_Status KW130_set_lna_gain (KW130_gain_mode_E mode, UINT8 step);
extern KW_Status KW130_set_rf_gain  (KW130_gain_mode_E mode, UINT8 step);
extern KW_Status KW130_set_bb_gain  (KW130_gain_mode_E mode, UINT8 step);
extern KW_Status KW130_set_filt_gain(KW130_gain_mode_E mode, UINT8 step);

// LPF corner trim, around the corner set_info.lpf selects.
extern KW_Status KW130_set_lpf_cor(UINT8 step);

// TOP of each detector, see the note above.
extern KW_Status KW130_set_top_lna     (UINT8 step);
extern KW_Status KW130_set_top_rfbuf   (UINT8 step);
extern KW_Status KW130_set_top_mixeramp(UINT8 step);
extern KW_Status KW130_set_top_filter  (UINT8 step);

// Image rejection, see the note above. cal measures all six points; set applies one.
extern KW_Status KW130_imr_cal(KW130_set_info set_info);
extern KW_Status KW130_set_imr(KW130_imr_T imr);
extern KW_Status KW130_get_imr(KW130_imr_T* imr);

// Drop every override. The registers keep their current values until the next
// KW130_set_tuner(), which is when the API defaults come back.
extern KW_Status KW130_reset_tuning(void);


// for Keywave Debug
extern KW_Status KW130_dump_reg(void);
extern KW_Status KW130_get_states(void);


#ifdef __cplusplus
}
#endif

#endif