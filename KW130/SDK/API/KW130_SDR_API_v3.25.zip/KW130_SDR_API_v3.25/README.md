# KW130 SDR API

**v3.25**, 2026-08-28. The version is also in `KW130_SDR.h` as `KW130_API_major` /
`KW130_API_minor`.

If you are coming from **v2.91**, everything in "What you must change" below applies to
you. Coming from v3.24, `KW130_set_bb_gain()` now rejects steps 12 to 15: the mixer amp
stops at 11 and those codes behave as 11. Coming from an earlier v3, the surface
changed at v3.24: `set_info.format` is gone,
replaced by `IF_KHz`, `lpf` and `hpf`; `vga_code` and `vga_att` are replaced by one
`vga_gain` step; and the AGC, gain, filter-trim and TOP setters were added.

---

## Porting: the functions you implement

The API never talks to hardware itself. It calls four functions, declared in
`I2C_Sys.h`, and you provide the bodies for your host:

| | |
|---|---|
| `I2C_Write_Reg(devID, regAddr, regData)` | write one register |
| `I2C_pageWrite_Reg(devID, regAddr, regDataPtr, Len)` | write `Len` consecutive registers |
| `I2C_pageRead_Reg(devID, regAddr, regDataPtr, Len)` | read `Len` consecutive registers |
| `KW130_delay_ms(ms)` | wait at least `ms` milliseconds |

The I2C functions return 1 on success and 0 if the transfer did not complete.

**The page buffers are indexed by absolute register address, not from the start address.**
`I2C_pageWrite_Reg(devID, 23, buf, 11)` sends `buf[23]` through `buf[33]`. The API always
passes its full 64-byte array.

`KW130_delay_ms()` must not be a no-op. The PLL needs time to settle after its auto-tune is
released, and again if the VCO current is raised; a host that returns immediately will report
false PLL failures and will push the VCO current up for nothing.

---

## Using it

```c
KW130_set_info  s;

s.RF_KHz                = 666000;        /* tuned frequency, kHz            */
s.IF_KHz                = 5000;          /* IF centre, kHz                  */
s.lpf                   = KW130_lpf_9M;  /* upper edge of the channel       */
s.hpf                   = KW130_hpf_0M96;/* lower edge of the channel       */
s.xtal_T.xtal_freq_KHz  = 24000;         /* crystal, 16000 ~ 32000          */
s.xtal_T.cap_x          = 21;            /* internal crystal cap, 0 ~ 31    */
s.xtal_T.share_mode     = 0;             /* 0 none, 1 master, 2 slave       */
s.vga_gain              = 9;             /* VGA gain step, 9 is 0 dB        */
s.img_rev               = 0;             /* 1 reverses the IF spectrum      */

if (KW130_initial(s) != KW_Success)      /* once, after power up            */
        ...

if (KW130_set_tuner(s) != KW_Success)    /* once per frequency              */
        ...

KW130_standby();                         /* powers the blocks down          */
```

### Image rejection

`KW130_imr_cal()` measures the I/Q imbalance at six frequencies and keeps the results. It
applies nothing. Two decisions stay with you: whether to calibrate at all, and which of the
six results to use for the frequency you are about to tune.

```c
KW130_imr_cal(s);                       /* once, if you want to        */

/* later, tuning near 864 MHz                                          */
KW130_set_imr(KW130_imr_result[0]);     /* or not                      */
KW130_set_tuner(s);                     /* always needed afterwards    */
```

It runs an internal tone through the receiver, so it leaves the part unable to receive: call
`KW130_set_tuner()` afterwards whether or not you keep a result. A trim that has been applied
survives later tuning.

The six tones come from dividing the crystal, so where they land depends on it — with 24 MHz
they are 864, 608, 480, 320, 160 and 80 MHz, and with 27 MHz they are 864, 576, 459, 306, 153
and 76.5 MHz. `KW130_imr_point_KHz[]` holds the tone each point actually used, which is what
tells you which result belongs near your frequency.

A point that does not finish leaves `KW130_imr_valid[]` at 0 for that point and the call
returns `KW_Failed`. The others are still usable.

### VGA gain

One step number covers the whole VGA range, -24.8 dB to +40.0 dB in 23 steps. Step 9 is
0 dB. The steps are 3.2 dB through the middle and 2.4 dB at the two ends, and the table in
`KW130_SDR.h` gives the dB for each one.

### Choosing the channel

There is no bandwidth setting. A channel is an IF centre and two edges, so that is what you
give:

    HPF corner = IF centre - channel bandwidth / 2      the lower edge
    LPF corner = IF centre + channel bandwidth / 2      the upper edge

An 8 MHz channel at a 5 MHz IF centre is therefore HPF 1 MHz and LPF 9 MHz, which is the
example above — `KW130_hpf_0M96` being the step nearest 1 MHz.

The IF centre is a plain number in kHz: 4570 and 5000 are both ordinary values. The corners
land on the steps the part provides, listed in `KW130_lpf_E` and `KW130_hpf_E`, so pick the
nearest. `KW130_set_lpf_cor()` then trims the upper edge if you need it between two steps.

`KW130_devID` selects the I2C address, strapped on the board. It defaults to 0xF2.

It holds the **8-bit write address** - a 7-bit slave address with the R/W bit already in
place as 0 - so put it on the bus unshifted:

| | | | | |
|---|---|---|---|---|
| write | `0xF2` | `0xB2` | `0x72` | `0x32` |
| read | `0xF3` | `0xB3` | `0x73` | `0x33` |

A read is addressed with `KW130_devID | 1`. Shifting it left first is the usual porting
mistake and the part will not ACK.

`KW130_initial()` is only needed once. Call `KW130_set_tuner()` for every frequency
change; it does not need `KW130_initial()` in front of it.

To read the chip back, `KW130_dump_reg()` fills `KW130_rData[0..63]` and
`KW130_get_states()` fills only the status registers `KW130_rData[1..4]`.

---

## The GPO pin

The GPO drives whatever the board connects to it. On the Keywave EVK it is the enable for
the off-chip LNA in front of the tuner.

```c
KW130_set_gpo(1);                  /* drive it high now                      */
KW130_set_gpo_auto(1);             /* or let the tuned frequency decide      */
```

With auto mode on, `KW130_set_tuner()` raises the GPO above `KW130_gpo_auto_KHz`
(950 MHz) and lowers it below, so an LNA follows the band it covers. Auto mode is off by
default; leave it off and the pin only moves when `KW130_set_gpo()` is called.

The level survives `KW130_initial()` and every `KW130_set_tuner()`, so re-initialising
cannot silently switch the LNA off. `KW130_set_gpo()` writes R62 and R63 only, so the
crystal capacitance in R63 is not disturbed.

The pin has to be in output mode for any of this, which means `mode_gpi` in R62 must be 1.
The initial register table sets it, and the API sets it again whenever it drives the GPO.


`KW130_standby()` takes the GPO low, so an LNA in front of the tuner is off while the tuner
is. There is no separate wake-up call: `KW130_set_tuner()` is what brings the part back, and
it sets the GPO with it — from the tuned frequency when auto mode is on, and to whatever you
last asked for otherwise.
---

## Tuning

`KW130_set_tuner()` works out the AGC, gain and filter settings for the band it is
tuning. That means a register written by hand is gone at the next frequency change.

The functions below are the supported way to change one. Each value is remembered and
put back after every `KW130_set_tuner()` and every `KW130_initial()`, and each call also
writes its register straight away — so a setting can be changed, measured and changed
again without retuning in between.

Nothing is overridden until one of them is called. A host that never calls them behaves
exactly as before.

Every parameter is an enum whose name is the value it sets, so nothing here needs the
register table.

```c
/* AGC detector window. The digits are the threshold in volts x 10, so vth_16 is 1.6 V. */
/* vth is the level above which the AGC reduces gain, vtl the level below which it      */
/* increases gain.  vth_04 .. vth_19,  vtl_03 .. vtl_18.                                */
KW130_set_rf_agc(KW130_vth_16, KW130_vtl_05);     /* RF path (LNA)             */
KW130_set_bb_agc(KW130_vth_07, KW130_vtl_05);     /* baseband path (mixer amp) */

/* How fast the AGC loop runs, and the RC corner that goes with it. Twelve speeds     */
/* from 64 kHz down to 2 Hz; the corners available depend on the speed - see the      */
/* header. 4 kHz is the only corner that works with any speed.                        */
KW130_set_agc_speed(KW130_agc_speed_125Hz, KW130_agc_rc_256Hz);

/* Gain of each block. Auto follows the AGC; manual holds the step you give.            */
/* Step 0 is the least gain.  lna 0..31,  rf 0..15,  bb 0..15,  filt 0..7.               */
KW130_set_lna_gain (KW130_gain_manual, 25);       /* LNA                       */
KW130_set_rf_gain  (KW130_gain_manual,  3);       /* RF buffer                 */
KW130_set_bb_gain  (KW130_gain_auto,    8);       /* mixer amp, back to the AGC */
KW130_set_filt_gain(KW130_gain_manual,  6);       /* filter                    */

/* LPF corner trim, around the corner set_info.lpf selected. 0 narrowest, 31 widest.    */
KW130_set_lpf_cor(20);

/* TOP: the level each detector calls overload. Lower it and the AGC backs the gain off   */
/* sooner, trading sensitivity for headroom. Same numbers as the register table.          */
KW130_set_top_lna(4);                             /* 0 .. 7   */
KW130_set_top_rfbuf(1);                           /* 0 .. 7   */
KW130_set_top_mixeramp(3);                        /* 0 .. 7,  0 is the highest TOP */
KW130_set_top_filter(4);                          /* 0 .. 7,  0 is the highest TOP */

KW130_reset_tuning();          /* the API takes the defaults back at the next
                                  KW130_set_tuner()                                     */
```

The defaults `KW130_set_tuner()` applies are `vth_13` / `vtl_09` on both paths and
`agc_speed_4kHz`. Every gain block starts on auto, at step 16 (LNA), 8 (RF), 8 (mixer amp)
and 4 (filter).

In `KW130_gain_auto` the AGC drives the block and the step is kept for whenever manual is
selected.

The LPF fine trim starts at the default for the corner `set_info.lpf` selected. Raising
the HPF corner clears more of what sits near DC, at the cost of the bottom of the channel. The gain settings come back at the next `KW130_initial()` rather than the next
`KW130_set_tuner()`, since that is where the API sets them — but as overrides they survive
both.

A faster loop settles sooner and follows a changing signal; a slower one rides through
modulation without pumping. Two of the twelve settings run at 1 kHz and differ in loop
damping — `KW130_agc_speed_1kHz_f` and `KW130_agc_speed_1kHz_s`; try both if 1 kHz is the
rate you want.

`vth` above `vtl` is the sensible arrangement, but it is not enforced — the part can be
driven either way on the bench. Nothing is stored or written when a call is rejected.

---

## What you must change when upgrading from v2.91

**1. Test the result against `KW_Success`, not `KW_Failed`.**

`KW_Status` now carries the reason a call failed:

| | |
|---|---|
| `KW_Success` = 1 | as before |
| `KW_Failed` = 0 | failure with no further detail |
| `KW_I2C_Fail` | an I2C write or read did not complete |
| `KW_PLL_Unlock` | registers were written, but the VCO never reported lock |
| `KW_Bad_Param` | `set_info` carries an out-of-range field |

`KW_Success` deliberately keeps its old value, so `if (result == KW_Success)` still behaves
exactly as before. But `if (result == KW_Failed)` will now miss a real failure — change those
tests to `if (result != KW_Success)`.

**2. Provide `KW130_delay_ms()`.** New function in the porting contract, see above.

**3. The IMR arrays are gone.** `KW130_IMR_code_x[]`, `KW130_IMR_code_y[]`,
`KW130_IMR_sign_x[]` and `KW130_IMR_sign_y[]` are removed. They were always zero in v2.91, and
the API now writes a zero I/Q trim, so the register state is unchanged. Image calibration is
not part of this release.

**4. `KW130_print_reg()` and `KW130_print_var()` are gone.** They were declared in the v2.91
header but never implemented in any version, so calling them was a link error.

---

## New

**Tuning overrides.** `KW130_set_rf_agc`, `KW130_set_bb_agc`, `KW130_set_agc_speed`,
`KW130_set_lna_gain`, `KW130_set_rf_gain`, `KW130_set_bb_gain`, `KW130_set_filt_gain`,
`KW130_set_lpf_cor`, the four `KW130_set_top_*` and `KW130_reset_tuning`, described above. Every parameter is an enum
named after the value it sets rather than a register code, and the setting survives a tune,
which writing the register by hand does not.

| | |
|---|---|
| `KW130_check_set_info(set_info)` | validate a `set_info` without writing anything, so a UI can reject bad input before it reaches the chip |
| `KW130_vco_power`, `KW130_pll_retry` | read-only. After `KW130_set_tuner()`, what the PLL needed: `pll_retry` 0 with `vco_power` at 10 means it locked on the first poll at the nominal current |

`KW130_initial()` and `KW130_set_tuner()` validate `set_info` before touching the bus and
return `KW_Bad_Param` without writing anything. `format`, `xtal_freq_KHz` (16~32 MHz),
`cap_x`, `share_mode`, `vga_code`, `vga_att` and `img_rev` are checked. `RF_KHz` is
deliberately **not** range checked, so the part can be driven outside its specified band;
`KW130_RF_KHz_min` / `_max` are in the header as documentation only.

## Fixed

- **A PLL that never locks is now reported.** `KW130_set_tuner()` used to return
  `KW_Success` even after the VCO failed to lock; it returns `KW_PLL_Unlock`.
- **The PLL lock sequence waits before it polls.** The lock flag was read immediately after
  the auto-tune was released, so a fast host could read too early and needlessly raise the
  VCO current. It now settles first, and raises the current only when the search really has
  not converged.
- **`KW130_initial()` writes R5.** It wrote R6~R63, leaving R5 (`en_sync`, `sel_div1`,
  `iqgen_div2`, `lovcm_up`, `en_rfdet_ibst`) at the chip default until the first tune.
- **RF band-split settings restored.** `lovcm_up`, `pw_mix` and `LO_vcm` are set per band in
  `set_RFbuf_tuner()`; the previously released API package was missing them.
- **Table indexes are bounded.** An unknown `format` is rejected instead of reading past the
  IF table, and the tracking-filter table indexes are clamped to the tables.

## Portability

`KW130_SDR.h` needs no other header: it used `TRUE` / `FALSE` without defining them and only
compiled because a platform header happened to come first. Declarations are wrapped in
`extern "C"`, `KW_bool` replaces `bool` so neither C++ nor `<stdbool.h>` is required, and the
`UINT8`…`INT32` widths are checked at compile time — on a target where they do not hold, the
build stops at `KW130_type_width_check` and those six typedefs are the only thing to edit.
