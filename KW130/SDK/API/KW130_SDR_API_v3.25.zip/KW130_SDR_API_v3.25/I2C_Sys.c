#include "I2C_Sys.h"


//---------------------------------------------------------------------
// keywave definition functions for I2C write/read
// --------------------------------------------------------------------
KW_bool I2C_Write_Reg(UINT8 KW_devID, UINT8 regAddr, UINT8 regData)
{
	KW_bool ok = 0;					// 1 when the transfer completed


	// host output device address = KW_devID          (already the write address)
	// host output register address = regAddr
	// host output DATA buffer = regData
	
	return ok;
}

// I2C_pageWrite_Reg(UINT8 devID, UINT8 regAddr, UINT8* regDataPtr, UINT8 Len)
// ----------------------------------------------------------------------------
KW_bool I2C_pageWrite_Reg(UINT8 KW_devID, UINT8 regAddr, UINT8* regDataPtr, UINT8 Len)
{
	KW_bool ok = 0;					// 1 when the transfer completed

	

	// host output device address = KW_devID          (already the write address)
	// host output register address = regAddr
	// host output DATA buffer
	//	for (int DataCunt=0; DataCunt < Len; DataCunt++)
	//		host output DATA buffer[DataCunt] = *(regDataPtr+regAddr+DataCunt);

	return ok;
}


// -----------------------------------------------------------------------------
KW_bool I2C_pageRead_Reg(UINT8 devID, UINT8 regAddr, UINT8* regDataPtr, UINT8 Len)
{
	KW_bool ok = 0;					// 1 when the transfer completed

	
	// host output device address = KW_devID          (already the write address)
	// host output register address = regAddr
	// host repeat start 
	// host output device address = (KW_devID | 1)    (the read address, bit 0 set)
	//	for(int DataCunt = 0;	DataCunt < Len;	DataCunt ++)
	//		*(regDataPtr+regAddr+DataCunt) = host Input DATA buffer[DataCunt];

	return ok;
}


// KW130_delay_ms(UINT16 ms)
// ----------------------------------------------------------------------------
void KW130_delay_ms(UINT16 ms)
{

	// wait at least ms milliseconds, then return
	// e.g.  Sleep(ms);            // Windows
	//       HAL_Delay(ms);        // STM32 HAL
	//       usleep(ms * 1000);    // POSIX

}
