/**
 * KW307 SDK - High-Level Customer API
 * FW: 2.5.2
 *
 * Include this header to *change* radar behaviour (gain, range, FOV,
 * sensitivity, trackers, hold-time, ...). It also pulls in KW307_io.h, so you
 * get init / update / on_frame / read_blocking as well.
 *
 * If you only need to *receive* frames on the radar's saved defaults, include
 * KW307_io.h alone.
 *
 *   Sec.1  System         firmware version / factory reset / save / radar re-init
 *   Sec.2  Output mode    no need to change in the base SDK
 *   Sec.3  Device config  power / gain / range / FOV / sensitivity / ...
 *
 * Typical startup:
 *   kw307_init();
 *   kw307_check_fw_version(300);
 *   // apply your settings here (see example_platform/<port>/main.c)
 *   kw307_on_frame(on_radar);
 *   while (1) kw307_update();
 *
 * Every setter returns KW307_OK on success, or a negative KW307_ERR_* code
 * (see KW307_io.h). Arguments out of range return KW307_ERR_PARAM.
 */

#ifndef KW307_API_H
#define KW307_API_H

#include <stdint.h>
#include <stdbool.h>
#include "KW307_io.h"
#include "KW307_protocol.h"
#include "KW307_cmd.h"      /* raw access: kw307_send_cmd / read_cmd / set_parameter */

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
   Sec.1  System
   ================================================================ */

/* KW307 SDK version — the version of THIS SDK source, independent of the paired
 * MCU firmware version below. Bump on any API or behaviour change. */
#define KW307_SDK_VERSION_MAJOR  2u
#define KW307_SDK_VERSION_MINOR  4u
#define KW307_SDK_VERSION_PATCH  1u

/* MCU firmware version this SDK is paired with. */
#define KW307_SDK_FW_MAJOR  2u
#define KW307_SDK_FW_MINOR  5u
#define KW307_SDK_FW_PATCH  2u

/** Re-initialise the radar (~130 ms, blocking). Re-applies the current
 *  configuration. Call after a setting that needs an init to take effect. */
int kw307_radar_init(void);

/** Clear saved settings and reload firmware defaults. */
int kw307_factory_reset(void);

/** Persist the current settings to flash; restored automatically on next
 *  power-up. Don't call in a loop — each call uses a flash write cycle. */
int kw307_save_settings(void);

/**
 * Check the connected MCU firmware is compatible with this SDK.
 * Compatible = same MAJOR.MINOR (KW307_SDK_FW_MAJOR/MINOR); the PATCH field is
 * ignored, so any 2.5.x firmware passes.
 *   0  : compatible
 *   1  : incompatible — major or minor differs; re-verify the protocol
 *  <0  : link error (no response / UART down)
 */
int kw307_check_fw_version(int timeout_ms);


/* ================================================================
   Sec.2  Output mode
   ================================================================ */
/**
 *   kw307_set_output_default()  (re)select the default frame — presence +
 *                               2 moving + 1 still target (consume with
 *                               kw307_on_frame).
 *   kw307_set_output_off()      stop the periodic stream (the radar keeps
 *                               running); works for whichever frame is active.
 */
int kw307_set_output_default(void);
int kw307_set_output_off(void);

/* ================================================================
   Sec.3  Device config
   ================================================================ */

/** Deep-sleep Power Down.
 *    down = true  -> RF powered down, lowest current; frame output stops
 *                    (a UART byte from the host wakes it).
 *    down = false -> Normal (resume sensing).
 *  Boot default: false. */
int kw307_set_power_down(bool down);

/** RF gain. index 0~8: -3 / 0 / +3 / +6 / +9 / +12 / +15 / +18 / +21 dB.
 *  Boot default: 5 (+12 dB). */
int kw307_set_gain(uint8_t index);

/** Min + max detection distance in cm.
 *    min_cm : near gate (e.g. 50 = 0.5 m).  max_cm : far gate (e.g. 1000 = 10 m).
 *  Boot defaults: 50 / 1000. min_cm must be < max_cm. */
int kw307_set_detect_range(uint16_t min_cm, uint16_t max_cm);

/** Detection cone — how wide the radar sees in front.
 *    fov_deg         : cone width in whole degrees (1~180). Larger = picks up
 *                      people off to the sides. Boot default: 120.
 *    shrink_rate_deg : how much the cone narrows per 100cm (0~25 deg/100cm);
 *                      higher = tighter cone at long range. Boot default: 8.
 *                      You can use this to define a rectangle-like area.
 *  Tuning: false triggers from people passing by -> reduce fov_deg;
 *  missing off-centre targets at long range -> reduce shrink_rate_deg. */
int kw307_set_detect_fov(int16_t fov_deg, uint8_t shrink_rate_deg);

/** Mag threshold — detection magnitude floor for moving and stationary targets.
 *  Higher = less sensitive. Range per band 0~32767.
 *    baseline_moving     : moving-target floor      (default 350)
 *    baseline_stationary : stationary-target floor  (default 100) */
int kw307_set_mag_threshold(int16_t baseline_moving, int16_t baseline_stationary);

/** Frame-output rate + sentinel mode.
 *    option   : 0 = 20 Hz full rate (default)
 *               1 = 1 Hz   power-saving
 *               2 = 0.5 Hz power-saving
 *    sentinel : true enables adaptive power-save ("sentinel") — the module idles
 *               at the low rate and ramps up when motion appears. Only meaningful
 *               for the power-saving options (1 / 2); it is IGNORED at option 0
 *               (20 Hz is already full rate, nothing to wake from).
 *  Boot default: 20 Hz, sentinel off. option > 2 -> KW307_ERR_PARAM. */
int kw307_set_update_rate(uint8_t option, bool sentinel);

/** Motion (moving-target) sensitivity.
 *    level   : 0 (most sensitive) ~ 9 (least sensitive) — a monotonic curated
 *              preset of the moving-band HPF + Fast-band speed gate.
 *    byp_spd : 0 = normal; non-zero switches the moving HPF to its lowest cutoff
 *              and turns the speed-sum gate off, so the tracker reacts to any
 *              motion regardless of accumulated speed (e.g. a hand dryer that
 *              must fire the instant a hand appears).
 *  Affects the moving band only. level > 9 returns KW307_ERR_PARAM. */
int kw307_set_motion_sensitivity(uint8_t level, uint8_t byp_spd);

/** Stationary (still-target) sensitivity as a single level.
 *    0~9 : most-sensitive (0, catches breathing-rate motion) -> least (9);
 *          levels 7~9 also raise the detection floor (+6 dB).
 *  Affects the stationary band only. level > 9 returns KW307_ERR_PARAM. */
int kw307_set_stationary_sensitivity(uint8_t level);

/** Tune the moving-target tracker counters.
 *    cnt_max     : hold time of a moving target.
 *                  how long a target survives without re-detection,
 *                  in frames (20 fps). Default 32.
 *    cnt_show_th : response time of a moving target.
 *                  The target enters the "Shown" state once cnt >= cnt_show_th.
 *                  Default 8. Must be <= cnt_max. */
int kw307_set_moving_tracker_cnt(uint8_t cnt_max, uint8_t cnt_show_th);

/** Tune the stationary-target tracker counters.
 *  Same meanings as the moving tracker;
 * Defaults: cnt_max 64, cnt_show_th 8. */
int kw307_set_stationary_tracker_cnt(uint8_t cnt_max, uint8_t cnt_show_th);

/** Keep the presence signal asserted while a still target stands inside a
 *  forward window (distance x field-of-view), so brief detection dropouts
 *  don't flicker presence while a person sits very still.
 *
 *    on          enable (true) / disable (false).
 *    distance_cm window depth in cm (0~3276); a still target must be closer.
 *    fov_deg     window width in whole degrees (0~180), edge to edge
 *                (e.g. 60 = +/- 30 deg around directly-ahead).
 *  Boot defaults: on = true, distance_cm = 150, fov_deg = 40.
 *
 *  Tuning: presence flickers while a person sits still -> widen the window;
 *  presence lingers after they leave -> narrow it. */
int kw307_set_force_stationary(bool on, int16_t distance_cm, int16_t fov_deg);

/** Maximum time a still target may sit before the radar releases it.
 *    enable  : 1 = enforce the cap, 0 = never auto-release on time.
 *    seconds : lifetime, 0~3276 s. Higher for offices/lounges, lower for
 *              fast-cycle scenes (urinals, hand dryers).
 *  Boot default: enabled, 20 s.
 *  Tuning: presence stays "occupied" too long after the person left -> shorten;
 *  person dropped while still sitting -> lengthen, or set enable = 0. */
int kw307_set_max_stationary_time(uint8_t enable, uint16_t seconds);

/** Reject repetitive non-human motion (AC, machinery, ...) so it is not
 *  reported as presence.
 *    en     : true = on (default), false = report every moving target.
 *    spd_th : motion threshold — higher = reject more. Range 0..1000, default 300.
 *    dev_th : allowed drift in cm — higher = reject more. Range 0..50, default 20. */
int kw307_set_advanced_clutter_rejection(bool en, int16_t spd_th, int16_t dev_th);

/** Presence-flag hold time (debounce): how long the presence flag stays
 *  asserted after the last detection, so it doesn't flicker between frames.
 *  seconds : 0~3276 s (held as seconds*20 frames internally).
 *  Boot default: 6 s (120 frames). seconds > 3276 returns KW307_ERR_PARAM.*/
int kw307_set_flag_hold_time(uint16_t seconds);



#ifdef __cplusplus
}
#endif

#endif /* KW307_API_H */
