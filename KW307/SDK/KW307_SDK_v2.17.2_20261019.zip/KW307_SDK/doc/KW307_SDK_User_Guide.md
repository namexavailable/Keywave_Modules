# KW307 SDK User Guide

24 GHz human-presence radar over UART — how it works, and the call that changes each part of it

**SDK 2.17.2** · module firmware **2.10.0** and newer · 2026-10-19

Start at **Quick start**: the smallest program that works. The chapters after it follow the signal from the antenna to the target list, one section per block of the diagram, each ending with the calls that change that block. The **UART protocol** chapter at the end gives the bytes, for a host that does not run the SDK.

## Contents

1. [Quick start](#quick-start)
    1.1 [Build integration](#build-integration)
    1.2 [UART port functions](#uart-port-functions)
    1.3 [Minimal example program](#minimal-example-program)
    1.4 [Frame contents](#frame-contents)
2. [Output modes](#output-modes)
    2.1 [Output mode setup](#output-mode-setup)
    2.2 [Switching modes while running](#switching-modes-while-running)
3. [Error handling](#error-handling)
4. [Signal path](#signal-path)
    4.1 [Static clutter rejection and Doppler filters](#static-clutter-rejection-and-doppler-filters)
    4.2 [Background update control](#background-update-control)
    4.3 [Distance, angle and speed extraction](#distance-angle-and-speed-extraction)
    4.4 [Detection threshold](#detection-threshold)
    4.5 [Tracking algorithm](#tracking-algorithm)
    4.6 [Line-of-sight filtering](#line-of-sight-filtering)
    4.7 [Detect range and field of view](#detect-range-and-field-of-view)
    4.8 [Presence flag](#presence-flag)
5. [Application examples](#application-examples)
6. [Function reference](#function-reference)
    6.1 [Session](#session)
    6.2 [Filters](#filters)
    6.3 [Detection and reporting](#detection-and-reporting)
    6.4 [Custom frames](#custom-frames)
    6.5 [Trackers](#trackers)
    6.6 [Front end and power](#front-end-and-power)
7. [UART protocol](#uart-protocol)
    7.1 [UART link settings](#uart-link-settings)
    7.2 [UART frame format](#uart-frame-format)
    7.3 [Write and read requests](#write-and-read-requests)
    7.4 [Output frame layouts](#output-frame-layouts)

## Quick start

Settings take effect only once the module is running and reporting. Getting there takes five functions that you write, three calls that the SDK provides, and a main loop.

![You write the top box and the bottom one. Everything between them ships as C source.](guide/img/sdk_layers.svg)

### Build integration

Add every `.c` file under `core/` and every `.h` file beside them. There is no build system to adopt and nothing to configure at compile time. Add the files, add `core/` to your include path, and you have a C99 library with no dependency beyond the standard headers `stdint.h`, `stdbool.h`, `stddef.h` and `string.h`.

### UART port functions

The SDK never touches your hardware. It calls out to these, and you point them at whatever UART your board has:

```
int  kw307_port_open (const char* port_name, int baud_rate);
void kw307_port_close(void);
int  kw307_port_send (const uint8_t* buf, int len);
int  kw307_port_recv (uint8_t* buf, int max_len, int timeout_ms);
int  kw307_port_is_open(void);
```

`example_platform/port_template/` is a working skeleton with those five left as `TODO`. If your host is close to `STM32_HAL/`, `Arduino/`, `RPi_Pico/`, `pc_win32/` or `pc_linux/`, start from that one instead. Those are finished ports, not a list of what is supported.

The port they open is an ordinary UART at **115200 baud, 8 data bits, no parity, one stop bit, no flow control**, at **3.3 V TTL**. The baud rate is set in `user_config.h` next to the port you are writing, and has to match the module's — 115200 is what it ships with.

> **Note.** `kw307_port_recv()` must not block past `timeout_ms`, and must return what it has rather than waiting for a full buffer. Everything the SDK does on top — every read-back, every blocking command — is built on that one promise.

Every read-back waits about 200 ms (`KW307_READ_TIMEOUT_MS`) for the module's answer and then returns `KW307_ERR_TIMEOUT`, so no call can hang.

### Minimal example program

```
#include "KW307_api.h"

static void on_radar(const KW307Frame_t* f)
{
    set_led(f->presence_flag);                  /* 1 while someone is there */
}

int main(void)
{
    board_init();                            /* your clocks, pins, UART */

    if (kw307_init() != KW307_OK) return 1;  /* opens the port, starts the link */
    kw307_on_frame(on_radar);                /* your callback, one per frame */

    for (;;) kw307_update();                 /* reads the UART, runs callbacks */
}
```

`kw307_update()` does not block. Call it as often as your loop runs; the module sends a frame about twenty times a second and `on_radar` fires once per frame.

That program never configures the module, and it works: the module boots with the settings in its own flash and starts streaming. Configuration is what the rest of this guide is about, and every call in it is in scope from `KW307_api.h` alone.

> **Note.** Call `kw307_check_fw_version()` once after `kw307_init()`. It returns `0` when the firmware is compatible, `1` when it is older than this SDK needs, and a negative code if the module did not answer. On older firmware, the calls it does not have return `KW307_ERR_NOT_SUPPORTED`.

### Frame contents

```
typedef struct {
    uint16_t       frame_index;   /* frame counter */
    uint8_t        presence_flag;    /* 1 = presence this frame */
    KW307Tracker_t moving[2];     /* walking, gesturing */
    KW307Tracker_t stationary[1]; /* a seated person, micro-motion */
} KW307Frame_t;
```

The pointer is valid for the length of the callback. Copy out what you need.

> **Use a slot only when its `state` says Valid.** `state != 0` is not that test. The other non-zero values mean a target is being confirmed, or is deliberately hidden, and using those makes one person appear as two. Valid is `1` in the simple reporting form, the default. After `kw307_set_tracker_state_advanced_mode(true)`, a moving target is Valid at `3` instead. `core/KW307_protocol.h` lists every state value.

Each slot also carries `counter`, which rises while the target keeps being seen and falls when it is missed. It is useful as a confidence or fade level.

## Output modes

The quick start showed one output. There are three, and the difference between them is only **how much each frame carries**. Every one of them reports presence, two moving targets and one stationary target — that part never changes. What changes is what is added on top.

| Mode | What it adds | Payload | Your callback | Struct |
|---|---|---|---|---|
| `KW307_OUTPUT_NORMAL` | — the default frame | 27 B | `kw307_on_frame()` | `KW307Frame_t` |
| `KW307_OUTPUT_NORMAL_WITH_SPD` | how fast each moving target is going | 34 B | `kw307_on_frame_spd()` | `KW307FrameSpd_t` |
| `KW307_OUTPUT_NORMAL_WITH_SPD_RG` | the above, plus the four nearest stationary range gates | 66 B | `kw307_on_frame_spd_rg()` | `KW307FrameSpdRg_t` |

There is also `KW307_OUTPUT_OFF`, which stops the stream. The radar keeps running; frames are no longer sent.

**If you are not sure: use `KW307_OUTPUT_NORMAL_WITH_SPD`.** It is the default frame plus the one field most products end up wanting, and it costs 7 bytes a frame.

The three structs are in **`core/KW307_protocol.h`**, field by field: what each one means, what `state` is allowed to be and which value means a real target, what the speed units are, and what the range gates are and are not.

### Output mode setup

Whichever mode you pick, the two steps are the same — register the callback, then select the mode:

```
kw307_on_frame_spd(on_radar);                     /* 1. where frames go   */
kw307_set_output(KW307_OUTPUT_NORMAL_WITH_SPD);   /* 2. what to send      */

while (1) { kw307_update(); }                     /* 3. read the UART     */
```

**Register before you select.** Frames start arriving as soon as the module is told to send them. If the callback is not in place yet, the first few frames are lost.

`kw307_update()` reads the UART and calls your callback. If it is not called regularly, no frames are delivered, so check this first when no frames arrive.

### Switching modes while running

You can change mode at any time — a calibration typically goes into `KW307_OUTPUT_NORMAL_WITH_SPD_RG`, takes its reading, and returns to `KW307_OUTPUT_NORMAL_WITH_SPD`:

```
kw307_on_frame_spd(on_normal);        /* register both, once, at start-up */
kw307_on_frame_spd_rg(on_gates);

...

kw307_set_output(KW307_OUTPUT_NORMAL_WITH_SPD_RG);   /* measure   */
...
kw307_set_output(KW307_OUTPUT_NORMAL_WITH_SPD);      /* and back  */
```

**Register every callback you might use, once, at start-up.** There is nothing to unregister when you switch: only the selected mode's frames are sent, so only its callback fires. Frames still in flight from the previous mode are matched to the right callback on the way in, not mis-read.

## Error handling

Every setter and getter returns `int`: `KW307_OK` (zero) on success, or a negative error code on failure. A single test detects every failure:

```
if (kw307_set_detect_range(30, 400) != KW307_OK) { /* handle it */ }
```

A setter returns `KW307_OK` once the command is sent; it does not wait for the module's reply. To confirm a value, read it back with its getter.

Test for a specific error code only where the application must respond differently. The error codes are defined in `KW307_io.h`.

| Error code | Value | Description | Recommended action |
|---|---|---|---|
| `KW307_OK` | 0 | The call succeeded. | None. |
| `KW307_ERR_PORT` | -1 | The UART failed, or the module's reply did not match the request. A setter reports every UART failure with this code. | Check the UART connection. The call may be retried. |
| `KW307_ERR_PARAM` | -2 | An argument is outside the range the call accepts. No command was sent to the module. | Correct the argument to within the range documented for the call. |
| `KW307_ERR_NOT_SUPPORTED` | -4 | The module firmware does not support this call. Reported once `kw307_check_fw_version()` has run. | This is not an error condition. Do not retry the call, and do not use this feature with this module. |
| `KW307_ERR_TIMEOUT` | -5 | The module did not reply within the timeout. Returned by getters and blocking calls. | The call may be retried. |
| `KW307_ERR_PORT_OPEN` | -10 | `kw307_init()` could not open the UART. | Check the port name and baud rate in `user_config.h`. |
| `KW307_ERR_PORT_CLOSED` | -11 | The UART is not open: `kw307_init()` has not been called, or the port was lost. `kw307_is_open()` reports this without sending a command. | Stop sending commands and call `kw307_init()` to reopen the UART. |
| `KW307_ERR_PORT_SEND` | -12 | The UART did not accept the complete command. | Check the `kw307_port_send()` implementation in the port layer. |
| `KW307_ERR_NACK` | -20 | The module refused the request. Returned by getters and blocking calls. | Correct the request before sending it again. |
| `KW307_ERR_RESP_LEN` | -21 | The module's reply was shorter than expected. | Handle as a communication error. The call may be retried. |

> **A timeout does not always indicate a module fault.** A blocking call waits about 200 ms (`KW307_READ_TIMEOUT_MS`) for a reply, which arrives only if the application is reading the port. A stalled main loop, a disabled interrupt or a receive buffer that is never emptied causes every read to time out, even though the module is responding normally.

## Signal path

In the KW307 radar system, motion objects are categorised into two types:

- **Moving objects** — macro-movements such as walking or running.
- **Stationary objects with micro-Doppler** — micro-movements such as breathing, heartbeat, or subtle body shifts.

The radar hardware processes incoming signals through two parallel bands: the **moving band** and the **stationary band**. Both bands share a similar architecture and the same configurable parameters.

![The moving band takes 20 to 160 Hz, the stationary band 0.31 to 10 Hz.](guide/img/algorithm_flow.svg)

Every value the module reports comes out of those two paths, and every setting in this guide changes one block in one of them. Left to right:

| The block | What it does | Yours to change |
|---|---|---|
| **Analog front end** | Transmit and receive, the equalizer that compensates the signal's loss over range, and the baseband gain applied to the signal before it is digitised. | The baseband gain, and the equalizer order. |
| **Complex data per range gate** | The radar's own output: one in-phase / quadrature pair per range gate. | Which gates are in play, via the detection zone. |
| **Smooth average** | A short average over frames that takes the noise off each gate's signal before the Doppler filters see it. | Nothing. It is fixed, and it is the reason a single noisy frame does not become a target. |
| **Doppler high-pass** | Removes the stationary clutter — floors, walls, furniture, the antenna's own cross-talk. Two switches inside it decide *how* it is removed. | The corner, and the two switches. |
| **Digital gain** | A gain step after the clutter is removed, one setting for both bands. The baseband gain has to carry clutter and target together; this one carries only the residual signal, so it lifts a weak target without saturating the front end. | The step, 1x to 8x. |
| **Doppler low-pass** | Removes Doppler faster than the band covers, which is what separates the two bands. | The corner. |
| **Range-gate IIR** | An IIR filter that averages each gate's complex data over frames, one coefficient per band. | The coefficient, 0~1000. |
| **Extraction** | Turns each gate's filtered signal into a magnitude, a distance, an angle and a speed. | Nothing. |
| **Detection threshold** | Decides which gates become candidates for the tracker — fast enough for the band, and strong enough. It only decides which gates can form a target; the reported values are unchanged. | The threshold, per band. |
| **Tracking** | Decides which candidates are the same target across frames, and when a target is confirmed enough to report. | The counters. |

The **detection zone** and the **presence flag** sit beside the two bands rather than inside them: they apply to every target rather than to one point in the pipeline. The detection zone says which gates and which angles count at all; the presence flag is the presence answer on its own.

### Static clutter rejection and Doppler filters

In radar signal processing, rejecting static clutter — floors, walls, stationary furniture and antenna TX-to-RX cross-talk — is essential to isolate target motion. Static environmental clutter appears at DC (0 Hz).

- Micro-Doppler signals, such as human respiration, typically start around **0.3 Hz**.
- Macro-movements, such as walking, start around **20 Hz**.

The static clutter rejection circuit is equivalent to a Doppler high-pass filter. Setting a lower high-pass corner frequency enables detection of micro-Doppler targets, but increases susceptibility to environmental vibration clutter.

A Doppler low-pass filter filters out fast movement. If you do not want to detect fast movement, setting the low-pass corner lower keeps only slower-moving objects and lowers the environment noise.

#### Sensitivity levels

One call per band selects that band's Doppler corners for you.

```
kw307_set_motion_sensitivity(level);       /* 0~9, or -1 for any motion */
kw307_set_stationary_sensitivity(level);   /* 0~9, stationary band      */
```

Ten levels per band, from `0` (most sensitive) to `9` (least sensitive); the moving band also accepts `-1`. Each level is a row of settings picked together as a set: where the band's filters sit, and how little movement still counts.

| Level | High-pass | Min speed | Confirm frames | Speed clip | Min speed sum |
|---|---|---|---|---|---|
| **-1** | 0.16 Hz *(corner 7, nd 3)* | 1 | 4 | 2 | 0 *(off)* |
| **0** | 10 Hz *(corner 4)* | 250 | 4 | 500 | 1000 |
| **1** | 20 Hz *(corner 3)* | 250 | 4 | 500 | 1000 |
| **2** | 20 Hz *(corner 3)* | 250 | 8 | 500 | 2000 |
| **3** | 20 Hz *(corner 3)* | 500 | 4 | 1000 | 2000 |
| **4** | 40 Hz *(corner 2)* | 500 | 4 | 1000 | 2000 |
| **5** | 40 Hz *(corner 2)* | 500 | 8 | 1000 | 4000 |
| **6** | 40 Hz *(corner 2)* | 1000 | 4 | 2000 | 4000 |
| **7** | 80 Hz *(corner 1)* | 500 | 8 | 1000 | 4000 |
| **8** | 80 Hz *(corner 1)* | 1000 | 4 | 2000 | 4000 |
| **9** | 80 Hz *(corner 1)* | 1000 | 8 | 2000 | 8000 |

Moving band. `-1` is one step below 0: the lowest corner the filter has, the lowest speed that counts as movement, and the added-up speed check (`min_speed_sum`) off entirely.

| Level | High-pass | Low-pass | Baseband attenuator |
|---|---|---|---|
| **0** | 0.16 Hz *(corner 7, nd 3)* | 10 Hz *(corner 8)* | 0 dB |
| **1** | 0.31 Hz *(corner 7, nd 2)* | 10 Hz *(corner 8)* | 0 dB |
| **2** | 0.62 Hz *(corner 7, nd 1)* | 10 Hz *(corner 8)* | 0 dB |
| **3** | 1.2 Hz *(corner 7, nd 0)* | 10 Hz *(corner 8)* | 0 dB |
| **4** | 2.5 Hz *(corner 6, nd 0)* | 10 Hz *(corner 8)* | 0 dB |
| **5** | 5 Hz *(corner 5, nd 0)* | 10 Hz *(corner 8)* | 0 dB |
| **6** | 10 Hz *(corner 4, nd 0)* | 20 Hz *(corner 16)* | 0 dB |
| **7** | 10 Hz *(corner 4, nd 0)* | 20 Hz *(corner 16)* | -6 dB |
| **8** | 20 Hz *(corner 3, nd 0)* | 40 Hz *(corner 32)* | -6 dB |
| **9** | 40 Hz *(corner 2, nd 0)* | 80 Hz *(corner 64)* | -6 dB |

Stationary band. A stationary level sets **both** corners — the high-pass and the low-pass — and the baseband attenuator: 0 dB at 0~6, -6 dB at 7~9, so a level replaces the value set by `kw307_set_baseband_att()`. A level never changes the thresholds set by `kw307_set_mag_threshold()`. Levels 6 and 7 are the same filter and differ only in that 6 dB.

> **The baseband attenuator is ahead of the band split.** Levels 7~9 quieten the moving band by the same 6 dB, not the stationary band alone. If that matters, stay at 6 or below and raise the stationary threshold yourself with `kw307_set_mag_threshold()`.

#### Direct corner frequency settings

The four Doppler filters, set directly. Use these when no level lands where you want it.

```
kw307_set_moving_hpf_corner(corner, nd);       /* moving     high-pass, corner 0~7, nd 0~3 */
kw307_set_moving_lpf_corner(corner);           /* moving     low-pass, 0~255              */
kw307_set_stationary_hpf_corner(corner, nd);   /* stationary high-pass                     */
kw307_set_stationary_lpf_corner(corner);       /* stationary low-pass                      */
```

At the default 2 kHz sampling rate:

```
high-pass   2000 / 2^corner / 2^(nd + 1) / 2π   Hz
low-pass    2000 * corner / 256 / 2π            Hz
```

The high-pass halves with every step of `corner`; the low-pass is linear in it.

> **The high-pass depends on `corner + nd` and on nothing else.** So `4/2` and `6/0` are the same 2.5 Hz. `nd` is the downsample factor, 0~3. Eight corners and four `nd` give eleven distinct corner frequencies, each half the one above it. Reach for `nd` only once `corner` is at 7 and the corner still has to come down.

| corner + nd | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high-pass, Hz | 160 | 80 | 40 | 20 | 10 | 5 | 2.5 | 1.2 | 0.62 | 0.31 | 0.16 |

Defaults, and the two bands as one picture:

| | High-pass | Low-pass | What is left |
|---|---|---|---|
| Moving | 20 Hz, `3 / 0` | 160 Hz, `128` | walking, gesturing, a hand arriving |
| Stationary | 0.31 Hz, `7 / 2` | 10 Hz, `8` | breathing, a small shift in a chair |

That is motion level 2 and stationary level 1. The moving band starts where macro movement starts, so between 10 and 20 Hz both bands are rolling off. To make the two bands meet, use motion level 0, which sets the moving high-pass corner to 10 Hz.

> **Note.** Setting a corner directly can take the band off its level, so `kw307_get_motion_sensitivity()` or `kw307_get_stationary_sensitivity()` reports `KW307_LEVEL_NONE` afterwards. This is expected, not an error.

> **Warn.** The low-pass also sets the band's anti-alias limit before decimation. Raising it well past the band's own range adds no detections. It lets faster movement fold back into the range the band does report, which reads as targets that are not there. We recommend keeping the default low-pass corners, which are the tested settings.

### Background update control

The static clutter rejection is controlled in two stages. The **first stage** acts before the signal is split into the two bands, so its switches act on both bands. The **second stage** has a switch on each band. Each stage has a background update switch and a subtraction switch.

The background update switches control background adaptation:

- **Update** (the default) — operates as a standard Doppler high-pass, continuously updating the static clutter estimate.
- **Freeze** — freezes background adaptation. This effectively extends the high-pass corner frequency down to DC (0 Hz), so a newly added stationary object is detected against the memorised background.

```
kw307_en_background_update(on);                 /* first stage, both bands */
kw307_set_moving_background(update);            /* true = keep adapting */
kw307_set_stationary_background(update);
```

#### Environment subtraction switch

The high-pass is the signal minus a low-pass of itself. The switches above act on that low-pass, the background estimate; these act on the subtraction.

- **On** (the default) — the estimate is subtracted, and the output is high-passed.
- **Off** — the signal passes with the environment still in it, which is the path for measuring the environment.

```
kw307_en_background_subtraction(on);            /* first stage, both bands */
kw307_en_moving_env_subtraction(on);
kw307_en_stationary_env_subtraction(on);
```

> **To see a target that never moves, turn off both first-stage switches:** `kw307_en_background_update(false)` and `kw307_en_background_subtraction(false)`. Either one left on is enough to remove the target. Expect a noisier signal once they are off.

#### Stationary result hold

```
kw307_en_stationary_hold(on);     /* true = hold the stationary result */
```

This holds the stationary tracker result, so a change of filter state does not reach what you read. Every stationary slot keeps the distance, angle, magnitude and state it had when the hold went on. The moving band is not held.

Use the hold while you change the environment subtraction switch. Changing that switch moves the output path: the signal steps, and the estimate behind it needs seconds to settle. The module cannot tell that swing from a real target arriving or leaving, and the hold keeps it out of the stationary result. The background switch does not need the hold — it changes what the filter learns, not where the signal goes. The two first-stage switches do: changing either one steps the signal in the same way.

### Distance, angle and speed extraction

This block turns each range gate's complex (I/Q) data into a magnitude, a distance, an angle and a speed.

Ahead of it, the range-gate IIR, one per band, averages each gate's complex data over frames:

```
kw307_set_RangeGate_IIR(moving, stationary);     /* 0~1000, default 150 (0.15) both */
```

The value is the weight given to each new measurement, in thousandths:

```
output  =  k/1000 x new measurement  +  (1 - k/1000) x previous output
```

So the default 150 counts a new reading as 0.15 and what it already had as 0.85. Higher follows the measurement more closely, lower holds the previous value harder, and 1000 is no averaging at all.

One coefficient covers all four quantities: magnitude, distance, angle and speed. The tracker has its own smoothing, in **Tracking algorithm** below.

### Detection threshold

Between the readings and the tracker there is one more decision: which range gates become candidates. A gate has to be moving at the right speed for its band **and** be strong enough, or it takes no part in forming a target.

```
kw307_set_mag_threshold(moving, stationary);   /* the threshold, per band. Default 350 / 100 */
```

It is a minimum, not a target. The default suits most rooms. Raise it only when the room is noisier than the default allows for, and measure the room first with the noise floor report below.

#### Noise floor report

```
kw307_en_noise_floor_report(on);     /* off by default */
```

With it on, an **empty** target slot reports the room's peak magnitude in its `mag` instead of zero — the peak an empty room gives back, which is what a real target has to exceed.

- It reports only while **nobody is detected**. The moment the presence flag goes to 1 the slot reads 0 again: with a person in the room the peak magnitude *is* the person. It gates on **people**, not on objects, so anything else left in the room is part of the reading.
- Only the **first moving slot** and the **nearest stationary slot** carry it. The measurement is per band, not per slot, so the rest stay 0.
- It is the room's **peak**, not its average.

> **Note.** Use `state` to tell whether a slot holds a target, never `mag`. With this on an empty slot carries a non-zero magnitude, and code that treats `mag != 0` as a target will report a target in an empty room.

### Tracking algorithm

The tracker filters the impulse noise out of the range-gate data and gives each target a smooth trajectory.

A tracker counter is used to maintain the stability and credibility of the trajectory. Each slot carries a count that rises while the target keeps being seen and falls when it is missed:

```
kw307_set_moving_tracker_cnt(cnt_limit, display_th);
kw307_set_stationary_tracker_cnt(cnt_limit, display_th);
```

- `cnt_limit` — the counter's upper limit, in frames: how long a target survives without being seen again. Defaults: 32 moving, 64 stationary.
- `display_th` — the count at which the target is reported. Default 8 for both, and it must not exceed `cnt_limit`.

Beyond the counters, each band sets what it takes to report a target, and how steadily the reported position follows each new measurement:

```
kw307_set_motion_threshold(confirm_frames, min_speed, speed_clip, min_speed_sum);
kw307_set_moving_smoothing(smoothing);
kw307_set_stationary_tracker_opt(confirm_frames, smoothing, match_distance_cm);
```

- `confirm_frames` (moving) — the number of frames a new moving target's speed is added up over before it is reported, 1~32. Default 8.
- `min_speed` — the slowest movement that counts as a moving target. Default 250.
- `speed_clip` — each frame's speed is capped at this before it is added up, so one spike cannot create a target. 0 = no cap. Default 500.
- `min_speed_sum` — the total the added-up speed must exceed over `confirm_frames` for the target to be reported. 0 = no check. Default 2000.
- `confirm_frames` (stationary) — consecutive frames a stationary target must be seen in before it is reported, 1~255. Default 3.
- `match_distance_cm` — how far a new sighting may be from where a stationary target was last seen and still count as the same target. Default 100.

Speeds are in the module's own unit. At the default sampling rate 500 is about 0.19 m/s; `kw307_set_sample_rate()` changes that scale.

`smoothing` is the same weight in thousandths as the range-gate IIR above, applied to the reported track instead of to the gate: 300 (0.3) moving, 60 (0.06) stationary by default.

> **Note.** `kw307_set_motion_threshold()` is what a motion sensitivity level sets. Reading the level back after setting these four directly reports no level.

### Line-of-sight filtering

A person blocks the radar. Someone standing directly behind them sends back almost nothing. So what the module sees at that angle is usually a ghost or clutter, not a second person.

That is why the module reports only the front target by default.

Turn it off to see every candidate:

```
kw307_en_los(false);   /* report everything, hidden or not */
    /* ... read every candidate ... */
kw307_en_los(true);    /* back to normal */
```

Turn line of sight off when two people in a queue must count as two, or to see every candidate the radar returns while you tune an installation.

> **It also lets reflections through.** An echo behind a moving target is usually that target bounced off a wall. The module drops it for the same reason it drops a hidden person: it is behind something. With line of sight off, both come through. Expect more targets than there are people.

### Detect range and field of view

Objects outside the detect range and the field of view are ignored before tracking.

```
kw307_set_detect_range(min_cm, max_cm);          /* the room, in cm */
kw307_set_detect_fov(fov_deg, shrink_rate_deg);  /* the field of view, and how it narrows with distance */
```

A fixed FOV covers more floor the further out it reaches. Narrowing it with distance keeps the far end of the zone inside the room. The FOV never narrows below the limit set by `kw307_set_fov_min()`, 20° by default.

![At the default 120° with a shrink of 8° per metre: 120° at the module, 80° at 5 m, 40° at 10 m.](guide/img/detection_cone.svg)

### Presence flag

The presence flag is a simple on/off indication. Any object that shows motion or micro-Doppler signatures inside the detection zone sets it. It sets as soon as a target is confirmed, and a hold time keeps it from flickering: after the last detection, the flag stays set for the hold time, in frames.

```
kw307_set_presence_hold_time(frames);   /* default 220 = 11 s */
```

Normal operation is 20 Hz, so 1 s = 20 frames; the most, 32767 frames, is about 1638 s (27 min). `kw307_set_stationary_release_time()` counts the same way.

> **For a product's occupancy logic, we recommend using the tracker output or the range-gate data.** They report each target's magnitude, distance, angle and speed at a fixed rate, 20 Hz by default, so your logic can decide what counts as a person. The presence flag is set by any motion in the zone.

## Application examples

Five worked configurations ship with the SDK, one per `DEMO_SCENE_*` in the main program of every port under `example_platform/`. They are not presets: no call selects one. Each block is the same ordinary setters this guide describes, already tuned for a room.

| Scene | The room it was tuned for |
|---|---|
| `DEMO_SCENE_OUTDOOR` | A yard or a doorway, long and busy |
| `DEMO_SCENE_OFFICE` | A room someone works in, sitting still for long stretches |
| `DEMO_SCENE_DESK` | One person, close, a screen away |
| `DEMO_SCENE_URINAL` | A narrow bay, one occupant, quick turnover |
| `DEMO_SCENE_HAND_DRYER` | A hand held under the outlet, in a tight window |

Pick the one whose room is closest to yours and read its block in any port's main program — the baseband gain, the range, the field of view, the two sensitivity levels, the detection thresholds, the tracker counters and the holds, all in one place and all commented. Copy it and adjust from there.

`DEMO_SCENE_OFFICE` is the one the module already boots at: motion level 2, stationary level 1.

## Function reference

Grouped by where each call acts on the diagram. Every setter except the custom-frame calls has a matching `kw307_get_*` that reads the value back; those take the same pointers the setter takes values, and are omitted here.

### Session

| Call | What it does |
|---|---|
| `kw307_init()` / `kw307_close()` | Open and close the link. |
| `kw307_update()` | Read the UART and call the registered callback. Call it on every pass of your main loop. |
| `kw307_radar_init()` | Re-initialise the module. Settings return to the last save; unsaved changes are discarded. |
| `kw307_save_settings()` | Write the current settings to flash. Wait about 1 s before the next call. Call it only after settings have changed, not on every pass of a loop: a call that saves a change rewrites the flash. |
| `kw307_factory_reset()` | Return every setting, and the output mode, to the default. |
| `kw307_clear_state()` | Drop stale targets without touching settings. |
| `kw307_check_fw_version()` | Check the module firmware is compatible with this SDK: `0` compatible, `1` firmware older than this SDK needs, negative on a link error. |

### Filters

| Call | What it does |
|---|---|
| `kw307_set_motion_sensitivity(level)` | Moving band as one level, 0~9, or -1 for any motion at all. |
| `kw307_set_stationary_sensitivity(level)` | Stationary band as one level, 0~9. |
| `kw307_set_moving_hpf_corner(corner, nd)` | Moving high-pass, directly. |
| `kw307_set_moving_lpf_corner(corner)` | Moving low-pass. |
| `kw307_set_stationary_hpf_corner(corner, nd)` | Stationary high-pass. |
| `kw307_set_stationary_lpf_corner(corner)` | Stationary low-pass. |
| `kw307_en_background_update(on)` | First-stage background update, both bands. On by default. |
| `kw307_set_moving_background(update)` | Freeze or keep adapting, moving band. Not saved. |
| `kw307_set_stationary_background(update)` | Freeze or keep adapting, stationary band. Not saved. |
| `kw307_en_background_subtraction(on)` | First-stage background subtraction, both bands. On by default; turn off both first-stage switches to see a target that never moves. |
| `kw307_en_moving_env_subtraction(on)` | Subtract the environment, or pass it through. Not saved. |
| `kw307_en_stationary_env_subtraction(on)` | The same, stationary band. Not saved. |
| `kw307_en_stationary_hold(on)` | Freeze the stationary detections while you disturb that band. Not saved. |

### Detection and reporting

| Call | What it does |
|---|---|
| `kw307_set_detect_range(min_cm, max_cm)` | Detect range: the near and far limits, in cm. |
| `kw307_set_detect_fov(fov_deg, shrink_rate_deg)` | Field of view, and how it narrows with distance. |
| `kw307_set_fov_min(fov_deg)` | The narrowest the shrink can make the FOV. |
| `kw307_set_mag_threshold(moving, stationary)` | The detection threshold per band. |
| `kw307_en_noise_floor_report(on)` | Report the room's noise floor in an empty slot's magnitude. |
| `kw307_set_presence_hold_time(frames)` | How long the presence flag holds after the last detection, in frames (20 = 1 s). |
| `kw307_en_gpio_presence_flag(on)` | Mirror the presence flag on the GPIO pin. Not saved. |
| `kw307_set_output(mode)` | Which frame the module sends: `_NORMAL`, `_NORMAL_WITH_SPD`, `_NORMAL_WITH_SPD_RG`, or `_OFF`. Not saved. |
| `kw307_on_frame(cb)` | Receive `KW307_OUTPUT_NORMAL` frames. |
| `kw307_on_frame_spd(cb)` | Receive `KW307_OUTPUT_NORMAL_WITH_SPD` frames. |
| `kw307_on_frame_spd_rg(cb)` | Receive `KW307_OUTPUT_NORMAL_WITH_SPD_RG` frames. |

### Custom frames

| Call | What it does |
|---|---|
| `kw307_out_clear(c)` | Every block off - the start of a new shape. |
| `kw307_out_normal_with_spd(c)` / `kw307_out_normal_with_spd_rg(c)` | Start from the `KW307_OUTPUT_NORMAL_WITH_SPD` or `KW307_OUTPUT_NORMAL_WITH_SPD_RG` shape instead. |
| `kw307_out_presence(c, on)` | The presence flag. |
| `kw307_out_moving_trk(c, on, full, speed)` | The two moving trackers, whole or state only, with or without speed. |
| `kw307_out_stationary(c, nearest, second)` | The nearest and second-nearest stationary targets. |
| `kw307_out_stationary_trk(c, on, full)` | The four stationary-band trackers. |
| `kw307_out_room_max(c, on)` | The room's peak magnitude per band. |
| `kw307_out_rg(c, start_rg, end_rg, moving, stationary, mag_only)` | Range gates, per band. |
| `kw307_out_len(c)` | The frame size that shape will produce. |
| `kw307_set_output_config(c)` | Send the shape. Nothing reaches the module before this. |
| `kw307_set_output_rg(start_rg, end_rg, en_moving_trk, en_stationary_trk)` | The board-tuning shape in one call: both bands' gates, trackers optional. |
| `kw307_on_frame_f3(cb)` | Receive any shape, decoded into `KW307FrameF3_t`. |
| `kw307_dec_frame_f3(data, len, out)` | Decode one from payload bytes, for your own transport. |

### Trackers

| Call | What it does |
|---|---|
| `kw307_en_los(on)` | Drop targets standing directly behind a nearer one. On by default; turn it off to see every candidate. |
| `kw307_set_moving_tracker_cnt(cnt_limit, display_th)` | Moving counters, in frames. |
| `kw307_set_stationary_tracker_cnt(cnt_limit, display_th)` | Stationary counters. |
| `kw307_set_motion_threshold(frames, min_speed, clip, sum)` | What counts as movement. A level sets these. |
| `kw307_set_moving_smoothing(smoothing)` | How steadily a moving target's position follows. |
| `kw307_set_stationary_tracker_opt(confirm, smoothing, match_cm)` | What it takes to report a stationary target, and how steadily. |
| `kw307_set_RangeGate_IIR(moving, stationary)` | How much each gate's magnitude, distance, angle and speed are averaged over frames. |
| `kw307_set_presence_hold_zone(on, distance_cm, fov_deg)` | Hold presence while somebody stands still in a near forward zone. |
| `kw307_set_stationary_release_time(enable, frames)` | Drop a stationary target after this many frames (20 = 1 s). |
| `kw307_set_tracker_state_advanced_mode(advanced)` | Choose the advanced reporting form, which adds the in-between states, or the simple one (Empty / Valid). |
| `kw307_set_advanced_clutter_rejection(en, spd_th, dev_th)` | Reject repetitive motion such as a fan. |

### Front end and power

| Call | What it does |
|---|---|
| `kw307_set_gain(index)` | Baseband gain in the analog receive chain, 0 to +21 dB. |
| `kw307_set_equalizer_gain(index)` | Equalizer gain in the analog receive chain, 0 to +12 dB. |
| `kw307_set_baseband_att(index)` | Baseband attenuator, 0 to -12 dB. Every stationary level sets it too. |
| `kw307_set_digital_gain(index)` | Digital gain. |
| `kw307_set_equalizer_order(order)` | Equalizer order. |
| `kw307_set_antenna(pa_num, rx_ant_num, with_angle)` | Which antennas are in use, and whether the angle is measured. |
| `kw307_set_sample_rate(sel)` | Sampling rate. The filter equations assume the 2 kHz default. |
| `kw307_set_power_mode(mode)` | Power mode. After DOWN, sensing resumes only on NORMAL. Not saved. |

## UART protocol

Everything above is the SDK speaking this protocol for you. This section is the protocol itself. You need the bytes in two cases: a host that does not run the SDK, and a link that misbehaves and needs a logic analyser on it.

### UART link settings

| | |
|---|---|
| Baud rate | 115200 |
| Data bits · parity · stop bits | 8 · none · 1 |
| Flow control | None |
| Logic level | 3.3 V TTL — low 0 V, high 3.3 V |
| Byte order | Big-endian, MSB first, payloads included |

### UART frame format

```
00 00 00 00 00   AA  55   CMD   LEN_H LEN_L   DATA ...   CRC_H CRC_L
└── wake-up ──┘  └SOF┘
```

| Field | |
|---|---|
| Wake-up | At least five `0x00` bytes before **every** frame you send. The module drops into an idle low-power state between commands, and these wake it; they are discarded. It has to be `0x00`; another filler byte is not a substitute. |
| SOF | `AA 55` to write or to stream, `AA 56` to read. The second byte is the only thing that distinguishes a write from a read request. |
| CMD | What the frame is about. The same CMD number is used for the write and the read of a setting. |
| LEN | Payload length, big-endian, not counting CRC. |
| CRC | CRC-16, polynomial `0x8005`, seed `0xFFFF`, big-endian, computed over CMD + LEN + DATA. The SOF and the wake-up bytes are outside it. |

> **Send the wake-up bytes and the frame as one stream.** A gap lets the module go back into that idle state before the command arrives. The command is then lost with no error on either side: the frame was never received, so there is nothing to NACK. This is a common cause when a host that does not use the SDK receives no reply.

### Write and read requests

A **write** is `AA 55 [CMD] …`. The module replies with an ACK frame on CMD `0xAC` whose payload carries the CMD it is answering and a status byte:

| Status | |
|---|---|
| `0x00` | Done. |
| `0x01` | The value was out of range. |
| `0x02` | The module does not accept that request for this CMD. |
| `0x03` | CRC mismatch; the frame arrived damaged. |
| `0x04` | The length field did not match the payload. |

A CMD the module does not recognise is dropped, with no reply at all.

A **read** is `AA 56 [CMD]` with an empty or selector-only payload. The module answers with the same ACK frame and, when the status is `0x00`, follows it with the current value on the same CMD.

Output frames streamed by the module (`0xF0`, `0xF3`) arrive without a request, with the same header and CRC but no wake-up bytes, and no ACK: they are output, not a reply.

### Output frame layouts

`core/KW307_protocol.h` says what every field means, including the `state` values and which ones mean a Valid target. That header is the reference; this is only the byte layout, which no header carries.

Each of the three output modes has **one fixed layout**. Every multi-byte value is 16-bit **big-endian**, and distances on the wire are in **millimetres** — the SDK converts them to centimetres, a host parsing the bytes does not.

A **tracker** is the same 8 bytes everywhere it appears.

Its offsets carry a `+`: they count from the tracker's first byte, wherever it sits in the frame. The frame tables below count from the first byte of the payload.

| Offset | Field | Type |
|---|---|---|
| +0~1 | `distance_mm` | uint16 |
| +2~3 | `angle_tenth` | int16, 0.1 degree |
| +4~5 | `mag` | uint16 |
| +6 | `state` | uint8 |
| +7 | `counter` | uint8 |

#### `KW307_OUTPUT_NORMAL`, CMD `0xF0`, 27 bytes

| Offset | Field |
|---|---|
| 0~1 | `frame_index` |
| 2 | `presence_flag` |
| 3~10 | moving target 1 |
| 11~18 | moving target 2 |
| 19~26 | stationary target |

#### `KW307_OUTPUT_NORMAL_WITH_SPD`, CMD `0xF3`, 34 bytes

| Offset | Field |
|---|---|
| 0~1 | `frame_index` |
| 2~4 | `B0 2C 09` — the shape bytes, always these three in this mode |
| 5 | `presence_flag` |
| 6~13 | moving target 1 |
| 14~21 | moving target 2 |
| 22~25 | the two moving targets' speeds, int16 each |
| 26~33 | stationary target |

#### `KW307_OUTPUT_NORMAL_WITH_SPD_RG`, CMD `0xF3`, 66 bytes

| Offset | Field |
|---|---|
| 0~1 | `frame_index` |
| 2~4 | `30 2E 09` — the shape bytes, always these three in this mode |
| 5 | `presence_flag` |
| 6~13 | moving target 1 |
| 14~21 | moving target 2 |
| 22~25 | the two moving targets' speeds, int16 each |
| 26~33 | stationary target |
| 34~41 | `distance_mm`, stationary-band gates 0, 1, 2, 3 |
| 42~49 | `angle_tenth`, gates 0~3 |
| 50~57 | `mag`, gates 0~3 |
| 58~65 | speed, gates 0~3 |

Those are the raw per-gate readings, before grouping and before any tracker. A gate with nothing in it reads as noise, not as zero; a gate beyond the detect range reads zero.

> **Tell the two `0xF3` modes apart by bytes 2~4, never by length.** The two differ in those three bytes. A length check cannot tell a truncated frame of one shape from a whole frame of the other. `KW307_OUTPUT_NORMAL` has no shape bytes — it is `0xF0`, and only ever 27 bytes.
