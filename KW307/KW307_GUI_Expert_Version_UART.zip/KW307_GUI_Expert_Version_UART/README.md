# KW307 Tools

Browser-based configuration GUI and SDK user guide for the Keywave **KW307**
24 GHz mmWave radar presence-sensing module.

| Folder | Contents |
|---|---|
| `gui/` | `KW307_GUI_B.5_20261014.html`: UART configuration and live-view GUI (version B.5, SDK 2.17.1, firmware 2.10.0) |
| `docs/` | `KW307_SDK_User_Guide.html`: SDK user guide |

## Using the GUI

1. Connect the KW307 to your computer through a USB-to-UART adapter (115200 8N1 by default).
2. Open `gui/KW307_GUI_B.5_20261014.html` in **Chrome or Edge**. The GUI uses Web Serial, which Firefox and Safari do not support.
3. Pick the serial port and press **Connect**.

You don't need to install anything or run a server. The page runs entirely from the file.

## Contributing

Issues and pull requests are welcome. Contributions submitted to this repository
are licensed under the Apache License, Version 2.0 (Section 5 of the License).

## License

Copyright 2026 Keywave Technology Ltd

Licensed under the [Apache License, Version 2.0](LICENSE). See [NOTICE](NOTICE)
for attribution requirements.

"Keywave", "KW307" and the Keywave logo are trademarks of Keywave Technology Ltd
and are not licensed under the Apache License. You may say your project "works
with the KW307". Please don't present a modified version as an official Keywave
release.
