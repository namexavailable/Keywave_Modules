/******************************************************************************
 * KW307 SDK - WiFi Dashboard (ESP32-S3)
 *
 * One-page web UI mapping each KW307 SDK 2.7.5 public API call to a
 * button / input, plus a Canvas-based radar fan plot.
 * Paired MCU firmware: 2.7.5.
 *
 *  BOARD
 *    ESP32-S3. Nothing in the sketch is tied to that part beyond the two UART
 *    pins below.
 *
 *  REQUIRED LIBRARY
 *    "WebSockets" by Markus Sattler
 *      Sketch > Include Library > Manage Libraries > search "WebSockets"
 *    The dashboard is pushed, not polled: the board sends one 30-byte binary
 *    frame per module frame (~20 Hz) over ws://<board>:81, so the plot moves
 *    when the radar does rather than when a browser timer fires. The settings
 *    panel is still pulled, from /state at 1 Hz, because nothing on it changes
 *    unless someone presses ENTER. If the socket cannot open the page falls
 *    back to polling /data by itself, at the old 10 Hz.
 *
 *    The status bar shows which transport is live (Push / Polling) and the
 *    measured rate beside it, so "is it really 20 Hz" is a thing you read off
 *    the page rather than infer. A "drop N%" figure there means frames are
 *    being lost on the link: frame_index is monotonic, so gaps prove it.
 *
 *  TWO CONNECTION METHODS - pick one in setup() below:
 *    Option A  Access Point:  wifi.connectAP("KW307-Radar", "12345678")
 *                              -> connect to that SSID, open http://192.168.4.1
 *    Option B  Station mode:  wifi.connectSTA(WIFI_SSID, WIFI_PASS)
 *                              -> open http://kw307.local (or printed IP)
 *
 *  WIRING
 *    Module TX -> ESP32 GPIO 17  (RADAR_RX_PIN)
 *    Module RX -> ESP32 GPIO 18  (RADAR_TX_PIN)
 *    GND       -> GND
 *    VCC 3V3   -> 3V3
 *
 *  All SDK .c / .h files live in this sketch folder so Arduino compiles
 *  them automatically. Each /cmd endpoint on the web side maps to exactly
 *  one kw307_* API function - see KW307WiFi.cpp::_handleCmd.
 *
 *============================================================================
 * READING A FRAME - THE ONE RULE THAT IS EASY TO GET WRONG
 *============================================================================
 *  A target slot counts ONLY when its state means Valid.
 *
 *      NEVER write   if (slot.state != 0)      <-- wrong
 *      NEVER write   if (slot.mag   != 0)      <-- wrong, mag is signal
 *                                                  strength, not presence
 *      ALWAYS write  if (slot.state == <the Valid value>)
 *
 *  Which number is Valid depends on the reporting form the module is in:
 *
 *      form                      moving[0..1]     stationary[0]
 *      ----------------------    -------------    -------------
 *      simple   (module default)  Valid = 1        Valid = 1
 *      advanced (evaluation)      Valid = 3        Valid = 1
 *
 *  The other non-zero values are NOT targets to act on: in the advanced form
 *  1 and 2 are candidates the module has not confirmed, and a stationary 2 is
 *  a still target sitting where a moving one already is. Treating them as real
 *  reports people who are not there, or the same person twice.
 *
 *  The form cannot be assumed either, and there is no test that works for both:
 *  state 1 means Valid in the simple form but "not confirmed yet" in the
 *  advanced one, so reading it the wrong way either hides every moving target
 *  or invents ones that are not there. This sketch never hard-codes 1 or 3.
 *  It settles the question three ways, none of which costs a byte on the wire:
 *
 *    - firmware older than 2.7.5 has no simple form, so the version alone
 *      answers it (read once with Check FW);
 *    - if this sketch set the form itself, it already knows;
 *    - otherwise it watches the frames. A moving slot above 1 cannot occur in
 *      the simple form, so the first target that appears proves which form is
 *      running, and the answer corrects itself if anything changes it later.
 *
 *  That third rule is what makes a module someone else left in the advanced
 *  form work on first power-up without anyone noticing. See advForm() in the
 *  dashboard script and _saw_adv in KW307WiFi.h.
 *
 *  For the minimal non-web version of the same rule, see
 *  KW307_SDK_base/example_platform/Arduino_ESP32S3/main.ino (MOVING_VALID).
 *****************************************************************************/

#include "KW307_api.h"
#include "port_arduino.h"
#include "KW307WiFi.h"

/* ----- Pin definitions ------------------------------------------------- */
/* Radar UART. Changing the pins: avoid 26~32 (flash), 33~37 (octal PSRAM),
 * 0 / 3 / 45 / 46 (strapping) and 19 / 20 (USB). */
#define RADAR_RX_PIN   17    /* GPIO receiving from module TX */
#define RADAR_TX_PIN   18    /* GPIO driving module RX        */
#define RADAR_SERIAL   Serial1

/* ----- WiFi (Option B only) ------------------------------------------- */
#define WIFI_SSID      "YOUR_WIFI"
#define WIFI_PASS      "YOUR_PASSWORD"

KW307WiFi wifi;

/* Latches every incoming frame into the dashboard. Handling frames yourself
 * instead? Read "READING A FRAME" above first. */
static void on_radar(const KW307Frame_t* f)
{
    wifi.feedFrame(f);
}

void setup()
{
    /* The console runs over native USB, so it never touches the radar's UART. */
    Serial.begin(115200);
    Serial.println(F("\n== KW307 WiFi Dashboard =="));

    /* 1. Start WiFi. Pick ONE method. The delay lets the 3V3 rail settle
     *    before the WiFi PHY draws its startup current - keep it. */
    delay(500);
    wifi.connectAP("KW307-Radar", "12345678");
    // wifi.connectSTA(WIFI_SSID, WIFI_PASS);

    Serial.print(F("[WiFi] Dashboard: "));
    Serial.println(wifi.getURL());

    /* 2. Bind HardwareSerial to the SDK and start it. */
    kw307_port_arduino_begin(RADAR_SERIAL, RADAR_RX_PIN, RADAR_TX_PIN);

    /* 3. Open the SDK. On failure the dashboard just reports NO DATA. */
    if (kw307_init() != KW307_OK)
        Serial.println(F("[SDK] kw307_init failed - radar link unavailable"));

    /* 4. No boot preset - the module keeps its own saved settings, so Save on
     *    the dashboard survives a power cycle. To force one, call kw307_set_*
     *    here plus wifi.setScene(n) to match the UI. */
    Serial.println(F("[MCU] not contacted - press Check FW on the dashboard"));

    /* 5. Register the per-frame callback. */
    kw307_on_frame(on_radar);
}

void loop()
{
    kw307_update();    /* drains UART RX + dispatches on_radar callback */
    wifi.tick();       /* services HTTP + mDNS + captive DNS */
}
