/******************************************************************************
 * KW307WiFi.h - WiFi HTTP dashboard wrapper for the KW307 radar (ESP32 family)
 *
 * Serves a one-page dashboard over WiFi:
 *   - a live radar plot showing the targets the module reports
 *   - five module actions, drawn over the plot:
 *       Check FW / Initial / Clear State / Factory Reset / Save Setting
 *   - a settings panel: gain, detection range, field of view, sensitivity,
 *     signal thresholds, trackers, hold time and the feature switches
 *
 * Editing a control only changes what the browser is holding. ENTER then
 * applies the whole panel to the module in one batch. ENTER sits directly
 * under the plot so the radar stays in view while the settings go out.
 *
 * Every setting on the page maps to one public kw307_set_* function from
 * KW307_api.h; _processCommand() in the .cpp is the whole mapping.
 *
 * Scene presets (Outdoor / Office / Desk / Urinal / Hand Dryer) live in the
 * browser. Picking one only fills the panel — nothing reaches the module
 * until ENTER.
 *
 * TRACKER STATE FORM — see "READING A FRAME" in the .ino for the full rule.
 *   A slot holds a target only at its Valid value: moving 1 in the simple form,
 *   3 in the advanced one, stationary 1 in both. Never test state != 0.
 *
 *   Which form is running is decided in three places, highest authority first,
 *   and none of them costs any extra traffic:
 *     version < 2.7.0  no simple form exists, always advanced
 *     _trk_adv         this dashboard set the form, so it knows
 *     _saw_adv         a moving slot above 1 was seen, which the simple form
 *                      cannot produce (feedFrame)
 *   The page needs the last two to apply the same rule, and they travel apart
 *   because they change at different rates: _saw_adv rides every push frame,
 *   _trk_adv sits in /state with the rest of the panel. The third rule is what
 *   lets a module left in the advanced form work on first power-up, and is why
 *   boot neither writes nor reads anything.
 *
 * USAGE (in your .ino):
 *
 *   KW307WiFi wifi;
 *   static void on_radar(const KW307Frame_t* f) { wifi.feedFrame(f); }
 *
 *   void setup() {
 *       kw307_port_arduino_begin(Serial1, 17, 18);
 *       kw307_init();
 *       kw307_on_frame(on_radar);
 *       wifi.connectAP("KW307-Radar", "12345678");
 *   }
 *
 *   Boot deliberately puts nothing on the UART — not even a version read. The
 *   module is listened to and never touched until the operator presses
 *   Check FW, which unlocks the rest of the page.
 *****************************************************************************/

#ifndef KW307_WIFI_H
#define KW307_WIFI_H

/* Any ESP32 variant the Arduino core supports — nothing below is specific to
 * one. Only the UART pins in the .ino need to match the board. */
#if !defined(ESP32)
#error "KW307WiFi requires an ESP32-family board (ESP32 / S2 / S3 / C3 / C6)."
#endif

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <DNSServer.h>

/* Frames are PUSHED over a WebSocket, one per module frame (~20 Hz), rather
 * than polled — see _wsPush(). Polling cost what it could not buy back: a
 * request every 100 ms still only sampled half the frames, and each one paid
 * for a fresh TCP connection plus ~700 bytes of JSON that was mostly settings
 * which had not changed. The push frame is 30 bytes and costs no request.
 *
 * Needs "WebSockets" by Markus Sattler:
 *   Sketch > Include Library > Manage Libraries > search "WebSockets"
 *   or https://github.com/Links2004/arduinoWebSockets */
#if !defined(__has_include) || !__has_include(<WebSocketsServer.h>)
#error "Missing library: install 'WebSockets' by Markus Sattler via Sketch > Include Library > Manage Libraries."
#endif
#include <WebSocketsServer.h>

#include "KW307_api.h"

#define KW307_MDNS_NAME  "kw307"

/* Port 80 stays with the HTTP server, so the socket needs its own. */
#define KW307_WS_PORT    81

class KW307WiFi {
public:
    KW307WiFi();

    /* ----- Lifecycle ------------------------------------------------ */
    void   connectAP (const char* ssid = "KW307-Radar",
                      const char* password = "12345678",
                      uint8_t channel = 11);
    void   connectSTA(const char* ssid, const char* password);
    void   tick();
    String getURL();

    /* ----- Fed by the sketch --------------------------------------- */
    void feedFrame(const KW307Frame_t* f);
    void setScene(uint8_t mode)    { _scene = mode; }

private:
    WebServer        _server;
    WebSocketsServer _ws;
    DNSServer        _dns;
    bool             _apMode = false;

    /* Push-frame wire format: 30 bytes, little-endian, laid out in _wsPush().
     * The matching decoder is decodeFrame() in the dashboard script — the two
     * must be changed together, so bump VER whenever the layout moves. The page
     * drops a frame whose version it does not recognise rather than reading the
     * old offsets out of new data, which would show plausible wrong targets
     * instead of an obvious failure. */
    static const uint8_t WS_FRAME_VER = 1;
    static const uint8_t WS_FRAME_LEN = 30;

    /* Latest frame snapshot (latched by feedFrame()). _frame_ms timestamps it
     * so /data can report the frame's age: _have_frame alone only says "a frame
     * arrived at some point", which would let a dead link keep showing the last
     * reading as if it were current. */
    volatile KW307Frame_t _frame;
    volatile uint8_t      _have_frame = 0;
    volatile uint32_t     _frame_ms   = 0;

    /* Which reporting form the frames actually arrive in, worked out by
     * watching them rather than by asking the module. In the simple form a
     * moving slot only ever reports 0 or 1; 2 and 3 exist solely in the
     * advanced form, so seeing either is proof — no false positive is
     * possible. Set in feedFrame(), cleared whenever something may have
     * changed the form, and re-latched on the next target, so it corrects
     * itself without costing a single byte on the wire. */
    volatile uint8_t      _saw_adv    = 0;

    /* When the form was last disturbed, for the settling window in feedFrame().
     * Clearing _saw_adv is not enough on its own: the module only changes form
     * from its next frame, and frames it had already sent are still in the RX
     * buffer, so those stale ones re-latch the flag we just cleared. _saw_adv
     * never expires, so that one frame would pin the display to the old form
     * for good. 0 = never disturbed. */
    volatile uint32_t     _form_change_ms = 0;

    /* How long to stay deaf. 5 frames at the module's 20 Hz — enough to cover
     * the frame in flight, the "from the next frame" changeover and whatever
     * the RX buffer was holding, while staying far below the time it takes an
     * operator to notice anything. */
    static const uint32_t FORM_SETTLE_MS = 250u;

    /* Arm the window; call after anything that may have changed the form. */
    void _formDisturbed() { _form_change_ms = millis(); }
    /* False while the window is open. */
    bool _settled() const
    { return _form_change_ms == 0u || (millis() - _form_change_ms) > FORM_SETTLE_MS; }

    /* FW version read by the "Check FW" dashboard button — the only place it
     * comes from, since boot no longer reads it. 0/0/0 means never asked;
     * major == 0xFF means asked and the module did not answer. The page tells
     * those two apart: pressing the button unlocks the main actions either way,
     * while Clear State and the tracker-state form need a real version. */
    uint8_t _fw_major = 0;
    uint8_t _fw_minor = 0;
    uint8_t _fw_patch = 0;

    /* Mirror state — matches the dashboard's UI state, NOT a read-back of the
     * module. Seeded with the OFFICE scene preset (scene 1), which is also what
     * the dashboard's combos default to. The sketch does not push a boot preset
     * (the module keeps its own saved settings), so these values only become
     * authoritative once the user presses ENTER. */
    uint8_t  _scene          = 1;
    uint8_t  _gain           = 5;       /* +12 dB */
    uint16_t _range_min_cm   = 50;
    uint16_t _range_max_cm   = 1000;
    int16_t  _fov_deg10      = 1200;
    uint8_t  _shrink_deg10   = 80;      /* 8 deg / 100 cm */
    int16_t  _signal_moving      = 350;
    int16_t  _signal_stationary  = 100;
    uint16_t _hold_sec       = 11;

    /* Motion / Stationary combo indices (UI display + lookup key).
     * 2.7.5: level 0 = most sensitive ... 9 = least sensitive. */
    uint8_t _motion_idx     = 2;   /* L2 */
    uint8_t _motion_byp     = 0;   /* byp_spd: bypass the Fast-band speed gate */
    uint8_t _stationary_idx = 1;   /* L1 */

    /* ---- Rest of the settings panel ---- */
    bool     _force_sta_on      = true;
    int16_t  _force_sta_dist_cm = 150;
    int16_t  _force_sta_fov_deg = 40;
    uint8_t  _max_sta_en        = 1;
    uint16_t _max_sta_sec       = 20;
    uint8_t  _mov_trk_max       = 32;
    uint8_t  _mov_trk_show      = 8;
    uint8_t  _sta_trk_max       = 64;
    uint8_t  _sta_trk_show      = 8;
    bool     _clutter_en        = true;  /* repetitive-motion (fan / AC) rejection */
    int16_t  _clutter_spd       = 300;
    int16_t  _clutter_dev       = 20;    /* cm */

    /* Feature switches: Power Down / presence output pin / tracker form. */
    bool     _power_down        = false;
    bool     _gpio_flag         = true;  /* presence output pin follows the flag */
    bool     _trk_adv           = false; /* tracker-state reporting form */

    /* HTTP route handlers. */
    void _startServer();
    void _startMDNS();
    void _handleRoot();
    void _handleData();
    void _handleState();
    void _handleCmd();

    /* Serialise the latched frame and broadcast it to every socket client.
     * Called straight from feedFrame(), which is safe because the SDK runs the
     * frame callback in the caller's context (KW307_io.h) — that is loop(), not
     * an ISR, so the socket write needs no queue in between. */
    void _wsPush();

    /* Parse / dispatch a "verb:args" POST body. */
    void _processCommand(const String& cmd);

    static int _parseInt(const String& s, int fallback);

    /* The embedded dashboard HTML (defined at the bottom of the .cpp). */
    static const char _dashboardHtml[] PROGMEM;
};

#endif /* KW307_WIFI_H */
