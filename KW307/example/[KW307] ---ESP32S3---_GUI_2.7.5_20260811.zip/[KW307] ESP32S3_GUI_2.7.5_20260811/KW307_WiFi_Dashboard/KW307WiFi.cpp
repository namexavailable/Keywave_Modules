/******************************************************************************
 * KW307WiFi.cpp - ESP32 WiFi dashboard implementation
 *
 * Three HTTP endpoints:
 *   GET  /       the dashboard page (embedded at the bottom of this file)
 *   GET  /data   JSON: the latest radar frame plus the current settings
 *   POST /cmd    one "verb:args" line, applied to the module
 *
 * Editing a control on the page changes browser-side state only. ENTER then
 * sends the whole panel as a batch of /cmd lines. Each verb in
 * _processCommand() below calls one kw307_* function from KW307_api.h.
 *****************************************************************************/
#include "KW307WiFi.h"
#include "KW307_cmd.h"   /* kw307_cmd_read_fw_version */
#include <string.h>


KW307WiFi::KW307WiFi() : _server(80) {}

/* ============================================================
   Lifecycle
   ============================================================ */
void KW307WiFi::connectAP(const char* ssid, const char* password)
{
    /* Report what the AP interface actually does. Without this a client that
     * cannot associate looks identical to one that never tried: the sketch
     * carries on either way and the console stays silent. The sequence for a
     * healthy join is AP_START -> STACONNECTED -> STAIPASSIGNED. */
    WiFi.onEvent([](arduino_event_id_t ev, arduino_event_info_t info) {
        (void)info;
        switch (ev) {
            case ARDUINO_EVENT_WIFI_AP_START:          Serial.println(F("[WiFi] AP interface up"));      break;
            case ARDUINO_EVENT_WIFI_AP_STOP:           Serial.println(F("[WiFi] AP interface down"));    break;
            case ARDUINO_EVENT_WIFI_AP_STACONNECTED:   Serial.println(F("[WiFi] client associated"));    break;
            case ARDUINO_EVENT_WIFI_AP_STADISCONNECTED:Serial.println(F("[WiFi] client left"));          break;
            case ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED:  Serial.println(F("[WiFi] client got an IP"));     break;
            default: break;
        }
    });

    WiFi.mode(WIFI_AP);
    /* Check the result. softAPIP() is not proof of anything: WiFi.mode() alone
     * creates the AP interface and gives it the default 192.168.4.1, so the
     * address prints happily even when the radio never started advertising. */
    bool ok = WiFi.softAP(ssid, password);
    _apMode = true;
    delay(200);
    _dns.start(53, "*", WiFi.softAPIP());
    _startServer();
    _startMDNS();

    Serial.print(F("[WiFi] softAP("));
    Serial.print(ssid);
    Serial.print(F(") -> "));
    Serial.println(ok ? F("OK") : F("FAILED"));
    Serial.print(F("[WiFi] mode="));
    Serial.print((int)WiFi.getMode());
    Serial.print(F("  AP MAC="));
    Serial.print(WiFi.softAPmacAddress());
    Serial.print(F("  channel="));
    Serial.println(WiFi.channel());
}

void KW307WiFi::connectSTA(const char* ssid, const char* password)
{
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) delay(250);
    if (WiFi.status() != WL_CONNECTED) return;   /* caller can retry / fall back to AP */
    _apMode = false;
    _startServer();
    _startMDNS();
}

void KW307WiFi::_startServer()
{
    _server.on("/",     HTTP_GET,  [this]() { _handleRoot(); });
    _server.on("/data", HTTP_GET,  [this]() { _handleData(); });
    _server.on("/cmd",  HTTP_POST, [this]() { _handleCmd();  });
    _server.onNotFound([this]() { _handleRoot(); });
    _server.begin();
}

void KW307WiFi::_startMDNS()
{
    if (MDNS.begin(KW307_MDNS_NAME)) MDNS.addService("http", "tcp", 80);
}

String KW307WiFi::getURL()
{
    String url = "http://";
    url += (_apMode ? WiFi.softAPIP().toString() : WiFi.localIP().toString());
    url += " (or http://" KW307_MDNS_NAME ".local)";
    return url;
}

void KW307WiFi::tick()
{
    if (_apMode) _dns.processNextRequest();
    _server.handleClient();
}

/* ============================================================
   Frame latch (called from kw307_on_frame() callback in sketch)
   ============================================================ */
void KW307WiFi::feedFrame(const KW307Frame_t* f)
{
    memcpy((void*)&_frame, f, sizeof(KW307Frame_t));
    _have_frame = 1;
    _frame_ms   = millis();   /* stamped so /data can report the frame's age */

    /* Passive detection of the reporting form — see _saw_adv in the header.
     * A moving slot above 1 cannot occur in the simple form, so one sighting
     * settles it. Done here rather than in the browser because the page polls
     * at 10 Hz while frames arrive at 20 Hz: sampling would miss the brief
     * candidate states this relies on.
     *
     * Deaf for FORM_SETTLE_MS after anything that may have changed the form,
     * because the frames arriving right then are the old form's: the module
     * switches from its next frame and the RX buffer still holds what it sent
     * before that. Latching one of those would pin the display to the form we
     * just left — permanently, since _saw_adv has no way to expire. The window
     * costs nothing: it only ever follows a write of our own, which is exactly
     * when _trk_adv already knows the answer. */
    if (_settled() && (f->moving[0].state > 1u || f->moving[1].state > 1u))
        _saw_adv = 1u;
}

/* ============================================================
   HTTP: /  (dashboard HTML)
   ============================================================ */
void KW307WiFi::_handleRoot()
{
    _server.sendHeader("Cache-Control", "no-cache");
    _server.send_P(200, "text/html", _dashboardHtml);
}

/* ============================================================
   HTTP: /data  (JSON snapshot of latest frame + mirror state)
   ============================================================ */
void KW307WiFi::_handleData()
{
    KW307Frame_t f;
    memcpy(&f, (const void*)&_frame, sizeof(KW307Frame_t));
    uint8_t fresh = _have_frame;

    /* Milliseconds since the last frame landed. "fresh" only says a frame
     * arrived at some point in the past, so the dashboard needs the age to
     * tell a live reading from one frozen by a dead link or Power Down.
     * Clamped so the JSON field stays a small number. */
    uint32_t age = fresh ? (millis() - _frame_ms) : 999999u;
    if (age > 999999u) age = 999999u;

    char j[2048];
    snprintf(j, sizeof(j),
        "{"
          "\"fw_major\":%u,\"fw_minor\":%u,\"fw_patch\":%u,"
          "\"fresh\":%u,\"age\":%u,"
          "\"frame_index\":%u,"
          "\"human\":%u,"
          /* Per slot: distance cm, angle 0.1 deg, mag, state, counter. */
          "\"moving\":["
            "{\"d\":%u,\"a\":%d,\"m\":%u,\"st\":%u,\"cnt\":%u},"
            "{\"d\":%u,\"a\":%d,\"m\":%u,\"st\":%u,\"cnt\":%u}],"
          "\"stationary\":{\"d\":%u,\"a\":%d,\"m\":%u,\"st\":%u,\"cnt\":%u},"
          "\"scene\":%u,"
          "\"gain\":%u,"
          "\"range_min_cm\":%u,\"range_max_cm\":%u,"
          "\"fov_deg10\":%d,\"shrink_deg10\":%u,"
          "\"signal_moving\":%d,\"signal_stationary\":%d,"
          "\"hold_sec\":%u,"
          "\"motion_idx\":%u,\"motion_byp\":%u,\"stationary_idx\":%u,"
          "\"trk_adv\":%u,\"saw_adv\":%u,\"gpio_flag\":%u,"
          "\"clutter_en\":%u,\"clutter_spd\":%d,\"clutter_dev\":%d,"
          "\"last_nack\":%u,"
          "\"power_down\":%u,"
          "\"force_sta_on\":%u,\"force_sta_dist\":%d,\"force_sta_fov\":%d,"
          "\"max_sta_en\":%u,\"max_sta_sec\":%u,"
          "\"mov_trk_max\":%u,\"mov_trk_show\":%u,"
          "\"sta_trk_max\":%u,\"sta_trk_show\":%u"
        "}",
        (unsigned)_fw_major, (unsigned)_fw_minor, (unsigned)_fw_patch,
        (unsigned)fresh, (unsigned)age,
        fresh ? (unsigned)f.frame_index : 0u,
        fresh ? (unsigned)f.human_flag : 0u,
        fresh ? (unsigned)f.moving[0].distance_cm : 0u, fresh ? (int)f.moving[0].angle_tenth : 0,
        fresh ? (unsigned)f.moving[0].mag : 0u,
        fresh ? (unsigned)f.moving[0].state : 0u,        fresh ? (unsigned)f.moving[0].counter : 0u,
        fresh ? (unsigned)f.moving[1].distance_cm : 0u, fresh ? (int)f.moving[1].angle_tenth : 0,
        fresh ? (unsigned)f.moving[1].mag : 0u,
        fresh ? (unsigned)f.moving[1].state : 0u,        fresh ? (unsigned)f.moving[1].counter : 0u,
        fresh ? (unsigned)f.stationary[0].distance_cm : 0u, fresh ? (int)f.stationary[0].angle_tenth : 0,
        fresh ? (unsigned)f.stationary[0].mag : 0u,
        fresh ? (unsigned)f.stationary[0].state : 0u,        fresh ? (unsigned)f.stationary[0].counter : 0u,
        (unsigned)_scene,
        (unsigned)_gain,
        (unsigned)_range_min_cm, (unsigned)_range_max_cm,
        (int)_fov_deg10, (unsigned)_shrink_deg10,
        (int)_signal_moving, (int)_signal_stationary,
        (unsigned)_hold_sec,
        (unsigned)_motion_idx, (unsigned)_motion_byp, (unsigned)_stationary_idx,
        (unsigned)_trk_adv, (unsigned)_saw_adv, (unsigned)_gpio_flag,
        (unsigned)_clutter_en, (int)_clutter_spd, (int)_clutter_dev,
        (unsigned)kw307_last_nack_status(),
        (unsigned)_power_down,
        (unsigned)_force_sta_on, (int)_force_sta_dist_cm, (int)_force_sta_fov_deg,
        (unsigned)_max_sta_en, (unsigned)_max_sta_sec,
        (unsigned)_mov_trk_max, (unsigned)_mov_trk_show,
        (unsigned)_sta_trk_max, (unsigned)_sta_trk_show);

    _server.sendHeader("Cache-Control", "no-cache");
    _server.send(200, "application/json", j);
}

/* ============================================================
   HTTP: /cmd  (POST verb:args)
   ============================================================ */
void KW307WiFi::_handleCmd()
{
    String body = _server.arg("plain");
    body.trim();
    _processCommand(body);
    _server.send(200, "text/plain", "ok");
}

int KW307WiFi::_parseInt(const String& s, int fallback)
{
    if (s.length() == 0) return fallback;
    return (int)s.toInt();
}

/* Each verb maps to a kw307_* public API call (or short sequence of
 * calls for combos that aggregate multiple parameters). */
void KW307WiFi::_processCommand(const String& cmd)
{
    int colon = cmd.indexOf(':');
    String verb = (colon >= 0) ? cmd.substring(0, colon) : cmd;
    String rest = (colon >= 0) ? cmd.substring(colon + 1) : String();

    auto next = [&rest]() -> String {
        int c = rest.indexOf(':');
        String t = (c >= 0) ? rest.substring(0, c) : rest;
        rest = (c >= 0) ? rest.substring(c + 1) : String();
        return t;
    };

    /* ---- Scene preset ----------------------------------------------
     * Carries no settings of its own. The preset table lives in the browser
     * and only fills the panel there; ENTER then pushes every setting
     * explicitly. All this verb does is record which preset the panel is
     * showing, so /data can report it back. */
    if (verb == "scene") {
        uint8_t m = (uint8_t)_parseInt(rest, _scene);
        if (m < 5) _scene = m;
    }

    /* ---- Gain ------------------------------------------------------ */
    else if (verb == "gain") {
        uint8_t g = (uint8_t)_parseInt(rest, _gain);
        if (kw307_set_gain(g) == KW307_OK) _gain = g;
    }

    /* ---- Detection range, min / max in cm -------------------------- */
    else if (verb == "range") {
        uint16_t mn = (uint16_t)_parseInt(next(), _range_min_cm);
        uint16_t mx = (uint16_t)_parseInt(rest, _range_max_cm);
        if (kw307_set_detect_range(mn, mx) == KW307_OK) {
            _range_min_cm = mn; _range_max_cm = mx;
        }
    }

    /* ---- Field of view + shrink rate ------------------------------ */
    else if (verb == "fov") {
        int16_t fov = (int16_t)_parseInt(next(), _fov_deg10);
        uint8_t sh  = (uint8_t)_parseInt(rest, _shrink_deg10);
        /* Both arrive as deg×10 (1200 = 120°, 80 = 8°/100 cm); the API
         * takes whole degrees. Mirrors stay in deg×10 for /data. */
        if (kw307_set_detect_fov(fov / 10, (uint8_t)(sh / 10)) == KW307_OK) {
            _fov_deg10 = fov; _shrink_deg10 = sh;
        }
    }

    /* ---- Motion sensitivity ---------------------------------------
     * "motion:<level>[:<byp_spd>]", level 0 = most sensitive ... 9 = least.
     * byp_spd makes the tracker react to any motion regardless of how much
     * speed has built up - for something like a hand dryer that has to fire
     * the instant a hand appears. */
    else if (verb == "motion") {
        int idx = _parseInt(next(), _motion_idx);
        int byp = _parseInt(rest, _motion_byp);
        if (idx >= 0 && idx <= 9) {
            if (kw307_set_motion_sensitivity((uint8_t)idx, byp ? 1u : 0u) == KW307_OK) {
                _motion_idx = (uint8_t)idx;
                _motion_byp = byp ? 1u : 0u;
            }
        }
    }

    /* ---- Stationary sensitivity, level 0~9 ------------------------ */
    else if (verb == "stationary") {
        int idx = _parseInt(rest, _stationary_idx);
        if (idx >= 0 && idx <= 9) {
            if (kw307_set_stationary_sensitivity((uint8_t)idx) == KW307_OK)
                _stationary_idx = (uint8_t)idx;
        }
    }

    /* ---- Presence flag hold time, seconds ------------------------- */
    else if (verb == "hold") {
        uint16_t s = (uint16_t)_parseInt(rest, _hold_sec);
        if (kw307_set_flag_hold_time(s) == KW307_OK) _hold_sec = s;
    }

    /* ---- Signal threshold, moving / stationary -------------------- */
    else if (verb == "signal") {
        int16_t fa = (int16_t)_parseInt(next(), _signal_moving);
        int16_t sl = (int16_t)_parseInt(rest, _signal_stationary);
        if (kw307_set_mag_threshold(fa, sl) == KW307_OK) {
            _signal_moving = fa; _signal_stationary = sl;
        }
    }

    /* ================================================================
       Module actions — the five buttons over the radar plot
       ================================================================ */

    /* ---- Initial - re-initialise the radar -----------------------
     * Reloads the module's saved settings and restarts detection, which
     * takes about 130 ms. Any setting applied but not saved is dropped, so
     * re-send the panel (ENTER) afterwards. */
    else if (verb == "radarinit") {
        kw307_radar_init();
        /* Reloads the saved record, which may hold a different reporting form
         * than the one currently running — re-detect instead of trusting the
         * old sighting. Same reason as the factory reset below. The call blocks
         * ~130 ms with the module still streaming, so the RX buffer is holding
         * several pre-init frames by the time it returns: settle before
         * believing any of them. */
        _saw_adv = 0u;
        _formDisturbed();
    }

    /* ---- Clear State - needs FW 2.7.2 or newer -------------------
     * Drops the targets the module is holding and resets the presence flag.
     * Settings and flash are untouched; targets take a moment to reappear. */
    else if (verb == "clearstate") {
        kw307_clear_state();
    }

    /* ---- Factory Reset -------------------------------------------- */
    else if (verb == "reset") {
        kw307_factory_reset();
        /* Back at firmware defaults, so the mirror's own idea of the reporting
         * form is stale too. Defaults mean simple, and the frames still in
         * flight are from before that — the case the window exists for. */
        _trk_adv = false;
        _saw_adv = 0u;
        _formDisturbed();
    }

    /* ---- Save Setting --------------------------------------------- */
    else if (verb == "save") {
        kw307_save_settings();
    }

    /* ---- Check FW - read the module's firmware version ----------- */
    else if (verb == "fwver") {
        uint8_t maj = 0, min_ = 0, patch = 0;
        if (kw307_cmd_read_fw_version(300, &maj, &min_, &patch) == KW307_OK) {
            _fw_major = maj;
            _fw_minor = min_;
            _fw_patch = patch;
        } else {
            /* Sentinel: dashboard JS treats major == 0xFF as "read failed". */
            _fw_major = 0xFF;
            _fw_minor = 0xFF;
            _fw_patch = 0xFF;
        }
    }

    /* ---- Power Down ----------------------------------------------- */
    else if (verb == "powerdown") {
        bool down = (_parseInt(rest, 0) != 0);
        if (kw307_set_power_down(down) == KW307_OK) _power_down = down;
    }

    /* ---- Force-stationary window ---------------------------------- */
    else if (verb == "forcesta") {
        bool on = (_parseInt(next(), _force_sta_on ? 1 : 0) != 0);
        int16_t dist = (int16_t)_parseInt(next(), _force_sta_dist_cm);
        int16_t fov  = (int16_t)_parseInt(rest, _force_sta_fov_deg);
        if (kw307_set_force_stationary(on, dist, fov) == KW307_OK) {
            _force_sta_on = on; _force_sta_dist_cm = dist; _force_sta_fov_deg = fov;
        }
    }

    /* ---- Max stationary time -------------------------------------- */
    else if (verb == "maxsta") {
        uint8_t  en  = (uint8_t) _parseInt(next(), _max_sta_en);
        uint16_t sec = (uint16_t)_parseInt(rest, _max_sta_sec);
        if (kw307_set_max_stationary_time(en, sec) == KW307_OK) {
            _max_sta_en = en; _max_sta_sec = sec;
        }
    }

    /* ---- Moving tracker counters ---------------------------------- */
    else if (verb == "movtrk") {
        uint8_t mx = (uint8_t)_parseInt(next(), _mov_trk_max);
        uint8_t sh = (uint8_t)_parseInt(rest,   _mov_trk_show);
        if (kw307_set_moving_tracker_cnt(mx, sh) == KW307_OK) {
            _mov_trk_max = mx; _mov_trk_show = sh;
        }
    }

    /* ---- Stationary tracker counters ------------------------------ */
    else if (verb == "statrk") {
        uint8_t mx = (uint8_t)_parseInt(next(), _sta_trk_max);
        uint8_t sh = (uint8_t)_parseInt(rest,   _sta_trk_show);
        if (kw307_set_stationary_tracker_cnt(mx, sh) == KW307_OK) {
            _sta_trk_max = mx; _sta_trk_show = sh;
        }
    }

    /* ---- Tracker state reporting form ----------------------------
     * false = simple (module default): a slot is Valid at state 1.
     * true  = advanced: a moving slot is Valid at 3, with Checking / Birth
     *         candidates and Hidden stationary slots also reported.
     * The plot reads "trk_adv" from /data to pick the right Valid value.
     * Needs FW 2.7.0 or newer. Older firmware has no simple form - it always
     * emits the advanced values and ignores this write - so on such a module
     * the switch has to be set On for the plot to match what is arriving. */
    else if (verb == "trkadv") {
        bool adv = (_parseInt(rest, _trk_adv ? 1 : 0) != 0);
        if (kw307_set_tracker_state_advanced_mode(adv) == KW307_OK) {
            _trk_adv = adv;
            /* The form just changed, so anything observed before this says
             * nothing about it now. Dropping the latch also means a switch back
             * to simple is not held advanced by an old sighting — and if the
             * module did not actually take the write, the next target re-latches
             * it within a frame or two.
             *
             * The window matters most here: the return value above only says the
             * bytes went out, so this is exactly the path where stale frames and
             * a cleared latch meet. Without it, switching back to simple with
             * someone in front of the radar re-latches advanced from a frame the
             * module had already sent, and every moving target then fails the
             * Valid test for good. */
            _saw_adv = 0u;
            _formDisturbed();
        }
    }

    /* ---- Presence output pin -------------------------------------
     * Not persisted by kw307_save_settings(). */
    else if (verb == "gpioflag") {
        bool on = (_parseInt(rest, _gpio_flag ? 1 : 0) != 0);
        if (kw307_set_gpio_human_flag(on) == KW307_OK) _gpio_flag = on;
    }

    /* ---- Repetitive-motion (clutter) rejection -------------------- */
    else if (verb == "clutter") {
        bool    en  = (_parseInt(next(), _clutter_en ? 1 : 0) != 0);
        int16_t spd = (int16_t)_parseInt(next(), _clutter_spd);
        int16_t dev = (int16_t)_parseInt(rest,   _clutter_dev);
        if (kw307_set_advanced_clutter_rejection(en, spd, dev) == KW307_OK) {
            _clutter_en = en; _clutter_spd = spd; _clutter_dev = dev;
        }
    }
}

/* ============================================================
   Embedded dashboard HTML  (also mirrored standalone as
   KW307WiFi_Dashboard.html in this folder)
   ============================================================ */
const char KW307WiFi::_dashboardHtml[] PROGMEM = R"HTMLEOF(
<!DOCTYPE html><html><head><meta charset="UTF-8">
<!-- Without this tag a phone lays the page out on a 980 px virtual canvas and
     then shrinks the result to fit the screen, so 16 px text arrives at about
     6 px and every width media query below sees 980 rather than the real 390.

     initial-scale is the one knob for how large the page reads. It pins the
     ratio rather than the layout width, so the apparent text size comes out the
     same on any phone; the layout viewport becomes device-width / scale, and
     that is the width the media queries below see. On a 390 px phone:

       scale   layout viewport   16 px text reads as
       1.00        390 px            16.0 px   1:1, nothing shrunk
       0.90        433 px            14.4 px
       0.85        459 px            13.6 px
       0.80        488 px            12.8 px   <-- set here
       0.70        557 px            11.2 px
       0.60        650 px             9.6 px
       0.50        780 px             8.0 px   crosses the 719 px breakpoint:
                                               the plot flip buttons come back
       (no tag)    980 px             6.4 px   what this page did before

     Shrinking costs tap area as well as height — at 0.80 a 28 px select reads
     as 22 px — so this is the trade against the dropdowns being easy to hit.

     Desktop browsers ignore the tag entirely, so none of this reaches the
     >= 1280 px layout. -->
<meta name="viewport" content="width=device-width,initial-scale=0.8">
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:sans-serif;}
body{background:#0a0a0a;color:#ddd;padding:10px;font-size:16px;}
h1{color:#00aaff;font-size:24px;display:inline;}
.sub{color:#666;font-size:16px;margin-left:8px;}
#bar{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:6px;
     padding:6px 10px;margin:8px 0;display:flex;gap:14px;align-items:center;
     flex-wrap:wrap;font-size:16px;}
#bar b{color:#0af;}
#bar .st{flex:1;color:#888;}
#bar .st.ok{color:#0c6;} #bar .st.err{color:#f53;}
.radarwrap{position:relative;margin-bottom:8px;}
/* The plot border doubles as the presence indicator: it lights up green
 * whenever the module reports a person, so the state is readable from across
 * the room without finding the readout. */
canvas#radar{background:#000;border:1px solid #222;border-radius:6px;
             display:block;width:100%;
             transition:border-color .15s ease, box-shadow .15s ease;}
canvas#radar.present{border-color:#00e06a;
                     box-shadow:0 0 16px rgba(0,224,106,0.55);}
/* Middle overlay column, left of Check FW / Clear State: frame counter on top
 * of the presence readout. Same 102 px total height as the button stacks
 * either side, so all three line up along the bottom of the plot. */
.midStack{position:absolute;right:172px;bottom:14px;width:148px;display:flex;
          flex-direction:column;gap:6px;align-items:stretch;}
#frameBox{height:36px;box-sizing:border-box;line-height:24px;padding:5px 8px;
          border:1px solid #444;background:#1a1a1a;border-radius:4px;
          color:#0af;font-size:16px;text-align:center;font-family:monospace;
          letter-spacing:1px;box-shadow:0 2px 6px rgba(0,0,0,0.6);}
#frameBox.stale{color:#777;}
/* Presence readout. Colour is the indicator, with a third state so a dead
 * link cannot masquerade as "nobody here". */
#humanBox{height:80px;
          display:flex;flex-direction:column;align-items:center;
          justify-content:center;gap:2px;border-radius:4px;
          border:1px solid #444;background:#1a1a1a;
          box-shadow:0 2px 6px rgba(0,0,0,0.6);
          transition:background .15s ease, border-color .15s ease;}
#humanBox .hl{font-size:20px;letter-spacing:1px;color:#777;}
#humanBox .hv{font-size:20px;font-weight:bold;line-height:1;color:#666;
              font-family:monospace;letter-spacing:1px;}
#humanBox.on {background:#04361f;border-color:#00c060;}
#humanBox.on  .hl{color:#8fe0b4;}
#humanBox.on  .hv{color:#00e06a;}
#humanBox.nd {background:#2a1f00;border-color:#a36b00;}
#humanBox.nd  .hl{color:#c99a3a;}
#humanBox.nd  .hv{font-size:20px;color:#fa3;}
.panel{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:6px;
       padding:10px 12px;margin-bottom:8px;}
.title{font-size:24px;color:#0af;letter-spacing:1px;text-transform:uppercase;
       margin-bottom:8px;display:flex;justify-content:space-between;}
.title .cmd{color:#555;font-weight:normal;font-size:16px;}
input,select{background:#252525;color:#0af;border:1px solid #333;
             border-radius:4px;padding:5px 8px;font-size:16px;
             font-family:inherit;}
/* One settings row: label on the left, then up to two fixed control slots.
 * A control tagged .wide spans both slots. Explanatory text lives in title=
 * tooltips so the panel stays short. */
.g{display:grid;grid-template-columns:minmax(0,1fr) 96px 96px;
   gap:3px 6px;align-items:center;padding:3px 0;}
.g .lb{grid-column:1;color:#bbb;font-size:16px;line-height:1.25;}
.g .c1{grid-column:2;} .g .c2{grid-column:3;}
.g .wide{grid-column:2 / span 2;}
.g select,.g input[type=number]{width:100%;min-width:0;}
.g .note{grid-column:1 / span 3;color:#c99a3a;font-size:14px;line-height:1.35;
         margin-top:2px;}
/* Checkbox rows: the box sits in the label cell. */
.ck{display:flex;align-items:center;gap:6px;cursor:pointer;}
.ck input[type=checkbox]{width:18px;height:18px;flex:none;margin:0;
                         accent-color:#0af;cursor:pointer;}
.ck.dis{opacity:0.45;cursor:not-allowed;}
.ck.dis input[type=checkbox]{cursor:not-allowed;}
.g .c2.ck{font-size:16px;color:#bbb;}
.sep{border-top:1px solid #2a2a2a;margin:7px 0 4px;}
button{background:#003399;color:#fff;border:none;border-radius:4px;
       padding:8px 18px;font-size:16px;cursor:pointer;font-family:inherit;}
button:hover{background:#0050d0;}
.rightActs{position:absolute;right:12px;bottom:14px;display:flex;
           flex-direction:column;gap:6px;align-items:stretch;width:148px;}
/* Lives in #bar, alongside the connection state and the NACK count. It used
 * to sit on top of Check FW in the button stack, where a readout the size of
 * a button, one gap away from a button, simply read as a second button. Up
 * here it is unmistakably a reading, and the stack below holds nothing but
 * things you can press. */
#fwDisplay{background:#252525;border:1px solid #444;color:#888;
           padding:2px 10px;border-radius:4px;font-size:16px;
           font-family:monospace;letter-spacing:1px;white-space:nowrap;}
#fwDisplay.match{color:#0c6;border-color:#0c6;}
#fwDisplay.partial{color:#fa3;border-color:#fa3;}
#fwDisplay.bad{color:#f53;border-color:#a33;}
#fwDisplay.scene{color:#0af;border-color:#0af;}
#fwBtn{background:#333;color:#fff;font-size:16px;font-weight:bold;
       height:36px;box-sizing:border-box;padding:0 10px;
       border:1px solid #666;border-radius:4px;
       cursor:pointer;font-family:inherit;
       box-shadow:0 2px 6px rgba(0,0,0,0.6);}
#fwBtn:hover{background:#444;}
#fwBtn.busy{background:#aa6600;}
/* Attention cues for the one button that unlocks the rest. The ring grows
 * and fades rather than blinking on and off - it reads as 'look here'
 * without the strobe of a hard flash, and it sits outside the button so the
 * label stays legible. Cleared by applyLocks() as soon as Check FW has been
 * pressed, whether the read succeeded or not. */
@keyframes fwPulse{
  0%,100%{box-shadow:0 2px 6px rgba(0,0,0,0.6), 0 0 0 0 rgba(250,170,51,0.55);}
  50%    {box-shadow:0 2px 6px rgba(0,0,0,0.6), 0 0 0 7px rgba(250,170,51,0);}
}
#fwBtn.attn{border-color:#fa3;color:#fa3;animation:fwPulse 1.6s ease-out infinite;}
@media (prefers-reduced-motion:reduce){ #fwBtn.attn{animation:none;} }
#bar .hint{color:#fa3;font-weight:bold;}
#bar .hint.off{display:none;}
#enter{background:#006633;color:#fff;font-size:20px;font-weight:bold;
       letter-spacing:1px;width:100%;height:52px;box-sizing:border-box;
       padding:0 10px;border:none;border-radius:4px;
       cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.6);
       font-family:inherit;}
#enter:hover:not(:disabled){background:#009955;}
#enter:disabled,.actBtn:disabled,#fwBtn:disabled{
       opacity:0.4;cursor:not-allowed;}
#enter.pending{background:#a36b00;}
#enter.sending{background:#aa6600;}
.mcuActs{position:absolute;left:12px;bottom:14px;display:flex;
         flex-direction:column;gap:6px;align-items:stretch;width:148px;}
/* Shared look for the four action buttons — they sit in either stack
 * (Clear State lives on the right, under Check FW). */
.actBtn{width:148px;height:36px;box-sizing:border-box;
        background:#2c2c2c;color:#ddd;border:1px solid #555;
        border-radius:4px;padding:0 8px;font-size:16px;
        font-weight:bold;cursor:pointer;font-family:inherit;
        box-shadow:0 2px 6px rgba(0,0,0,0.6);}
.actBtn:hover{background:#3d3d3d;}
.actBtn.danger{background:#5a1a1a;border-color:#a33;color:#fdd;}
.actBtn.danger:hover{background:#7a2a2a;}
.actBtn.busy{background:#aa6600;}
.actBtn.on{background:#04361f;border-color:#00c060;color:#7bffb0;}
.actBtn.on:hover{background:#075c33;}
#sysCard{display:block;}         /* the action buttons' home at every width */
#sysHost{display:flex;gap:6px;flex-wrap:wrap;}
/* The per-slot readout table. In the wide layout it takes the plot's
 * bottom-left corner. Everywhere else it sits in
 * #outHost, directly under the plot, together with the presence strip: the
 * readouts belong with the fan they describe, and at 16 px text there is no
 * width left to float them over it. */
#outBox{border:1px solid #444;border-radius:4px;background:rgba(20,20,20,0.92);
        padding:6px 8px 5px;box-shadow:0 2px 6px rgba(0,0,0,0.6);}
/* outCol stacks the Nearest toggle above the box so the button sits outside the
 * frame. #nearHost holds no button except in the wide layout; :empty collapses
 * it (and its flex gap) so the box position is unaffected elsewhere. */
#outCol{display:flex;flex-direction:column;gap:6px;align-items:flex-start;}
#outCol > #outBox{align-self:stretch;}
#nearHost:empty{display:none;}
/* Nearest filters what the plot draws — it never reaches the module — so it
 * belongs on the plot, not in the System card with the module actions. This
 * slot holds it in the bottom-left corner; the wide layout keeps its own
 * placement just above the readout frame, which is in that corner already.
 * The 14 px bottom offset is the one draw() assumes when it reserves room
 * under the fan for the overlays. */
#nearOnPlot{position:absolute;left:12px;bottom:14px;}
#nearOnPlot:empty{display:none;}
#nearGroup{display:flex;gap:6px;align-items:flex-end;}
/* The flip toggles need a corner wide enough to sit beside Nearest, and
 * under 720 px the plot has not got one. They are pure view state, so
 * dropping them there costs nothing that cannot be had by turning the
 * screen. Narrower than Nearest because their labels are shorter. */
.flipBtn{width:auto;padding:0 12px;}
@media (max-width:719px){ .flipBtn{display:none;} }
/* Plot zoom — how far the fan reaches, nothing else. It is a view control,
 * like Nearest, so it lives on the plot: bottom-right at every width except
 * the wide layout, which drops it into .midStack directly under the Human
 * box. Never sent to the module. */
#rangeOnPlot{position:absolute;right:12px;bottom:14px;width:190px;}
#rangeOnPlot:empty{display:none;}
#rangeBox{display:flex;align-items:center;gap:6px;height:36px;
          box-sizing:border-box;padding:0 8px;border:1px solid #444;
          background:#1a1a1a;border-radius:4px;
          box-shadow:0 2px 6px rgba(0,0,0,0.6);}
#rangeBox .rgl{color:#777;font-size:16px;letter-spacing:1px;flex:none;}
#rangeBox select{flex:1;min-width:0;padding:2px 4px;}
.radarwrap > #outCol{position:absolute;bottom:14px;left:172px;right:332px;}
/* Card placement of the two action stacks — relayout() parks them in the
 * System card at every width, so they never compete with the plot. */
#sysHost .mcuActs,#sysHost .rightActs{position:static;width:auto;}
#outHost > #outCol{margin-bottom:8px;}
/* Under the plot the frame counter and the presence box turn from a vertical
 * stack into one horizontal strip as wide as the Output box below it. */
#outHost > .midStack{position:static;flex-direction:row;width:auto;
                     height:44px;gap:8px;margin-bottom:8px;}
#outHost > .midStack #frameBox{flex:none;width:160px;height:44px;
                               line-height:32px;}
#outHost > .midStack #humanBox{flex:1;height:44px;flex-direction:row;
                               justify-content:center;gap:12px;}
/* Frame # lives in .midStack unless the wide layout moves it in here. */
#outBox .ofr{display:none;}
#outBox .oh{font-size:16px;letter-spacing:1px;color:#0af;text-transform:uppercase;
            margin-bottom:4px;}
/* Above the box it is a compact strip rather than a full-width stack button. */
#nearHost .actBtn{width:auto;height:30px;padding:0 14px;font-size:16px;
                  letter-spacing:0;}
#outTab{width:100%;border-collapse:collapse;font-family:monospace;font-size:16px;}
#outTab th{color:#777;font-weight:normal;font-size:16px;text-align:center;
           padding:0 0 2px;}
#outTab td{color:#0af;text-align:center;padding:1px 0;
           border-top:1px solid #262626;}
#outTab td.rl,#outBox .rl{color:#bbb;text-align:left;font-family:sans-serif;
                          font-size:16px;}
/* The ONLY reason a row is dimmed: the Nearest filter is on and this is not the
 * chosen row. Slot validity is not styled — the State column already spells out
 * Empty / Check / Birth / Hidden, and greying on top of that meant a row stayed
 * grey after the filter was switched off. Beats the td.rl colour by carrying one
 * more type selector. */
#outTab tr.dim td{color:#555;}
#outBox .ofr{align-items:center;gap:8px;margin-top:4px;
             padding-top:4px;border-top:1px solid #262626;}
#outBox #outFrame{color:#0af;font-family:monospace;font-size:16px;}

/* ===========================================================================
   Wide layout (>= 1280 px): a narrow settings column on the left and the
   radar plot filling the rest on the right, with the presence readout
   sitting on the plot itself.

   The cut-off is a window width, not a device: a PC window dragged narrow
   gets the single-column layout, which is the intended behaviour. Below the
   cut-off nothing is width-capped — the plot, the readouts and the cards all
   track the window — and relayout() keeps the readouts under the plot rather
   than over it.
   =========================================================================== */
@media (min-width:1280px){
  #app{display:flex;align-items:flex-start;gap:10px;}
  #colL{order:1;width:460px;flex:none;}
  #colR{order:2;flex:1;min-width:0;position:sticky;top:10px;}
  .radarwrap{margin-bottom:0;}
  /* The readout table takes the plot's bottom-left corner, and the frame
     counter moves into it — .midStack is left holding just presence. */
  .radarwrap > #outCol{left:16px;right:auto;width:560px;}
  #outBox .ofr{display:flex;}
  #frameBox{display:none;}
  /* Presence moves to the plot's bottom-right corner. Text size is the same
     as everywhere else - phone and desktop read identically. */
  .midStack{right:16px;width:190px;}
  #humanBox{height:96px;}
}
</style></head>
<body>
<h1>KW307</h1><span class="sub">24 GHz radar &middot; WiFi dashboard</span>
<div id="bar">
  <span class="st" id="st">&#9679; Connecting...</span>
  <span class="hint" id="fwHint">Check FW to enable Clear State + advanced mode</span>
  <span id="fwDisplay">v?.?.?</span>
  <span>NACK:</span><b id="nk">0</b>
</div>

<!-- Two columns on a wide screen, one on a narrow one. colR is first in the
     DOM so the narrow layout keeps today's order (plot, ENTER, cards); the
     wide layout puts colL first with `order`. -->
<div id="app">
<div id="colR">
<div class="radarwrap">
  <canvas id="radar"></canvas>
  <!-- Bottom-left slot for the Nearest filter. relayout() parks it here at
       every width except the wide layout, which has #nearHost instead. -->
  <span id="nearOnPlot" class="ovl">
    <!-- View controls: none of these reach the module or join the ENTER
         batch, and each one undoes itself when pressed again. -->
    <span id="nearGroup">
      <button id="nearBtn" class="actBtn" aria-pressed="false" onclick="toggleNear(this)"
              title="Show only the closest target on the plot. The readout table still lists every target, with the ones not plotted dimmed. Changes the display only.">Nearest</button>
      <button id="flipHBtn" class="actBtn flipBtn" aria-pressed="false" onclick="toggleFlip(this,'h')"
              title="Mirror the plot left to right, for a module mounted facing the other way. Display only — press again to put it back.">&#8596;</button>
      <button id="flipVBtn" class="actBtn flipBtn" aria-pressed="false" onclick="toggleFlip(this,'v')"
              title="Mirror the plot top to bottom, for a module mounted inverted. Display only — press again to put it back.">&#8597;</button>
    </span>
  </span>
  <!-- Bottom-right slot for the plot-zoom dropdown; the wide layout moves the
       control itself under the Human box instead. -->
  <span id="rangeOnPlot" class="ovl">
    <div id="rangeBox" title="How far the plot reaches, in metres. A view control: nothing is sent to the radar. It cannot read shorter than the detection range in use — pick a smaller number and it snaps back up to that range.">
      <span class="rgl">RANGE</span>
      <select id="i_fan" onchange="fanChanged()">
        <option value="100">1m</option><option value="200">2m</option>
        <option value="300">3m</option><option value="400">4m</option>
        <option value="500">5m</option><option value="600">6m</option>
        <option value="700">7m</option><option value="800">8m</option>
        <option value="900">9m</option><option value="1000" selected>10m</option>
        <option value="1100">11m</option><option value="1200">12m</option>
      </select>
    </div>
  </span>
  <div class="mcuActs ovl">
    <button class="actBtn" onclick="mcuAction(this,'radarinit')" title="Restart the radar with its saved settings. Takes a moment, and anything applied but not saved is lost.">Initial</button>
    <button class="actBtn danger" onclick="mcuAction(this,'reset')" title="Erase all saved settings and return the radar to its factory defaults.">Factory Reset</button>
    <button class="actBtn" onclick="mcuAction(this,'save')" title="Save the current settings so they survive a power cycle.">Save Setting</button>
  </div>
  <!-- Readout table, with the Nearest toggle stacked above it (outside it).
       #nearHost is empty except in the wide layout, where relayout() parks the
       button here; empty it collapses, so the box keeps its position. -->
  <div id="outCol" class="ovl">
  <span id="nearHost"></span>
  <div id="outBox">
    <div class="oh">Output (presence + targets)</div>
    <table id="outTab">
      <tr><th></th><th>Dist(cm)</th><th>Ang(deg)</th><th>Mag</th><th>State</th></tr>
      <tr><td class="rl">Moving 0</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>
      <tr><td class="rl">Moving 1</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>
      <tr><td class="rl">Stationary 0</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>
    </table>
    <div class="ofr"><span class="rl">Frame #</span><span id="outFrame">-</span></div>
  </div>
  </div><!-- /outCol -->
  <div class="midStack ovl">
    <div id="frameBox" class="stale" title="Counts the readings arriving from the radar.">no frame</div>
    <div id="humanBox" class="nd">
      <span class="hl">PRESENCE</span><span class="hv">--</span>
    </div>
  </div>
  <div class="rightActs ovl">
    <button id="fwBtn" class="attn" onclick="readFw(this)" title="Read the radar firmware version. Only Clear State and Tracker state advanced mode depend on it — they do not exist on older firmware, so they stay locked until a version actually comes back. Everything else works without it.">Check FW</button>
    <button id="clearBtn" class="actBtn" disabled onclick="mcuAction(this,'clearstate')" title="Forget the targets being tracked right now and start detecting again. Settings are kept. Needs firmware 2.7.2 or newer.">Clear State</button>
  </div>
</div>
<!-- Where the readout table goes when the plot is too narrow to host it. -->
<div id="outHost"></div>
</div><!-- /colR -->

<div id="colL">

<!-- Module actions. Empty (and hidden) in the narrow layout, where
     relayout() parks the two button stacks back over the plot instead. -->
<div class="panel" id="sysCard">
  <div class="title"><span>System</span><span class="cmd">module actions</span></div>
  <div id="sysHost"></div>
</div>

<div class="panel">
  <button id="enter" onclick="applyAll()">ENTER (APPLY SETTINGS)</button>
</div>

<div class="panel">
  <div class="title"><span>Customer Control Panel</span><span class="cmd">press ENTER to apply</span></div>

  <div class="g"><span class="lb">Application</span>
    <select id="i_scene" class="wide" onchange="applyScenePreset();upd();draw(lastD);">
      <option value="0">Outdoor</option>
      <option value="1" selected>Office</option>
      <option value="2">Desk</option>
      <option value="3">Urinal</option>
      <option value="4">Hand-dryer</option>
    </select>
  </div>

  <div class="g"><span class="lb">Gain</span>
    <select id="i_gain" class="wide" onchange="upd()" title="Receiver gain, -3 to +21 dB.">
      <option value="0">0: -3 dB</option><option value="1">1: 0 dB</option>
      <option value="2">2: +3 dB</option><option value="3">3: +6 dB</option>
      <option value="4">4: +9 dB</option><option value="5" selected>5: +12 dB</option>
      <option value="6">6: +15 dB</option><option value="7">7: +18 dB</option>
      <option value="8">8: +21 dB</option>
    </select>
  </div>

  <div class="g"><span class="lb">Room range min/max (cm)</span>
    <select id="i_rmin" class="c1" onchange="clampMinMax('min');upd();" title="Closest distance the radar reports, in cm.">
      <option value="10">10</option><option value="50" selected>50</option>
      <option value="100">100</option><option value="150">150</option>
      <option value="200">200</option><option value="250">250</option>
      <option value="300">300</option>
    </select>
    <select id="i_rmax" class="c2" onchange="clampMinMax('max');upd();" title="Furthest distance the radar reports, in cm. Must be greater than the minimum.">
      <option value="100">100</option><option value="150">150</option>
      <option value="200">200</option><option value="300">300</option>
      <option value="400">400</option><option value="500">500</option>
      <option value="600">600</option><option value="700">700</option>
      <option value="800">800</option><option value="900">900</option>
      <option value="1000" selected>1000</option><option value="1100">1100</option>
      <option value="1200">1200</option>
    </select>
  </div>

  <div class="g"><span class="lb">Field of view/shrink</span>
    <select id="i_fov" class="c1" onchange="upd()" title="Width of the detection area.">
      <option value="200">20&deg;</option><option value="400">40&deg;</option>
      <option value="600">60&deg;</option><option value="800">80&deg;</option>
      <option value="1000">100&deg;</option><option value="1200" selected>120&deg;</option>
    </select>
    <input type="number" id="i_shr" class="c2" value="8" min="0" max="25" onchange="upd()"
           title="How much the detection area narrows for every 100 cm of distance (0-25). Higher makes it tighter far away.">
  </div>

  <div class="g"><span class="lb">Motion sensitivity</span>
    <select id="i_mot" class="c1" onchange="upd()" title="0 picks up the slightest movement, 9 only obvious movement.">
      <option value="0">0</option><option value="1">1</option>
      <option value="2" selected>2</option><option value="3">3</option>
      <option value="4">4</option><option value="5">5</option>
      <option value="6">6</option><option value="7">7</option>
      <option value="8">8</option><option value="9">9</option>
    </select>
    <label class="c2 ck" title="React to movement however brief or slow it is — for fast-response uses such as a hand dryer.">
      <input type="checkbox" id="i_mbyp" onchange="upd()">byp_spd</label>
  </div>

  <div class="g"><span class="lb">Stationary sensitivity</span>
    <select id="i_sta" class="c1" onchange="upd()" title="0 detects someone sitting completely still, 9 only clearer signals.">
      <option value="0">0</option><option value="1" selected>1</option>
      <option value="2">2</option><option value="3">3</option>
      <option value="4">4</option><option value="5">5</option>
      <option value="6">6</option><option value="7">7</option>
      <option value="8">8</option><option value="9">9</option>
    </select>
  </div>

  <div class="g"><span class="lb">Flag hold time (s)</span>
    <select id="i_hold" class="c1" onchange="upd()" title="How long presence stays on after the last detection.">
      <option value="1">1</option><option value="2">2</option>
      <option value="3">3</option><option value="4">4</option>
      <option value="5">5</option><option value="11" selected>11</option>
      <option value="20">20</option><option value="30">30</option>
      <option value="60">60</option>
    </select>
  </div>

  <div class="g"><span class="lb">Mag floor mov/stat</span>
    <select id="i_nf" class="c1" onchange="upd()" title="Minimum signal strength for a moving target. Higher = less sensitive.">
      <option value="150">150</option><option value="200">200</option>
      <option value="250">250</option><option value="350" selected>350</option>
      <option value="450">450</option><option value="550">550</option>
      <option value="650">650</option><option value="750">750</option>
      <option value="850">850</option><option value="950">950</option>
    </select>
    <select id="i_ns" class="c2" onchange="upd()" title="Minimum signal strength for a still target. Higher = less sensitive.">
      <option value="50">50</option><option value="100" selected>100</option>
      <option value="150">150</option><option value="200">200</option>
      <option value="250">250</option><option value="300">300</option>
      <option value="350">350</option><option value="400">400</option>
      <option value="500">500</option><option value="600">600</option>
    </select>
  </div>

  <div class="g"><span class="lb">Moving trk max/show</span>
    <input type="number" id="i_mvmax"  class="c1" value="32" min="1" max="255" onchange="upd()"
           title="How long a moving target is kept after it stops being detected (1-255).">
    <input type="number" id="i_mvshow" class="c2" value="8"  min="1" max="255" onchange="upd()"
           title="Response time: frames before the slot turns Valid (1~255, must be <= max)">
  </div>

  <div class="g"><span class="lb">Stationary trk max/show</span>
    <input type="number" id="i_stmax"  class="c1" value="64" min="1" max="255" onchange="upd()"
           title="How long a still target is kept after it stops being detected (1-255).">
    <input type="number" id="i_stshow" class="c2" value="8"  min="1" max="255" onchange="upd()"
           title="Response time: frames before the slot turns Valid (1~255, must be <= max)">
  </div>

  <div class="sep"></div>

  <div class="g">
    <label class="lb ck" title="Keep presence on while someone sits still within the area set below, so short dropouts do not make it flicker.">
      <input type="checkbox" id="i_fsen" checked onchange="upd()">Force statio. (cm/deg)</label>
    <input type="number" id="i_fsdist" class="c1" value="150" min="0" max="3276" onchange="upd()" title="Depth of that area, in cm.">
    <input type="number" id="i_fsfov"  class="c2" value="40"  min="0" max="180"  onchange="upd()" title="Width of that area, in degrees.">
  </div>

  <div class="g">
    <label class="lb ck" title="Stop reporting a still target after the time set below. Unticked keeps it indefinitely.">
      <input type="checkbox" id="i_msten" checked onchange="upd()">Max still time (s)</label>
    <input type="number" id="i_mstsec" class="c1" value="20" min="0" max="3276" onchange="upd()" title="Time before a still target is released, in seconds.">
  </div>

  <div class="g">
    <label class="lb ck" title="Ignore repeating movement from equipment such as fans or air conditioning.">
      <input type="checkbox" id="i_clen" checked onchange="upd()">Adv clutter rej (sth/dth)</label>
    <input type="number" id="i_clspd" class="c1" value="300" min="0" max="1000" onchange="upd()" title="Movement threshold (0-1000). Higher ignores more.">
    <input type="number" id="i_cldev" class="c2" value="20"  min="0" max="50"   onchange="upd()" title="Allowed drift in cm (0-50). Higher ignores more.">
  </div>

  <div class="sep"></div>

  <div class="g">
    <label class="lb ck" title="Put the radar to sleep. Detection and readings stop until it is woken.">
      <input type="checkbox" id="i_pdn" onchange="upd()">Power down (sleep)</label>
  </div>

  <div class="g">
    <label class="lb ck" title="Let the presence output follow detection. Unticked keeps it off. This one is not saved.">
      <input type="checkbox" id="i_gpio" checked onchange="upd()">GPIO human flag output</label>
  </div>

  <div class="g">
    <!-- Starts locked like Clear State: the version is unknown until Check FW
         runs, so we cannot yet know whether the module supports this.
         applyLocks() releases it once a version >= 2.7.0 has been read. -->
    <label class="lb ck dis" title="Report the extra intermediate target states used when evaluating the radar. Needs firmware 2.7.0 or newer.">
      <input type="checkbox" id="i_trkadv" disabled onchange="upd()">Tracker state advanced mode</label>
  </div>
</div>

</div><!-- /colL -->
</div><!-- /app -->

<script>
const $=(i)=>document.getElementById(i);
const v=(i)=>$(i).value;
/* Checkbox read/write. The seven booleans go on the wire as 1 / 0. */
const ck =(i)=>$(i).checked ? 1 : 0;
const setCk=(i,x)=>{ $(i).checked = !!x; };
/* Fan-plot max range per scene index (cm), so the plot zoom matches the
 * selected application. */
const SCENE_FAN_CM = [1200, 1000, 300, 200, 200];
/* How far the fan currently reaches. Seeded from the scene the backend boots
 * in (1 = Office) and thereafter owned by the RANGE dropdown on the plot, by
 * the scene ENTER applies, and by the floor rule in update(). */
let fanCm = SCENE_FAN_CM[1];
function setFan(n){
  /* Round up to a whole hundred: the dropdown only holds those, and a floor
   * that is not one of them (a 150 cm detection range, say) has to land on the
   * option above it or the select would be handed a value it does not carry. */
  fanCm = Math.max(100, Math.min(1200, Math.ceil(n/100)*100));
  $('i_fan').value = fanCm;
}
/* A zoom shorter than the detection range would draw a live area the plot
 * cannot show, so the range in use is the floor. Picking under it snaps back
 * up rather than being refused — the choice still lands somewhere sensible. */
function fanChanged(){
  const floorCm = (lastD && lastD.range_max_cm) ? lastD.range_max_cm : 100;
  setFan(Math.max(parseInt(v('i_fan')) || fanCm, floorCm));
  draw(lastD);
}

/* Friendly scene names shown on the fwDisplay after ENTER. */
const SCENE_NAMES = ['Outdoor', 'Office', 'Desk', 'Urinal', 'Hand Dryer'];

/* fwDisplay current mode: 'fw' = show v?.?.? / version, 'scene' = show
 * the last applied scene name. readFw() flips back to 'fw'; applyAll()
 * flips to 'scene'. */
let dispMode = 'fw';

/* Per-scene panel defaults.
 *   fov is in 0.1 deg (1200 = 120 deg); shr is whole degrees per 100 cm.
 *   mot: 0 = most sensitive ... 9 = least.
 *   byp: react to any motion regardless of accumulated speed. Left off in
 *        these presets; HAND_DRYER uses a tight force-stationary window
 *        instead. */
const SCENE_PRESETS = [
  /* 0 OUTDOOR    */ { gain:5, rmin:50, rmax:1200, fov:1200, shr:8, mot:6, byp:0, sta:3, hold:5,  nf:350, ns:100,
                       mvmax:32, mvshow:8, stmax:64, stshow:8, msten:1, mstsec:5,   fsen:0, fsdist:150, fsfov:40, clen:0, clspd:300, cldev:20 },
  /* 1 OFFICE     */ { gain:5, rmin:50, rmax:1000, fov:1200, shr:8, mot:2, byp:0, sta:1, hold:11, nf:350, ns:100,
                       mvmax:32, mvshow:8, stmax:64, stshow:8, msten:1, mstsec:20,  fsen:1, fsdist:150, fsfov:40, clen:1, clspd:300, cldev:20 },
  /* 2 DESK       */ { gain:3, rmin:50, rmax:200,  fov:1200, shr:8, mot:0, byp:0, sta:0, hold:11, nf:350, ns:100,
                       mvmax:32, mvshow:8, stmax:64, stshow:8, msten:1, mstsec:120, fsen:1, fsdist:150, fsfov:40, clen:1, clspd:300, cldev:20 },
  /* 3 URINAL     */ { gain:3, rmin:10, rmax:150,  fov:600,  shr:5, mot:1, byp:0, sta:1, hold:1,  nf:350, ns:100,
                       mvmax:32, mvshow:8, stmax:64, stshow:8, msten:1, mstsec:60,  fsen:1, fsdist:150, fsfov:40, clen:0, clspd:300, cldev:20 },
  /* 4 HAND_DRYER */ { gain:5, rmin:10, rmax:100,  fov:400,  shr:5, mot:9, byp:0, sta:0, hold:1,  nf:200, ns:600,
                       mvmax:20, mvshow:2, stmax:20, stshow:2, msten:0, mstsec:10,  fsen:1, fsdist:100, fsfov:20, clen:0, clspd:300, cldev:20 },
];

/* Load a scene row into the panel. Fills local state only — nothing reaches
 * the module until ENTER. */
function applyScenePreset(){
  const idx = parseInt(v('i_scene'))||0;
  const p = SCENE_PRESETS[idx];
  if (!p) return;
  $('i_gain').value   = p.gain;
  $('i_rmin').value   = p.rmin;
  $('i_rmax').value   = p.rmax;
  $('i_fov').value    = p.fov;
  $('i_shr').value    = p.shr;
  $('i_mot').value    = p.mot;
  $('i_sta').value    = p.sta;
  $('i_hold').value   = p.hold;
  $('i_nf').value     = p.nf;
  $('i_ns').value     = p.ns;
  $('i_mvmax').value  = p.mvmax;
  $('i_mvshow').value = p.mvshow;
  $('i_stmax').value  = p.stmax;
  $('i_stshow').value = p.stshow;
  $('i_fsdist').value = p.fsdist;
  $('i_fsfov').value  = p.fsfov;
  $('i_mstsec').value = p.mstsec;
  $('i_clspd').value  = p.clspd;
  $('i_cldev').value  = p.cldev;
  setCk('i_mbyp',  p.byp);
  setCk('i_fsen',  p.fsen);
  setCk('i_msten', p.msten);
  setCk('i_clen',  p.clen);
}
let lastD=null, polling=true, errs=0, timer, dirty=false;

async function postCmd(c){
  try{ await fetch('/cmd',{method:'POST',headers:{'Content-Type':'text/plain'},body:c}); }catch(e){}
}

function upd(){
  dirty = true;
  $('enter').classList.add('pending');
}

function clampMinMax(changed){
  /* Enforce min < max strictly. If picking min crept past max, push
   * max up to the first valid option above min. If picking max dropped
   * below min, pull min down to the last valid option below max. */
  const min = parseInt(v('i_rmin'));
  const max = parseInt(v('i_rmax'));
  if (min < max) return;
  if (changed === 'min') {
    const sel = $('i_rmax');
    for (const o of sel.options) {
      if (parseInt(o.value) > min) { sel.value = o.value; return; }
    }
  } else {
    const sel = $('i_rmin');
    let pick = null;
    for (const o of sel.options) {
      if (parseInt(o.value) < max) pick = o.value;
    }
    if (pick !== null) sel.value = pick;
  }
}

/* A click locks every action for at least 1 second. On release the FW-based
 * lock is reapplied rather than blanket-enabling, so the buttons that were
 * locked before the click (version not read yet) stay locked. */
let cooldownRunning = false;
async function withCooldown(action){
  if (cooldownRunning) return;
  cooldownRunning = true;
  $('enter').disabled = true;
  $('fwBtn').disabled = true;
  document.querySelectorAll('.actBtn').forEach(b=>{ b.disabled = true; });
  const floor = new Promise(r => setTimeout(r, 1000));
  try {
    await Promise.all([Promise.resolve(action()), floor]);
  } finally {
    cooldownRunning = false;
    $('fwBtn').disabled = false;                       /* always the way out */
    $('nearBtn').disabled = false;                     /* display filter only */
    applyLocks(lastD);
  }
}

async function mcuAction(btn, verb){
  if (verb === 'reset' && !confirm('Factory reset will CLEAR all saved settings in NVM. Continue?')) return;
  if (verb === 'save'  && !confirm('Save current settings to flash? (consumes 1 flash cycle)')) return;
  await withCooldown(async () => {
    btn.classList.add('busy');
    await postCmd(verb);
    btn.classList.remove('busy');
  });
}

async function readFw(btn){
  dispMode = 'fw';   /* hand the display back to version readout */
  await withCooldown(async () => {
    btn.classList.add('busy');
    await postCmd('fwver');
    setTimeout(()=>{ btn.classList.remove('busy'); }, 200);
  });
}

/* ---- Firmware version ------------------------------------------------------
 * The dashboard does nothing to the module until Check FW has returned a
 * version, because the version is what tells it how to read the frames: the
 * tracker-state form only exists from 2.7.0, and firmware older than
 * that always emits the advanced values whatever the switch says. Boot writes
 * nothing, so the version is the only way to know which Valid value applies.
 * fwCode(): 0 = never read, -1 = read failed, else MMmmpp. */
const FW_BASELINE     = 20703;/* 2.7.3 — the SDK's paired baseline */
const FW_SIMPLE_FORM  = 20700;/* 2.7.0 — tracker-state form added */
const FW_CLEAR_STATE  = 20702;/* 2.7.2 — Clear State added */
function fwCode(d){
  if (!d) return 0;
  const maj = d.fw_major|0;
  if (maj === 0xFF) return -1;            /* backend sentinel for a failed read */
  return maj*10000 + (d.fw_minor|0)*100 + (d.fw_patch|0);
}
/* Check FW has been pressed at least once. The backend distinguishes the two
 * cases for us: 0 = never asked, -1 (0xFF sentinel) = asked and the module did
 * not answer. Pressing it is what unlocks the main actions — they do not depend
 * on the version, only on the operator having made contact deliberately. */
const fwTried = (d)=> fwCode(d) !== 0;
const fwKnown = (d)=> fwCode(d) > 0;
/* Never true before the version is read (fwCode is 0 or -1 then), so one test
 * covers both "too old" and "not known yet". */
const fwAtLeast = (d,code)=> fwCode(d) >= code;
/* Pre-2.7.0 has no simple form at all — it reports the advanced values and
 * ignores the switch, so the plot must test for 3 no matter what trk_adv says. */
const fwAlwaysAdvanced = (d)=>{ const c = fwCode(d); return c > 0 && c < FW_SIMPLE_FORM; };
/* The form the frames are actually arriving in, from three sources in order of
 * authority:
 *   fwAlwaysAdvanced  the version says the module has no simple form
 *   trk_adv           we set the form ourselves, so we know it
 *   saw_adv           the backend saw a moving state above 1, which cannot
 *                     happen in the simple form
 * The last one is what makes this safe with a module that was left in the
 * advanced form and saved: nothing has to be read or written to find out, the
 * first target that appears settles it. */
const advForm = (d)=> !!(d && (d.trk_adv || d.saw_adv)) || fwAlwaysAdvanced(d);

function showFw(d){
  /* Display owned by applyAll() while in 'scene' mode — skip here. */
  if (dispMode !== 'fw') return;

  const code = fwCode(d);
  const disp = $('fwDisplay');

  if (code < 0) {
    disp.textContent = 'READ FAIL';
    disp.className = 'bad';
  } else if (code === 0) {
    /* Never read. The bar hint and the pulsing button say what to do about
     * it; this only has to report that nothing is known yet. */
    disp.textContent = 'v?.?.?';
    disp.className = '';
  } else {
    disp.textContent = 'v' + (d.fw_major|0) + '.' + (d.fw_minor|0) + '.' + (d.fw_patch|0);
    disp.className = code >= FW_BASELINE ? 'match'
                   : (code >= 20300 ? 'partial' : 'bad');
  }
}

/* One gate, and it only covers what the firmware may not have:
 *
 *   a version >= X  ->  Clear State (2.7.2) and
 *                       Tracker state advanced mode (2.7.0)
 *       These two do not exist on older firmware, and a version that was never
 *       read cannot clear the bar, so they stay unclickable until a real
 *       version comes back. Neither affects what is displayed — advForm()
 *       settles the reporting form on its own.
 *
 * Everything else — ENTER, Initial, Factory Reset, Save Setting, Nearest —
 * works on any firmware and is live from the moment the page loads. Check FW
 * used to gate them all as a deliberate "I am talking to this module now"
 * step; that cost every user a mandatory click to reach settings that were
 * never in doubt, so it is now a capability probe and nothing more. */
function applyLocks(d){
  /* While the 1-second cooldown owns the buttons, leave them alone — poll()
   * runs every 100 ms and would otherwise re-enable them mid-action. */
  if (cooldownRunning) return;

  /* Say it, do not just leave it unsaid. withCooldown() disables all of these
   * for its one-second floor and calls us to restore them, so an unlocked
   * control has to be unlocked here explicitly - otherwise the first press of
   * any action button retires the lot. */
  $('enter').disabled = false;
  document.querySelectorAll('.actBtn').forEach(b=>{ b.disabled = false; });
  $('clearBtn').disabled = !fwAtLeast(d, FW_CLEAR_STATE);

  const trk = $('i_trkadv'), lockTrk = !fwAtLeast(d, FW_SIMPLE_FORM);
  trk.disabled = lockTrk;
  trk.closest('label').classList.toggle('dis', lockTrk);

  /* Point at Check FW while it is still worth pressing - nothing is blocked
   * by it any more, so this is a note, not a warning. It stops pulsing after
   * one press whether the read succeeded or not: a module that never answers
   * should not nag forever. */
  const askFw = !fwTried(d);
  $('fwBtn').classList.toggle('attn', askFw);

  /* The note itself outlives the press, because pressing is not always the
   * answer: on old firmware those two stay grey for good, and going quiet at
   * that point reads as a fault. Deliberately coarse - the gates are really
   * 2.7.0 and 2.7.2, but the only builds in the field are 2.5.x and 2.7.5, so
   * one version to ask for beats a table of thresholds nobody will meet.
   * Silence in two cases only: nothing is locked, or the read came back empty
   * and the red READ FAIL beside this already says so. */
  const code = fwCode(d);
  let hint = '';
  if (code === 0)
    hint = 'Check FW to enable Clear State + advanced mode';
  else if (code > 0 && !fwAtLeast(d, FW_CLEAR_STATE))
    hint = 'Clear State + advanced mode need FW 2.7.5';
  $('fwHint').textContent = hint;
  $('fwHint').classList.toggle('off', !hint);
}

/* Apply the whole panel in one batch. "scene" carries no settings of its
 * own — it only records which preset the panel is showing, so /data can
 * report it back. */
async function applyAll(){
  await withCooldown(async () => {
    const btn = $('enter');
    btn.classList.add('sending');
    await postCmd('scene:' + v('i_scene'));
    await postCmd('gain:' + v('i_gain'));
    await postCmd('range:' + v('i_rmin') + ':' + v('i_rmax'));
    await postCmd('fov:' + v('i_fov') + ':' + (parseInt(v('i_shr'))||0)*10);
    await postCmd('motion:' + v('i_mot') + ':' + ck('i_mbyp'));
    await postCmd('stationary:' + v('i_sta'));
    await postCmd('hold:' + v('i_hold'));
    await postCmd('signal:' + v('i_nf') + ':' + v('i_ns'));
    await postCmd('movtrk:' + v('i_mvmax') + ':' + v('i_mvshow'));
    await postCmd('statrk:' + v('i_stmax') + ':' + v('i_stshow'));
    await postCmd('forcesta:' + ck('i_fsen') + ':' + v('i_fsdist') + ':' + v('i_fsfov'));
    await postCmd('maxsta:' + ck('i_msten') + ':' + v('i_mstsec'));
    await postCmd('clutter:' + ck('i_clen') + ':' + v('i_clspd') + ':' + v('i_cldev'));
    await postCmd('powerdown:' + ck('i_pdn'));
    /* Feature switches last. The tracker-state form goes out only at a
     * version known to have it (2.7.0). Older firmware rejects it, and
     * so does an unknown version - which ENTER now reaches, since it no longer
     * waits for Check FW. Same test as the checkbox's own lock: if it is not
     * offered, it is not sent. advForm() reads those frames as advanced
     * regardless. */
    if (fwAtLeast(lastD, FW_SIMPLE_FORM)) await postCmd('trkadv:' + ck('i_trkadv'));
    await postCmd('gpioflag:' + ck('i_gpio'));
    btn.classList.remove('sending');
    btn.classList.remove('pending');
    dirty = false;
    /* Hand the fwDisplay to the just-applied scene name. */
    const sceneIdx = parseInt(v('i_scene'))||0;
    /* The zoom follows the scene that was just applied; the floor rule in
     * update() then raises it again if the new detection range is longer
     * than that scene's usual reach. */
    setFan(SCENE_FAN_CM[sceneIdx] || fanCm);
    const disp = $('fwDisplay');
    disp.textContent = SCENE_NAMES[sceneIdx] || '-';
    disp.className = 'scene';
    dispMode = 'scene';
  });
}

function setSt(m,c){ const e=$('st'); e.textContent=m; e.className='st '+(c||''); }

async function poll(){
  if(!polling) return;
  try{
    const r=await fetch('/data',{cache:'no-store'});
    if(!r.ok) throw 0;
    const d=await r.json();
    errs=0; setSt('● Connected','ok');
    update(d);
  }catch(e){
    errs++;
    setSt('● '+(errs>2?'No response':'Connecting...'), errs>2?'err':'');
    /* The ESP itself stopped answering — clear the readouts, and lock the
     * controls back down. Leaving them enabled would offer actions that cannot
     * reach the module, and the version we unlocked on is no longer confirmed. */
    if (errs>2) { showStatus(null); applyLocks(null); }
  }
  timer=setTimeout(poll,100);
}

/* A frame older than this is treated as no data at all. The radar streams at
 * 20 Hz (50 ms) and /data is polled every 100 ms, so anything past a second
 * means the link is down, the module is powered down, or output was turned
 * off — none of which should keep showing the last reading as if it were now. */
const STALE_MS = 1000;
function isLive(d){ return !!(d && d.fresh && d.age < STALE_MS); }

/* The middle overlay column: frame counter and presence, plus the plot's
 * border glow. Presence has three states, because "no signal" and "nobody
 * here" are not the same thing. Pass null when the ESP itself stopped
 * answering — everything falls back to the no-data look. */
/* "Nearest target only" — a browser-side display filter. Nothing is sent to the
 * module and it takes no part in the ENTER batch, so the radar keeps tracking
 * and reporting all three slots.
 *   plot     draws only the closest Valid target
 *   table    keeps every value on display; the chosen row stays at its normal
 *            colour and the other two fade. Turning the filter off restores all
 *            three rows.
 * Repaint both here so toggling responds immediately even when polling is off. */
let nearOnly = false;
/* View flips, for a module mounted mirrored or upside down. Browser-side
 * only - the radar keeps reporting the same angles either way. */
let flipH = false, flipV = false;
function toggleFlip(btn, axis){
  const on = (axis === 'h') ? (flipH = !flipH) : (flipV = !flipV);
  btn.classList.toggle('on', on);
  btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  draw(lastD);
}
function toggleNear(btn){
  nearOnly = !nearOnly;
  btn.classList.toggle('on', nearOnly);
  btn.setAttribute('aria-pressed', nearOnly ? 'true' : 'false');
  draw(lastD);
  showOut(lastD);
}

/* Which slot is closest to the radar: 0/1 = moving, 2 = stationary, -1 = none.
 * Only Valid slots are eligible — an Empty or still-unconfirmed slot may carry
 * a stale or candidate distance, and picking one of those would make the filter
 * jump to a target that is not being displayed. */
function nearestIdx(d, adv){
  if (!isLive(d)) return -1;
  const s = [d.moving[0], d.moving[1], d.stationary];
  let best = -1, bd = Infinity;
  for (let i=0;i<3;i++){
    const o = s[i];
    if (!o || o.st !== (i===2 ? 1 : (adv ? 3 : 1))) continue;
    if (o.d < bd) { bd = o.d; best = i; }
  }
  return best;
}

/* Slot state as text. Which names apply depends on the reporting form, and
 * the stationary slot has its own set in the advanced form
 * (2 = Hidden, not Birth). */
function stateName(st, adv, stationary){
  if (!adv) return st === 1 ? 'Valid' : 'Empty';
  if (stationary) return ['Empty','Valid','Hidden'][st] || '?';
  return ['Empty','Check','Birth','Valid'][st] || '?';
}

/* Readout table. Rows grey out unless the slot is Valid, so a reading that is
 * still a candidate (or left over in an Empty slot) cannot be misread as a
 * confirmed target. */
function showOut(d){
  const live = isLive(d);
  const adv  = live && advForm(d);
  const rows = $('outTab').rows;
  const slots = live ? [d.moving[0], d.moving[1], d.stationary] : [null,null,null];
  /* All three slots are always reported with their real values, at full
   * brightness. The Nearest filter is the only thing that fades a row, so
   * switching it off always returns the whole table to normal. */
  const near = nearOnly ? nearestIdx(d, adv) : -1;
  for (let i=0;i<3;i++){
    const o = slots[i], tr = rows[i+1], c = tr.cells;
    const stat = (i === 2);
    tr.classList.toggle('dim', nearOnly && i !== near);
    c[1].textContent = o ? o.d : '-';
    c[2].textContent = o ? (o.a/10).toFixed(1) : '-';
    c[3].textContent = o ? o.m : '-';
    c[4].textContent = o ? stateName(o.st, adv, stat) : '-';
  }
  $('outFrame').textContent = live ? d.frame_index : '-';
}

function showStatus(d){
  const live = isLive(d);

  const fb = $('frameBox');
  fb.textContent = live ? d.frame_index : 'no frame';
  fb.classList.toggle('stale', !live);
  showOut(d);

  const box = $('humanBox'), val = box.querySelector('.hv');
  if (!live)          { box.className = 'nd'; val.textContent = 'NO DATA'; }
  else if (d.human)   { box.className = 'on'; val.textContent = 'YES';     }
  else                { box.className = '';   val.textContent = 'NO';      }

  cv.classList.toggle('present', live && !!d.human);
}

function update(d){
  lastD=d;
  showFw(d);
  applyLocks(d);
  showStatus(d);
  $('nk').textContent = d.last_nack || 0;
  /* Whatever changed the detection range — ENTER here, another browser, a
   * setting restored from flash — the zoom follows it up so the live area
   * always fits inside the fan. */
  if (d.range_max_cm && fanCm < d.range_max_cm) setFan(d.range_max_cm);
  draw(d);
}

/* ===== Radar fan plot ===== */
const cv=$('radar'), cx=cv.getContext('2d');

function draw(d){
  /* Half-disk fan: top at (cX, 40), radius rMax, always width-bound at
   * W/2 - 30 so the fan looks the same at every size.
   * The canvas is then made tall enough that the absolutely-positioned
   * button stacks clear the arc: fan bottom (cY + rMax) + the tallest
   * stack + its bottom offset. Deriving it beats a width breakpoint —
   * the action buttons grazed the arc at ~600-760 px back when the
   * height was just a fixed multiple of the width. */
  const W=cv.width=cv.offsetWidth;
  const cX=W/2, cY=40;
  const rFan=(cX-30)*0.98;
  /* Measure whatever overlays are on the plot right now rather than assuming:
   * the wide layout moves the button stacks into the System card and grows the
   * presence box, so any hard-coded height would be wrong at one breakpoint. */
  let stack=0;
  document.querySelectorAll('.radarwrap > .ovl')
          .forEach(e=>{ stack=Math.max(stack, e.offsetHeight); });
  const BOTTOM=14, PAD=6;
  let H=Math.floor(cY+rFan+stack+BOTTOM+PAD);
  /* On a wide screen the plot is sticky and its column can get very wide, so
   * the derived height would run off the bottom of the viewport. Cap it and
   * let the fan shrink instead. */
  const cap=window.innerHeight-120;
  if (H>cap && cap>240) H=cap;
  H=cv.height=Math.max(220,H);
  const rMax=Math.max(40, Math.min(rFan, H-cY-stack-BOTTOM-PAD));
  const rangeCm = fanCm;
  const rangeMM = rangeCm * 10;
  const fovDeg10 = d && d.fov_deg10 ? d.fov_deg10 : 1200;
  const fovMin = -fovDeg10/20, fovMax = fovDeg10/20;

  cx.fillStyle='#000'; cx.fillRect(0,0,W,H);

  /* The two view flips, applied to coordinates rather than with a canvas
   * transform: a transform would mirror the text along with the geometry and
   * leave the ring and angle labels back to front. Horizontal mirrors about
   * the fan's own axis; vertical mirrors within the fan's band, apex to rim,
   * so the plot never swings down into the overlay row beneath it. Labels keep
   * their values - a target that was at -35 deg still reads -35 deg, it has
   * only moved to the side of the plot the operator is now looking at. */
  const FX = (x)=> flipH ? (2*cX - x) : x;
  const FY = (y)=> flipV ? (2*cY + rMax - y) : y;
  /* Polar to screen: a = degrees off boresight, r = pixels from the apex. */
  const PX = (a,r)=> FX(cX + r*Math.cos((90-a)*Math.PI/180));
  const PY = (a,r)=> FY(cY + r*Math.sin((90-a)*Math.PI/180));

  function polyAngle(a1,a2,color){
    cx.fillStyle=color; cx.beginPath(); cx.moveTo(FX(cX),FY(cY));
    const steps=30;
    for(let i=0;i<=steps;i++){
      const a=a1+(a2-a1)*i/steps;
      cx.lineTo(PX(a,rMax), PY(a,rMax));
    }
    cx.closePath(); cx.fill();
  }
  if(fovMin>-90) polyAngle(-90,fovMin,'#1e1e1e');
  if(fovMax<90)  polyAngle(fovMax, 90,'#1e1e1e');

  /* Far distance gate, from the value the module is actually running (the same
   * source as fovDeg10) rather than the fan's scale. The fan scale is a
   * per-scene constant - a hand dryer plots 200 cm - while the gate is what the
   * radar was told to report, so the two are equal only by coincidence. Shade
   * the band beyond it. */
  const gateMax = d && d.range_max_cm ? d.range_max_cm : rangeCm;
  const rOut = Math.max(0, Math.min(rMax, rMax * (gateMax*10) / rangeMM));
  if(rMax-rOut > 0.5){
    cx.fillStyle='#1e1e1e'; cx.beginPath();
    const steps=30;
    for(let i=0;i<=steps;i++){ const a=fovMin+(fovMax-fovMin)*i/steps;
      cx.lineTo(PX(a,rMax), PY(a,rMax)); }
    for(let i=steps;i>=0;i--){ const a=fovMin+(fovMax-fovMin)*i/steps;
      cx.lineTo(PX(a,rOut), PY(a,rOut)); }
    cx.closePath(); cx.fill();
  }

  cx.strokeStyle='#333'; cx.lineWidth=1;
  cx.font='12px sans-serif'; cx.fillStyle='#999';
  let step = rangeMM>10000?5000:(rangeMM>5000?2000:(rangeMM>2000?1000:(rangeMM>1000?500:200)));
  for(let r=step;r<=rangeMM;r+=step){
    const rr=rMax*r/rangeMM;
    /* Polyline, not arc(): an arc is defined by a centre and a sweep, and
     * neither survives a mirror the way a list of points does. */
    cx.beginPath();
    for(let a=-90;a<=90;a+=3) cx.lineTo(PX(a,rr), PY(a,rr));
    cx.stroke();
    /* Just inside whichever rim the mirror has put the label on, and clear of
     * the chord on whichever side the fan now opens. */
    cx.fillText((r/1000).toFixed(r%1000?1:0)+'m',
                flipH ? FX(cX+rr)+4 : cX+rr-22,
                FY(cY) + (flipV ? 14 : -4));
  }

  for(let a=-90;a<=90;a+=15){
    cx.strokeStyle='#2a2a2a'; cx.beginPath();
    cx.moveTo(FX(cX),FY(cY));
    cx.lineTo(PX(a,rMax), PY(a,rMax));
    cx.stroke();
    cx.fillStyle='#666';
    cx.fillText(a+'°', PX(a,rMax+12)-12, PY(a,rMax+12)+4);
  }

  cx.strokeStyle='#444'; cx.lineWidth=2;
  cx.beginPath();
  cx.moveTo(PX(-90,rMax), PY(-90,rMax));
  cx.lineTo(PX( 90,rMax), PY( 90,rMax));
  cx.stroke();

  /* The live area: the FOV on the sides, the max distance gate at the front.
   * Drawn on the gate, not on the rim of the fan - a boundary at the rim claims
   * everything plotted is in range, which is false whenever the gate sits
   * inside the scene's scale. The min gate is left undrawn on purpose. */
  cx.strokeStyle='#fff'; cx.lineWidth=3;
  cx.beginPath();
  cx.moveTo(PX(fovMin,rOut), PY(fovMin,rOut));
  cx.lineTo(FX(cX),FY(cY));
  cx.lineTo(PX(fovMax,rOut), PY(fovMax,rOut));
  const arcSteps=48;
  for(let i=0;i<=arcSteps;i++){ const a=fovMax+(fovMin-fovMax)*i/arcSteps;
    cx.lineTo(PX(a,rOut), PY(a,rOut)); }
  cx.stroke();

  cx.fillStyle='#f00'; cx.beginPath(); cx.arc(FX(cX),FY(cY),4,0,2*Math.PI); cx.fill();
  cx.fillStyle='#cfcfcf'; cx.font='bold 14px sans-serif';
  cx.fillText('KEYWAVE KW307', 16, 20);

  if(isLive(d)){
    /* A slot holds a real target only at its Valid value, and which value that
     * is depends on the module's state reporting form (FW 2.7.0+):
     *   simple (default)  moving Valid = 1, stationary Valid = 1
     *   advanced          moving Valid = 3, stationary Valid = 1
     *                     (1 Checking / 2 Birth are unconfirmed candidates;
     *                      stationary 2 = Hidden behind a moving target)
     * advForm() is the form the frames actually arrive in: what the module
     * acknowledged (trk_adv), OR unconditionally advanced on firmware older
     * than 2.7.0, which has no simple form and ignores the switch. Reading the
     * checkbox instead would flip the test before the module has switched.
     * Never test st !== 0; that only happens to work in the simple form. */
    const MOVING_VALID = advForm(d) ? 3 : 1;
    /* With the Nearest filter on, only the closest Valid slot is plotted. */
    const near = nearOnly ? nearestIdx(d, advForm(d)) : -1;
    const drawObj=(o,color,req,idx)=>{
      if(!o || o.st!==req) return;
      if(nearOnly && idx!==near) return;
      let distCm=o.d, ang=o.a/10;
      let distMM=distCm*10;
      if(distMM>rangeMM) distMM=rangeMM;
      const nd=(distMM/rangeMM)*rMax;
      const x=PX(ang,nd), y=PY(ang,nd);
      cx.fillStyle=color; cx.beginPath(); cx.arc(x,y,9,0,2*Math.PI); cx.fill();
      /* Badge geometry follows the type size: 22 px tall for 14 px text,
       * top at y-10 so it stays centred on the dot, 5 px of padding each
       * side and the baseline 6 px below centre. */
      cx.font='bold 14px sans-serif';
      const info=distCm+'cm / '+ang.toFixed(1)+'°';
      const tw=cx.measureText(info).width;
      cx.fillStyle='#000'; cx.fillRect(x+10,y-10,tw+10,22);
      cx.strokeStyle='#fff'; cx.lineWidth=1; cx.strokeRect(x+10,y-10,tw+10,22);
      cx.fillStyle=color; cx.fillText(info, x+15, y+6);
    };
    drawObj(d.moving[0],  '#00e0ff', MOVING_VALID, 0);
    drawObj(d.moving[1],  '#00a8ff', MOVING_VALID, 1);
    drawObj(d.stationary, '#ffcc00', 1,            2);
  }
}

/* The five action buttons belong over the plot in the narrow layout and in
 * the System card in the wide one. CSS can restyle a node but cannot move it
 * to another parent, so do that here and rerun on every breakpoint crossing.
 * Inline onclick handlers survive reparenting, so nothing needs rebinding. */
const WIDE = window.matchMedia('(min-width:1280px)');
function relayout(){
  const wrap = document.querySelector('.radarwrap');
  /* The module actions live in the System card at every width. */
  const sys = $('sysHost');
  sys.appendChild(document.querySelector('.mcuActs'));
  sys.appendChild(document.querySelector('.rightActs'));
  /* The two readouts move together: over the plot in the wide layout, and
   * stacked directly under it — presence strip first, then the table — in
   * every narrower one. Keeping them adjacent is the point; splitting them
   * across the plot edge made the same reading hard to follow. */
  const host = WIDE.matches ? wrap : $('outHost');
  host.appendChild(document.querySelector('.midStack'));
  host.appendChild($('outCol'));
  /* Nearest ends up on the plot either way: just above the readout frame in the
   * wide layout, which sits in the plot's bottom-left corner, and in that
   * corner directly otherwise. Done after the stacks move so it is never
   * carried away with them into the System card. */
  ;(WIDE.matches ? $('nearHost') : $('nearOnPlot')).appendChild($('nearGroup'));
  /* The zoom dropdown rides with the presence box in the wide layout, where both
   * are on the plot; elsewhere it takes the plot's bottom-right corner. */
  ;(WIDE.matches ? document.querySelector('.midStack') : $('rangeOnPlot'))
      .appendChild($('rangeBox'));
}
const onBreakpoint = ()=>{ relayout(); draw(lastD); };
[WIDE].forEach(mq=>{
  if (mq.addEventListener) mq.addEventListener('change', onBreakpoint);
  else if (mq.addListener) mq.addListener(onBreakpoint);
});
relayout();

/* Redraw on any resize: the canvas height now also tracks the viewport height,
 * not just its own width. */
window.addEventListener('resize', ()=>{ draw(lastD); });
draw(null);  /* initial paint so canvas sizes correctly before first poll */
poll();
</script>
</body></html>
)HTMLEOF";
