/******************************************************************************
 * KW307 SDK - WiFi Dashboard (Raspberry Pi Pico 2 W)
 *
 * One-page web UI mapping each KW307 SDK 2.7.5 public API call to a
 * button / input, plus a Canvas-based radar fan plot.
 * Paired MCU firmware: 2.7.5.
 *
 *  BOARD
 *    Raspberry Pi Pico 2 W (RP2350 + CYW43439), built with the arduino-pico
 *    core (Earle Philhower). Tools > Board > "Raspberry Pi Pico 2 W" — the
 *    plain Pico 2 has no radio and KW307WiFi.h refuses to build on it.
 *    Board manager URL, if the core is not installed yet:
 *      https://github.com/earlephilhower/arduino-pico/releases/download/global/package_rp2040_index.json
 *
 *    The same sketch runs on a Pico W (RP2040); only the board selection
 *    changes. Nothing here is tied to either part beyond the two UART pins.
 *
 *  TWO CONNECTION METHODS - pick one in setup() below:
 *    Option A  Access Point:  wifi.connectAP("KW307-Radar", "12345678")
 *                              -> connect to that SSID, open http://192.168.4.1
 *    Option B  Station mode:  wifi.connectSTA(WIFI_SSID, WIFI_PASS)
 *                              -> open http://kw307.local (or printed IP)
 *
 *  WIRING
 *    Module TX -> Pico GP17 (RADAR_RX_PIN, physical pin 22)
 *    Module RX -> Pico GP16 (RADAR_TX_PIN, physical pin 21)
 *    GND       -> GND       (physical pin 23, right beside the two above)
 *    VCC 3V3   -> 3V3 OUT   (physical pin 36)
 *
 *    The module is a 3V3 part and so is the RP2350, so the two UARTs wire
 *    together directly - no level shifting.
 *，
 
 *  All SDK .c / .h files live in this sketch folder so Arduino compiles
 *  them automatically. Each /cmd endpoint on the web side maps to exactly
 *  one kw307_* API function - see KW307WiFi.cpp::_handleCmd.
 *
 *============================================================================
 * READING A FRAME - THE ONE RULE THAT IS EASY TO GET WRONG
 *============================================================================
 *  A target slot counts ONLY when its state means Valid.
 *
 *      NEVER write   if (slot.state != 0)      <-- wrong
 *      NEVER write   if (slot.mag   != 0)      <-- wrong, mag is signal
 *                                                  strength, not presence
 *      ALWAYS write  if (slot.state == <the Valid value>)
 *
 *  Which number is Valid depends on the reporting form the module is in:
 *
 *      form                      moving[0..1]     stationary[0]
 *      ----------------------    -------------    -------------
 *      simple   (module default)  Valid = 1        Valid = 1
 *      advanced (evaluation)      Valid = 3        Valid = 1
 *
 *  The other non-zero values are NOT targets to act on: in the advanced form
 *  1 and 2 are candidates the module has not confirmed, and a stationary 2 is
 *  a still target sitting where a moving one already is. Treating them as real
 *  reports people who are not there, or the same person twice.
 *
 *  The form cannot be assumed either, and there is no test that works for both:
 *  state 1 means Valid in the simple form but "not confirmed yet" in the
 *  advanced one, so reading it the wrong way either hides every moving target
 *  or invents ones that are not there. This sketch never hard-codes 1 or 3.
 *  It settles the question three ways, none of which costs a byte on the wire:
 *
 *    - firmware older than 2.7.5 has no simple form, so the version alone
 *      answers it (read once with Check FW);
 *    - if this sketch set the form itself, it already knows;
 *    - otherwise it watches the frames. A moving slot above 1 cannot occur in
 *      the simple form, so the first target that appears proves which form is
 *      running, and the answer corrects itself if anything changes it later.
 *
 *  That third rule is what makes a module someone else left in the advanced
 *  form work on first power-up without anyone noticing. See advForm() in the
 *  dashboard script and _saw_adv in KW307WiFi.h.
 *
 *  For the minimal non-web version of the same rule, see
 *  KW307_SDK_base/example_platform/Arduino_ESP32S3/main.ino (MOVING_VALID).
 *****************************************************************************/

#include "KW307_api.h"
#include "port_arduino.h"
#include "KW307WiFi.h"

/* ----- Pin definitions ------------------------------------------------- */
/* Radar UART. A UART is not free to land anywhere on this part: each block
 * accepts one fixed set of pins per direction. Pick outside the set and
 * setRX / setTX call panic() — the board halts on boot rather than coming up
 * with a dead port, so a wrong pin here is loud, not silent.
 *
 * RP2350 (Pico 2 W). Bracketed = wired to the CYW43 radio, see below:
 *     Serial1 (UART0)  TX  GP0, GP2, GP12, GP14, GP16, GP18, GP28
 *                      RX  GP1, GP3, GP13, GP15, GP17, GP19, (GP29)
 *     Serial2 (UART1)  TX  GP4, GP6, GP8, GP10, GP20, GP22, (GP24), GP26
 *                      RX  GP5, GP7, GP9, GP11, GP21, (GP23), (GP25), GP27
 *
 * GP23 / GP24 / GP25 / GP29 are the CYW43's WL_ON / WL_D / WL_CS / WL_CLK.
 * They are not on the header and taking one costs you WiFi — which on this
 * sketch is the entire user interface.
 *
 * On a Pico W (RP2040) the sets are much narrower — TX {0,12,16,28} /
 * RX {1,13,17,29} for UART0 — so a pin chosen from the RP2350 rows above may
 * panic there. GP16 / GP17 below are valid on both.
 *
 * The direction is not interchangeable: GP16 appears only in the TX set and
 * GP17 only in the RX set, so wiring them the other way round is not a slow
 * link or a silent one, it is a panic at begin().
 *
 * GP16 / GP17 sit next to each other at physical pins 21 / 22, with a GND at
 * pin 23 — a 3-pin run for the whole signal side of the link. The console is
 * USB CDC rather than a UART (see setup()), so nothing else wants them. */
#define RADAR_RX_PIN   17    /* GP receiving from module TX */
#define RADAR_TX_PIN   16    /* GP driving module RX        */
#define RADAR_SERIAL   Serial1

/* ----- WiFi (Option B only) ------------------------------------------- */
#define WIFI_SSID      "YOUR_WIFI"
#define WIFI_PASS      "YOUR_PASSWORD"

KW307WiFi wifi;

/* Latches every incoming frame into the dashboard. Handling frames yourself
 * instead? Read "READING A FRAME" above first. */
static void on_radar(const KW307Frame_t* f)
{
    wifi.feedFrame(f);
}

void setup()
{
    /* The console runs over native USB (Serial = USB CDC on this core), so it
     * never touches the radar's UART. The banner is deliberately not guarded by
     * a wait-for-host loop: the enumeration takes a moment and anything printed
     * before it is lost, but blocking on it would stop a board that is running
     * standalone, with the dashboard as its only interface. Reconnect the
     * monitor and press Check FW if you need to see the link report. */
    Serial.begin(115200);
    Serial.println(F("\n== KW307 WiFi Dashboard =="));

    /* 1. Start WiFi. Pick ONE method. The delay lets the 3V3 rail settle
     *    before the WiFi PHY draws its startup current - keep it. */
    delay(500);
    wifi.connectAP("KW307-Radar", "12345678");
    // wifi.connectSTA(WIFI_SSID, WIFI_PASS);

    Serial.print(F("[WiFi] Dashboard: "));
    Serial.println(wifi.getURL());

    /* 2. Bind HardwareSerial to the SDK and start it. */
    kw307_port_arduino_begin(RADAR_SERIAL, RADAR_RX_PIN, RADAR_TX_PIN);

    /* 3. Open the SDK. On failure the dashboard just reports NO DATA. */
    if (kw307_init() != KW307_OK)
        Serial.println(F("[SDK] kw307_init failed - radar link unavailable"));

    /* 4. No boot preset - the module keeps its own saved settings, so Save on
     *    the dashboard survives a power cycle. To force one, call kw307_set_*
     *    here plus wifi.setScene(n) to match the UI. */
    Serial.println(F("[MCU] not contacted - press Check FW on the dashboard"));

    /* 5. Register the per-frame callback. */
    kw307_on_frame(on_radar);
}

void loop()
{
    kw307_update();    /* drains UART RX + dispatches on_radar callback */
    wifi.tick();       /* services HTTP + mDNS + captive DNS */
}
