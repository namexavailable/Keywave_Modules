/******************************************************************************
 * KW307WiFi.h - WiFi HTTP dashboard wrapper for the KW307 radar (Pico 2 W)
 *
 * Serves a one-page dashboard over WiFi:
 *   - a live radar plot showing the targets the module reports
 *   - five module actions, drawn over the plot:
 *       Check FW / Initial / Clear State / Factory Reset / Save Setting
 *   - a settings panel: gain, detection range, field of view, sensitivity,
 *     signal thresholds, trackers, hold time and the feature switches
 *
 * Editing a control only changes what the browser is holding. ENTER then
 * applies the whole panel to the module in one batch. ENTER sits directly
 * under the plot so the radar stays in view while the settings go out.
 *
 * Every setting on the page maps to one public kw307_set_* function from
 * KW307_api.h; _processCommand() in the .cpp is the whole mapping.
 *
 * Scene presets (Outdoor / Office / Desk / Urinal / Hand Dryer) live in the
 * browser. Picking one only fills the panel — nothing reaches the module
 * until ENTER.
 *
 * TRACKER STATE FORM — see "READING A FRAME" in the .ino for the full rule.
 *   A slot holds a target only at its Valid value: moving 1 in the simple form,
 *   3 in the advanced one, stationary 1 in both. Never test state != 0.
 *
 *   Which form is running is decided in three places, highest authority first,
 *   and none of them costs any extra traffic:
 *     version < 2.7.0  no simple form exists, always advanced
 *     _trk_adv         this dashboard set the form, so it knows
 *     _saw_adv         a moving slot above 1 was seen, which the simple form
 *                      cannot produce (feedFrame)
 *   /data carries the last two so the page can apply the same rule. The third
 *   is what lets a module left in the advanced form work on first power-up,
 *   and is why boot neither writes nor reads anything.
 *
 * USAGE (in your .ino):
 *
 *   KW307WiFi wifi;
 *   static void on_radar(const KW307Frame_t* f) { wifi.feedFrame(f); }
 *
 *   void setup() {
 *       kw307_port_arduino_begin(Serial1, 17, 16);
 *       kw307_init();
 *       kw307_on_frame(on_radar);
 *       wifi.connectAP("KW307-Radar", "12345678");
 *   }
 *
 *   Boot deliberately puts nothing on the UART — not even a version read. The
 *   module is listened to and never touched until the operator presses
 *   Check FW, which unlocks the rest of the page.
 *****************************************************************************/

#ifndef KW307_WIFI_H
#define KW307_WIFI_H

/* Covers the Pico 2 W and the Pico W — only the board selection changes. */
#if !defined(ARDUINO_ARCH_RP2040)
#error "KW307WiFi (this copy) requires the arduino-pico core — select Raspberry Pi Pico 2 W."
#endif

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LEAmDNS.h>
#include <DNSServer.h>

#include "KW307_api.h"

#define KW307_MDNS_NAME  "kw307"

class KW307WiFi {
public:
    KW307WiFi();

    /* ----- Lifecycle ------------------------------------------------ */
    void   connectAP (const char* ssid = "KW307-Radar",
                      const char* password = "12345678");
    void   connectSTA(const char* ssid, const char* password);
    void   tick();
    String getURL();

    /* ----- Fed by the sketch --------------------------------------- */
    void feedFrame(const KW307Frame_t* f);
    void setScene(uint8_t mode)    { _scene = mode; }

private:
    WebServer _server;
    DNSServer _dns;
    bool      _apMode = false;

    /* mDNS is serviced from tick(), but only once it has started. */
    bool      _mdns_ok = false;

    /* Associated-client count, so tick() can report clients joining and
     * leaving. 0xFF = not sampled yet, which stops the first sample being
     * reported as a change. Polled on a timer, not every pass through loop(). */
    uint8_t   _sta_seen  = 0xFF;
    uint32_t  _sta_poll_ms = 0;
    static const uint32_t STA_POLL_MS = 1000u;

    /* Latest frame snapshot (latched by feedFrame()). _frame_ms timestamps it
     * so /data can report the frame's age: _have_frame alone only says "a frame
     * arrived at some point", which would let a dead link keep showing the last
     * reading as if it were current. */
    volatile KW307Frame_t _frame;
    volatile uint8_t      _have_frame = 0;
    volatile uint32_t     _frame_ms   = 0;

    /* Which reporting form the frames actually arrive in, worked out by
     * watching them rather than by asking the module. In the simple form a
     * moving slot only ever reports 0 or 1; 2 and 3 exist solely in the
     * advanced form, so seeing either is proof — no false positive is
     * possible. Set in feedFrame(), cleared whenever something may have
     * changed the form, and re-latched on the next target, so it corrects
     * itself without costing a single byte on the wire. */
    volatile uint8_t      _saw_adv    = 0;

    /* When the form was last disturbed, for the settling window in feedFrame().
     * Clearing _saw_adv is not enough on its own: the module only changes form
     * from its next frame, and frames it had already sent are still in the RX
     * buffer, so those stale ones re-latch the flag we just cleared. _saw_adv
     * never expires, so that one frame would pin the display to the old form
     * for good. 0 = never disturbed. */
    volatile uint32_t     _form_change_ms = 0;

    /* How long to stay deaf. 5 frames at the module's 20 Hz — enough to cover
     * the frame in flight, the "from the next frame" changeover and whatever
     * the RX buffer was holding, while staying far below the time it takes an
     * operator to notice anything. */
    static const uint32_t FORM_SETTLE_MS = 250u;

    /* Arm the window; call after anything that may have changed the form. */
    void _formDisturbed() { _form_change_ms = millis(); }
    /* False while the window is open. */
    bool _settled() const
    { return _form_change_ms == 0u || (millis() - _form_change_ms) > FORM_SETTLE_MS; }

    /* FW version read by the "Check FW" dashboard button — the only place it
     * comes from, since boot no longer reads it. 0/0/0 means never asked;
     * major == 0xFF means asked and the module did not answer. The page tells
     * those two apart: pressing the button unlocks the main actions either way,
     * while Clear State and the tracker-state form need a real version. */
    uint8_t _fw_major = 0;
    uint8_t _fw_minor = 0;
    uint8_t _fw_patch = 0;

    /* Mirror state — matches the dashboard's UI state, NOT a read-back of the
     * module. Seeded with the OFFICE scene preset (scene 1), which is also what
     * the dashboard's combos default to. The sketch does not push a boot preset
     * (the module keeps its own saved settings), so these values only become
     * authoritative once the user presses ENTER. */
    uint8_t  _scene          = 1;
    uint8_t  _gain           = 5;       /* +12 dB */
    uint16_t _range_min_cm   = 50;
    uint16_t _range_max_cm   = 1000;
    int16_t  _fov_deg10      = 1200;
    uint8_t  _shrink_deg10   = 80;      /* 8 deg / 100 cm */
    int16_t  _signal_moving      = 350;
    int16_t  _signal_stationary  = 100;
    uint16_t _hold_sec       = 11;

    /* Motion / Stationary combo indices (UI display + lookup key).
     * 2.7.5: level 0 = most sensitive ... 9 = least sensitive. */
    uint8_t _motion_idx     = 2;   /* L2 */
    uint8_t _motion_byp     = 0;   /* byp_spd: bypass the Fast-band speed gate */
    uint8_t _stationary_idx = 1;   /* L1 */

    /* ---- Rest of the settings panel ---- */
    bool     _force_sta_on      = true;
    int16_t  _force_sta_dist_cm = 150;
    int16_t  _force_sta_fov_deg = 40;
    uint8_t  _max_sta_en        = 1;
    uint16_t _max_sta_sec       = 20;
    uint8_t  _mov_trk_max       = 32;
    uint8_t  _mov_trk_show      = 8;
    uint8_t  _sta_trk_max       = 64;
    uint8_t  _sta_trk_show      = 8;
    bool     _clutter_en        = true;  /* repetitive-motion (fan / AC) rejection */
    int16_t  _clutter_spd       = 300;
    int16_t  _clutter_dev       = 20;    /* cm */

    /* Feature switches: Power Down / presence output pin / tracker form. */
    bool     _power_down        = false;
    bool     _gpio_flag         = true;  /* presence output pin follows the flag */
    bool     _trk_adv           = false; /* tracker-state reporting form */

    /* HTTP route handlers. */
    void _startServer();
    void _startMDNS();
    void _handleRoot();
    void _handleData();
    void _handleCmd();

    /* Parse / dispatch a "verb:args" POST body. */
    void _processCommand(const String& cmd);

    static int _parseInt(const String& s, int fallback);

    /* The embedded dashboard HTML (defined at the bottom of the .cpp). */
    static const char _dashboardHtml[] PROGMEM;
};

#endif /* KW307_WIFI_H */
