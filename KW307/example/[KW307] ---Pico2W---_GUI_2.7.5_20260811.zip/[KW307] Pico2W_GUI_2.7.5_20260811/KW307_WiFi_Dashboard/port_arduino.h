/**
 * KW307 SDK - Arduino HardwareSerial Port
 * File: Pico2W/port_arduino.h
 *
 * Implements KW307_port.h over Arduino HardwareSerial. This copy is built for
 * the Raspberry Pi Pico 2 W (arduino-pico core, RP2350 + CYW43439), and keeps
 * the ESP32 branch so the same file compiles on either board.
 *
 * USAGE (in your .ino):
 *
 *   #include "port_arduino.h"
 *
 *   void setup() {
 *       // Bind SDK to a UART AND start it in one call.
 *       kw307_port_arduino_begin(Serial1, 1, 0);   // RX = GP1, TX = GP0
 *
 *       kw307_init();
 *       kw307_on_frame(on_radar);           // MCU auto-streams frames at power-on
 *       // ...
 *   }
 *
 * WHY THE PORT TYPE IS A TYPEDEF
 *   On the ESP32 core the pins are arguments to begin(), so a HardwareSerial&
 *   is all this file ever needs. arduino-pico instead sets them on the object
 *   first (setRX / setTX / setFIFOSize, all of which must precede begin()), and
 *   those are members of SerialUART, not of the HardwareSerial base class it
 *   derives from. Taking the reference as the base class would compile the
 *   declaration and then fail on the calls, so the begin() helper takes the
 *   concrete type per core. kw307_port_arduino_bind() genuinely only needs the
 *   base class — read / write / available / flush — so it keeps it.
 */

#ifndef PORT_ARDUINO_H
#define PORT_ARDUINO_H

#include "KW307_port.h"

#ifdef __cplusplus
/* Arduino.h rather than <HardwareSerial.h>: the ESP32 core ships that header at
 * the top level, arduino-pico keeps its serial classes in cores/rp2040 and
 * reaches them through Arduino.h. Arduino.h is the one include every core
 * guarantees, and it defines both types below. */
#include <Arduino.h>

#if defined(ARDUINO_ARCH_RP2040)
  /* Covers RP2040 and RP2350 alike — arduino-pico defines this macro for both,
   * so a Pico 2 W and a Pico W take the same branch. */
  typedef SerialUART      KW307SerialPort_t;
#else
  typedef HardwareSerial  KW307SerialPort_t;
#endif

/**
 * Bind the SDK to an already-configured serial port.
 * Call BEFORE kw307_init(). Serial.begin(...) must be done by you.
 */
void kw307_port_arduino_bind(HardwareSerial& serial);

/**
 * Convenience helper: bind + begin in one call.
 * Uses baud = KW307_ARDUINO_UART_BAUD (see user_config.h).
 *
 * Pico (arduino-pico): rx_pin / tx_pin are applied with setRX() / setTX()
 *   before begin(). They are not free choices — each UART accepts only a fixed
 *   set (see the pin table in the .ino).
 * ESP32: rx_pin / tx_pin are passed straight to HardwareSerial::begin().
 */
void kw307_port_arduino_begin(KW307SerialPort_t& serial, int rx_pin, int tx_pin);

#endif /* __cplusplus */

#endif /* PORT_ARDUINO_H */
