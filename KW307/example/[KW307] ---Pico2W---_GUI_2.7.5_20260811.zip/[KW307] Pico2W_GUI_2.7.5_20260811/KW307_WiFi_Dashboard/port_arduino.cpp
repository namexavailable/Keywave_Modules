/**
 * KW307 SDK - Arduino HardwareSerial Port Implementation
 * File: Pico2W/port_arduino.cpp
 *
 * Single-instance static state - matches SDK singleton design.
 */

#include "port_arduino.h"
#include "user_config.h"
#include <Arduino.h>

static HardwareSerial* s_serial = nullptr;
static bool            s_open   = false;

/* ================================================================
   C++ binding helpers
   ================================================================ */

void kw307_port_arduino_bind(HardwareSerial& serial)
{
    s_serial = &serial;
}

void kw307_port_arduino_begin(KW307SerialPort_t& serial, int rx_pin, int tx_pin)
{
#if defined(ARDUINO_ARCH_RP2040)
    /* arduino-pico: pins and FIFO depth are properties of the port and have to
     * be set before begin() — begin() is what hands them to the PIO/UART block,
     * so anything set afterwards is ignored until the next begin(). */
    serial.setRX((pin_size_t)rx_pin);
    serial.setTX((pin_size_t)tx_pin);
    serial.setFIFOSize(KW307_ARDUINO_UART_FIFO);
    serial.begin(KW307_ARDUINO_UART_BAUD, SERIAL_8N1);
#elif defined(ESP32)
    /* ESP32 core accepts pin mapping in begin(). */
    serial.begin(KW307_ARDUINO_UART_BAUD, SERIAL_8N1, rx_pin, tx_pin);
#else
    (void)rx_pin; (void)tx_pin;
    serial.begin(KW307_ARDUINO_UART_BAUD);
#endif
    kw307_port_arduino_bind(serial);
}

/* ================================================================
   C interface expected by kw307_uart layer
   ================================================================ */

extern "C" {

int kw307_port_open(const char* port_name, int baud_rate)
{
    (void)port_name;   /* Arduino port picks the serial object via bind(). */
    (void)baud_rate;   /* Baud is applied by begin() / user. */

    if (!s_serial) return -1;
    s_open = true;
    return 0;
}

void kw307_port_close(void)
{
    /* Don't call Serial.end() - the user may still want debug output
     * on another Serial. Close is a logical state flip only. */
    s_open = false;
}

int kw307_port_send(const uint8_t* buf, int len)
{
    if (!s_open || !s_serial || len <= 0 || !buf) return -1;

    size_t written = s_serial->write(buf, (size_t)len);
    s_serial->flush();   /* drain TX FIFO so frame egress is complete */
    return (int)written;
}

int kw307_port_recv(uint8_t* buf, int max_len, int timeout_ms)
{
    if (!s_open || !s_serial || max_len <= 0 || !buf) return -1;

    int      count = 0;
    uint32_t start = millis();

    /* Wait up to timeout_ms for the first byte. */
    if (timeout_ms > 0) {
        while (s_serial->available() == 0) {
            if ((millis() - start) >= (uint32_t)timeout_ms) break;
            delay(1);
        }
    }

    /* Drain whatever is available, up to max_len. */
    while (count < max_len && s_serial->available() > 0) {
        int b = s_serial->read();
        if (b < 0) break;
        buf[count++] = (uint8_t)b;
    }
    return count;
}

int kw307_port_is_open(void)
{
    return s_open ? 1 : 0;
}

} /* extern "C" */
