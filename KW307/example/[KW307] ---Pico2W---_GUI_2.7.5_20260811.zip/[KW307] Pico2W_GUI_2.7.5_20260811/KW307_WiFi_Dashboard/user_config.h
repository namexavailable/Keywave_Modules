/**
 * KW307 SDK - Arduino User Configuration
 * File: Pico2W/user_config.h
 *
 * * Edit this file in your sketch folder to match your wiring. *
 *
 * Default baud rate is 115200 (matches KW307 UART0 factory default).
 * The HardwareSerial instance and pin assignment are selected in your
 * .ino file via kw307_port_arduino_begin(Serial1, RX, TX)
 * (declared in port_arduino.h).
 */

#ifndef KW307_USER_CONFIG_ARDUINO_H
#define KW307_USER_CONFIG_ARDUINO_H

/* Baud rate must match the KW307 firmware setting (default 115200). */
#define KW307_ARDUINO_UART_BAUD   115200UL

/* RX FIFO depth in bytes (arduino-pico only; the ESP32 core sizes its own).
 *
 * arduino-pico defaults SerialUART to a 32-byte software FIFO, which is under
 * one radar frame (34 bytes on the wire). The frames themselves are disposable
 * — only the newest is ever displayed — but the framing parser is not: an
 * overflow that lands mid-frame costs the CRC check on the frame after it as
 * well, because the parser has to resync from the next 0xAA it happens to see.
 * At 20 fps with the HTTP server sharing the same loop, that is often enough to
 * be visible as a stuttering frame counter.
 *
 * 512 bytes buys ~750 ms of buffering, which comfortably covers a slow HTTP
 * client holding up loop(). Applied by kw307_port_arduino_begin() before
 * begin(), where setFIFOSize() has to be called. */
#define KW307_ARDUINO_UART_FIFO   512u

#endif /* KW307_USER_CONFIG_ARDUINO_H */
